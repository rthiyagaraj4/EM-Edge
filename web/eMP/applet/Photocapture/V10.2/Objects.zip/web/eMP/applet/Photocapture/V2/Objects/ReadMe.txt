eHIS 5.10 Photo Capture 
=====================

- Install ActiveX Control.
  (regsvr32 IBAPhotoCapCtrl.ocx)

- Copy GdiPlus.dll to c:\winnt\system32.
  (Note: Ignore if already exists)

- Install respective camera driver.

- Copy IBAPhotoCap.ini to c:\winnt and do the necessary changes.

- Use Main.html to check whether the ActiveX is functioning properly
  (Edit ImageCaptureModal.html for the default patient_id)


