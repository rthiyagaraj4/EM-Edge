package eXH.EM;

import java.io.UnsupportedEncodingException;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.*;

import eXH.util.*;

@Path("/t2")

public class EMInboundWebservice {
	
	public static String l_debug_YN = "N";
	public static String l_app_msg = "";
	public static String l_event_type = "";
	
	@POST
	@Path("/emregisterpatient")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response EmRegisterPatient(String actionKey,@Context HttpHeaders headers) throws UnsupportedEncodingException {
		
	    String responseTxt = "";
		String[] str = null;
		
		String addedDate = new java.text.SimpleDateFormat( "yyyy-MM-dd HH:mm:ss" ).format( new java.util.Date() ) ;
		
		try {
			if (l_debug_YN.equals("Y"))	
				System.out.println(l_app_msg);
			System.out.println(" ::: Register Patient request date and time ::: "+addedDate);
			System.out.println(" .............................................................................. ");			
			
			l_debug_YN = XHUtil.getDebugYN();
			
			if (l_debug_YN.equals("Y"))	
				System.out.println("actionKey:::::::::::"+actionKey);
			
			
			String key = headers.getRequestHeader("key").get(0);
			
			responseTxt = EmRegisterPatient(actionKey,key);
			str = responseTxt.split("#");
			
			if (str.length > 1)
			{
				str[1] = str[1].replaceAll("\\$\\$", "#");				
			}
			
			System.out.println(" .............................................................................. ");
			
		} catch (Exception e) {
			e.printStackTrace();
			responseTxt = "E$!^Exception Occured";
		}
		return Response.status(responseCode(str[0])).entity(str[1]).build();
	}
	
	private String EmRegisterPatient(String paramString, String key) throws Exception {
		String responseTxt = "";
		
		try {
			
				l_app_msg = " ::: Inside Register Patient Transactions ::: ";
				if (l_debug_YN.equals("Y"))	
					System.out.println(l_app_msg);
				
				l_app_msg = " ::: Inside Register Patient paramString ::: "+paramString;
				if (l_debug_YN.equals("Y"))	
					System.out.println(l_app_msg);
				
				l_event_type = "OA30";

				EMInboundPatientRegistration QueryPatientDtls = new EMInboundPatientRegistration();

				responseTxt = QueryPatientDtls.processInPatRegRequest(paramString, key, l_event_type);
				
				l_app_msg = " ::: Inside Register Patient Response ::: "+responseTxt;
				if (l_debug_YN.equals("Y"))	
					System.out.println(l_app_msg);
				

		} catch (Exception exp) {
			exp.printStackTrace(System.err);
		}
		return responseTxt;
	}
	
	@POST
	@Path("/emscheduleappt")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response EmScheduleAppt(String actionKey,@Context HttpHeaders headers) {
		
	    String responseTxt = "", responseTxtPayment="";
		String[] str = null;
		
		String addedDate = new java.text.SimpleDateFormat( "yyyy-MM-dd HH:mm:ss" ).format( new java.util.Date() ) ;
		
		try {
			
			System.out.println(" ::: Schedule Appt Post request date and time ::: "+addedDate);
			System.out.println(" .............................................................................. ");
			
			l_debug_YN = XHUtil.getDebugYN();
			
			String key = headers.getRequestHeader("key").get(0);
			
			responseTxt = EmScheduleApptTrans(actionKey,key);
			if ((actionKey.contains("bank_ref_no") || actionKey.contains("net_amount_debit")) && 
					(!(responseTxt.contains("Error")||responseTxt.contains("\"status\":0"))))
			{
				System.out.println("::: Book Appointment with payment Details :::");
				responseTxtPayment=EMPaymentTransaction(actionKey,"OA25",key);
			}
			
			if (responseTxtPayment.contains("Error")||responseTxtPayment.contains("\"status\":0")){
				str=responseTxtPayment.split("#");
			}
			else{
			str = responseTxt.split("#");
			}
			
			System.out.println(" .............................................................................. ");
			
		} catch (Exception e) {
			e.printStackTrace();
			responseTxt = "E#Exception Occured";
		}
		return Response.status(responseCode(str[0])).entity(str[1]).build();
	}
	
	
	private String EmScheduleApptTrans(String paramString, String key) throws Exception {
		String responseTxt = "";
		
		try {
			
				l_app_msg = " ::: Inside Schedule Appt Transactions ::: ";
				if (l_debug_YN.equals("Y"))	
					System.out.println(l_app_msg);
				
				l_app_msg = " ::: Inside Schedule Appointment paramString ::: "+paramString;
				if (l_debug_YN.equals("Y"))	
					System.out.println(l_app_msg);
				
				l_event_type = "OA21";

				InboundTransaction QuerySchApptDtls = new InboundTransaction();

				responseTxt = QuerySchApptDtls.processInboundRequest(paramString, l_event_type, key);
				
				l_app_msg = " ::: Inside EmScheduleApptTrans responseTxt ::: "+responseTxt;
				if (l_debug_YN.equals("Y"))	
					System.out.println(l_app_msg);


		} catch (Exception exp) {
			exp.printStackTrace(System.err);
		}
		return responseTxt;
	}
	
	@POST
	@Path("/emrescheduleappt")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response EmRescheduleAppt(String actionKey,@Context HttpHeaders headers) {
		
		
	    String responseTxt = "";
		String[] str = null;
		
		String addedDate = new java.text.SimpleDateFormat( "yyyy-MM-dd HH:mm:ss" ).format( new java.util.Date() ) ;
		
		try {
			
			System.out.println(" ::: Reschedule Appointment request date and time ::: "+addedDate);
			System.out.println(" .............................................................................. ");
			
			l_debug_YN = XHUtil.getDebugYN();
			
			String key = headers.getRequestHeader("key").get(0);
			
			responseTxt = EmRescheduleApptTrans(actionKey, key);
			str = responseTxt.split("#");
			
			if (str.length > 1)
			{
				str[1] = str[1].replaceAll("\\$\\$", "#");				
			}
			
			System.out.println(" .............................................................................. ");
			
		} catch (Exception e) {
			e.printStackTrace();
			responseTxt = "E$!^Exception Occured";
		}
		return Response.status(responseCode(str[0])).entity(str[1]).build();
	}	

	private String EmRescheduleApptTrans(String paramString, String key) throws Exception {
		String responseTxt = "";
		
		try {
			
				l_app_msg = " ::: Inside Reschedule Appointments ::: ";
				if (l_debug_YN.equals("Y"))	
					System.out.println(l_app_msg);
				
				l_app_msg = " ::: Inside Reschedule Appointments paramString ::: "+paramString;
				if (l_debug_YN.equals("Y"))	
					System.out.println(l_app_msg);
				
				l_event_type = "OA23";

				InboundTransaction QueryRescheduleAppt = new InboundTransaction();

				responseTxt = QueryRescheduleAppt.processInboundRequest(paramString, l_event_type, key);
				
				l_app_msg = " ::: Inside Reschedule Appointments responseTxt ::: "+responseTxt;
				if (l_debug_YN.equals("Y"))	
					System.out.println(l_app_msg);


		} catch (Exception exp) {
			exp.printStackTrace(System.err);
		}
		return responseTxt;
	}
	
	@POST
	@Path("/emcancelappt")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response EmCancelAppt(String actionKey,@Context HttpHeaders headers) {
		
	    String responseTxt = "";
		String[] str = null;
		
		String addedDate = new java.text.SimpleDateFormat( "yyyy-MM-dd HH:mm:ss" ).format( new java.util.Date() ) ;
		
		try {
			
			System.out.println(" ::: Cancel Appointments Post request date and time ::: "+addedDate);
			System.out.println(" .............................................................................. ");
			
			l_debug_YN = XHUtil.getDebugYN();
			
			String key = headers.getRequestHeader("key").get(0);
			
			responseTxt = EmCancelledApptTrans(actionKey,key);
			str = responseTxt.split("#");
			
			if (str.length > 1)
			{
				str[1] = str[1].replaceAll("\\$\\$", "#");				
			}
			
			System.out.println(" .............................................................................. ");
			
		} catch (Exception e) {
			e.printStackTrace();
			responseTxt = "E$!^Exception Occured";
		}
		return Response.status(responseCode(str[0])).entity(str[1]).build();
	}
	
	private String EmCancelledApptTrans(String paramString, String key) throws Exception {
		String responseTxt = "";
		
		try {
			
				l_app_msg = " ::: Inside CancelledApptTrans ::: ";
				if (l_debug_YN.equals("Y"))	
					System.out.println(l_app_msg);
				
				l_app_msg = " ::: Inside CancelledApptTrans paramString ::: "+paramString;
				if (l_debug_YN.equals("Y"))	
					System.out.println(l_app_msg);
				
				l_event_type = "OA22";

				InboundTransaction QueryReasonDtls = new InboundTransaction();

				responseTxt = QueryReasonDtls.processInboundRequest(paramString, l_event_type, key);
				
				l_app_msg = " ::: Inside CancelledApptTrans responseTxt ::: "+responseTxt;
				if (l_debug_YN.equals("Y"))	
					System.out.println(l_app_msg);


		} catch (Exception exp) {
			exp.printStackTrace(System.err);
		}
		return responseTxt;
	}	
	
	public Response.Status responseCode(String code){
		if (code.equals("200")) {
			return Response.Status.OK;
		} else if (code.equals("400")) {
			return Response.Status.BAD_REQUEST;
		} else if (code.equals("401")) {
			return Response.Status.UNAUTHORIZED;
		} else if (code.equals("403")) {
			return Response.Status.FORBIDDEN;
		} else  {
			return Response.Status.INTERNAL_SERVER_ERROR;
		}
	}
	
	private String EMPaymentTransaction(String paramString, String requestType,String key){
		String responseTxt = "";		
		
		try {
			
				l_app_msg = "::: Inside EMPaymentTransaction ::: ";
				if (l_debug_YN.equals("Y"))	
					System.out.println(l_app_msg);
				
				l_app_msg = "::: Inside EMPaymentTransaction paramString ::: "+paramString;
				if (l_debug_YN.equals("Y"))
					System.out.println(l_app_msg);

				EMPaymentTransaction QHISTrans = new EMPaymentTransaction();
	
				responseTxt = QHISTrans.processInboundPaymentRequest(paramString, requestType, key);
				
				l_app_msg = "::: Inside EMPaymentTransaction responseTxt ::: "+responseTxt;
				if (l_debug_YN.equals("Y"))
					System.out.println(l_app_msg);
	
				if (responseTxt.indexOf("Error") == 0) {
					return responseTxt;
				}

		} catch (Exception exp) {
			System.out.println("(EMPaymentTransaction) Exception occurred : "+exp.getMessage());
			exp.printStackTrace(System.err);
		}
		
		return responseTxt;
	}


}
