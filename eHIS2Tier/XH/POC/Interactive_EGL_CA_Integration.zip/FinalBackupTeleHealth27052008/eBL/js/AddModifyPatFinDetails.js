var valid_from ="";
var valid_upto ="";
var cust_name = "";
var doc_reference = "";

function callSettlements(Obj)
{
	try
	{
		var obj2 = document.forms(0).ins_auth_flag;
		var obj3 = document.forms(0).clinic_code;
		var obj4 = document.forms(0).visit_type_code;
		var obj5 = document.forms(0).show_hide_blng_class;
		var obj6 = document.forms(0).bl_data_from_repos_yn;
		var obj7 = document.forms(0).items_disabled;
		var obj8 = document.forms(0).calling_module_id;
		var obj9 = document.forms(0).ext_settl_type;	

		var obj10 = document.forms(0).patient_id;		
		parent.frames(1).location.href='../../eBL/jsp/AddModifyPatFinDetails6.jsp?billing_group='+Obj.value+'&ins_auth_flag='+obj2.value+'&clinic_code='+obj3.value+'&visit_type_code='+obj4.value+'&show_hide_blng_class='+obj5.value+'&bl_data_from_repos_yn='+obj6.value+'&items_disabled='+obj7.value+'&calling_module_id='+obj8.value+'&id_fun=1&set_typ_from_frame1='+obj9.value+'&patient_id='+obj10.value+"&valid_from="+valid_from+"&valid_upto="+valid_upto+"&cust_name="+cust_name+"&doc_reference="+doc_reference;
		
//		alert(valid_from + "6");
//		alert(valid_upto + "6");
	}
	catch(e)
	{
	}

}

function callNonInsurance(Obj)
{
	try
	{
		var obj6 = document.forms(0).bl_data_from_repos_yn.value;
		var obj7 = document.forms(0).items_disabled.value;
		var obj8 = document.forms(0).calling_module_id.value;

	}
	catch(e)
	{
	}
	parent.frames(1).location.href='../../eBL/jsp/AddModifyPatFinDetails7.jsp?non_insur_blng_grp='+Obj.value+
	 '&calling_module_id='+obj8+'&items_disabled='+obj7+'&bl_data_from_repos_yn='+ obj6;

}

function callSettlements1(Obj)
{
	var str = Obj.value;
	var obj=str.substring(0,2);
	parent.frames(1).location.href='../../eBL/jsp/AddModifyPatFinDetails4.jsp?cash_set_type1='+obj;
}

function callNonInsurance1(Obj)
{
	var str = Obj.value;
	var obj=str.substring(0,2);
	parent.frames(1).location.href='../../eBL/jsp/AddModifyPatFinDetails8.jsp?cash_set_type2='+obj;
	
}
function disableObject(obj)
{
	try
	{
		var module_id = parent.frames(0).document.forms(0).calling_module_id.value;
		if (((obj.name == "billing_group") && (module_id == "MP")) || (module_id != "MP"))
		{
			return;
		}
	}
	catch(ex)
	{
	}
	disableCommon(2,obj);	
}

function disableCommon(funCase,obj)
{
	var repos_YN = "";
	var entireValue = "";
	if (funCase == 1)
	{
		repos_YN = document.forms(0).bl_data_from_repos_yn.value;
	}
	else if (funCase == 2)
	{
		repos_YN = parent.frames(0).document.forms(0).bl_data_from_repos_yn.value;
	}
	if (repos_YN == "Y")
	{
		if (funCase == 1)
		{
			entireValue = document.forms(0).items_disabled.value;
		}
		else if (funCase == 2)
		{
			entireValue = parent.frames(0).document.forms(0).items_disabled.value;
		}
			
		var arr = new Array();
		arr = entireValue.split("|");
		indx = arr.length;
		var checkArr = new Array();

		for (i=0;i<indx;i++)
		{
			checkArr = arr[i].split("-");
			if (checkArr.length >1 )
			{
				if (checkArr[1] == "N")
				{
					try
					{	
						if (funCase == 1)
						{	
								var itemDis = checkArr[0];
								var itm = "document.forms(0)."+itemDis;
								objDisable = eval(itm);
								eval('objDisable.disabled=true');
						}
						else if (funCase == 2)
						{
							
							var itemDis2 = checkArr[0];
							var itemDis1 = obj.name;
							if (itemDis1 == itemDis2)
							{
								eval('obj.disabled=true');
							} 
						}
					}
					catch(e)
					{
							
					}
				}
			}
		}
	}
}


function disableMappingItems()
{

	var obj = new Object();
	disableCommon(1,obj);	
}
function showBillingGrpConfirm()
{
	
	var retVal;
	var dialogHeight= "9" ;
	var dialogWidth	= "22" ;
	var dialogTop = "225" ;
	var center = "1" ;														   
	var status="no";
	var features	= "dialogHeight:" + dialogHeight + "; dialogWidth:" + dialogWidth + "; center: " + center + "; status: " + status + "; dialogTop :" + dialogTop;
	var arguments	= "" ;
	retVal = window.showModalDialog("../../eBL/jsp/BLBillingGroupConfirm.jsp",arguments,features);
	return(retVal);

}
function authScr(obj)
{	
	var retVal;
	var dialogHeight= "14" ;
	var dialogWidth	= "22" ;
	var dialogTop = "225" ;
	var center = "1" ;														   
	var status="no";
	var features	= "dialogHeight:" + dialogHeight + "; dialogWidth:" + dialogWidth + "; center: " + center + "; status: " + status + "; dialogTop :" + dialogTop;
	var arguments	= "" ;	
	if(parent.parent.frames(1).name=="package_frame")
	{
		
		retVal = window.showModalDialog("../../eBL/jsp/BLFinDetailsAuthoriseMain.jsp?mode=s",arguments,features);
	}
	else if(parent.parent.frames(1).name=="MainFrame2")
	{
		
		retVal = window.showModalDialog("../../eBL/jsp/BLFinDetailsAuthoriseMain.jsp?mode="+obj+"",arguments,features);
	}
	if(retVal==null) retVal="";
	if(retVal.length>0)
	{		
		if(retVal[0] == "Y")
		{
			
			enableAllElements();
			var bill_grp=parent.frames(0).document.forms(0).billing_group;
			var upd_fin_dtls=parent.frames(0).document.forms(0).upd_fin_dtls;
			var remarks=parent.frames(0).document.forms(0).remarks;
			var user_id=parent.frames(0).document.forms(0).user_id;
			upd_fin_dtls.value=retVal[1];
			remarks.value=retVal[2];
			user_id.value=retVal[3];
			try
			{
				bill_grp.focus();
			}
			catch(e)
			{
			}
			
			parent.frames(0).document.forms(0).modify_button.disabled=true;



			try
			{
				// Added on May'10'2004 for the HMC disabling even after auth.
				var bl_data_from_repos_yn = document.forms(0).bl_data_from_repos_yn.value;
				var calling_module_id = document.forms(0).calling_module_id.value;

				if (  (bl_data_from_repos_yn == 'Y')  && ( calling_module_id == 'MP') )
				{
					document.forms(0).blnggrpbut.disabled = true;
					try
					{
						parent.frames(1).frames(0).document.forms(0).cust1but.disabled=true;
					}
					catch(e)
					{

					}

				}
			}
			catch(e)
			{
			}










			
		}
	}
	
	return retVal;
}


function getPolicySearch()
{
	var cust=document.forms(0).cust_3.value;
	var polty_cd=document.forms(0).policy_type.value;
	var clinic_cd=document.forms(0).clinic_code.value;
	var visit_cd=document.forms(0).visit_type_code.value;
	if(polty_cd=="select")polty_cd="";

	if(cust=="")
	{
		document.forms(0).cust_3.focus();

	}
	else if(polty_cd=="")
	{
		document.forms(0).policy_type.focus();
	}
	if((cust!="")&&(polty_cd!=""))
	{
		var retVal;
		var dialogHeight= "23" ;
		var dialogWidth	= "40" ;
		var dialogTop = "180" ;
		var center = "1" ;														   
		var status="no";
		var features	= "dialogHeight:" + dialogHeight + "; dialogWidth:" + dialogWidth + "; center: " + center + "; status: " + status + "; dialogTop :" + dialogTop;
		var arguments	= "" ;
		var url = "../../eBL/jsp/BLPolicyDetailsMain.jsp?cust_code="+cust+"&policy_code="+escape(polty_cd)+"&clinic_code="+clinic_cd+"&visit_type_code="+visit_cd+"";
		retVal = window.showModalDialog(url,arguments,features);
	}
	
}


function checkForValidFrames4()
{
	var url = parent.frames(1).frames(1).location.href;
	url = url.toLowerCase();
	
	if ( (url.indexOf("blank.html")==-1))
		return true;
	else
		return false;
}

function checkForValidFrames8()
{
	var url = parent.frames(1).frames(1).frames(1).location.href;
	url = url.toLowerCase();
	
	if ( (url.indexOf("blank.html")==-1))
		return true;
	else
		return false;
}

function checkForValidFrames3()
{
	var url = parent.frames(1).frames(1).frames(0).location.href;
	url = url.toLowerCase();
	
	if ( (url.indexOf("blank.html")==-1))
		return true;
	else
		return false;
}

function sendBackFinDetails()
{
	var rtn_bil_grp="";
	var rtn_bil_cls="";
	var rtn_emp="";
	var rtn_cshst_typ1="";
	var rtn_chinst_ref1="";
	var rtn_chinst_dt1="";
	var rtn_chinst_rmk1="";
	var rtn_cust_1="";
	var rtn_cred_ref1="";
	var rtn_cred_dt1="";
	var rtn_cred_start_dt1="";
	var rtn_cust_2="";
	var rtn_cred_ref2="";
	var rtn_cred_dt2="";
	var rtn_cred_start_dt2="";
	var rtn_cust_3="";
	var rtn_poly_typ="";
	var rtn_poly_no="";
	var rtn_poexp_dt="";
	var rtn_nonins_blgrp="";
	

	var rtn_cshst_typ2="";
	var rtn_chinst_ref2="";
	var rtn_chinst_dt2="";
	var rtn_chinst_rmk2="";
	var rtn_cust_4="";
	var rtn_cred_ref3="";
	var rtn_cred_st_dt3="";
	var rtn_cred_dt3="";

	var rtn_cred_start_dt3="";
	var rtn_setlmt_ind="";
	var rtn_upd_fin_dtls="";
	var rtn_ins_auth_flag="";
	var rtn_credit_auth_ref="";
	var rtn_credit_auth_date="";
	var rtn_app_days="";
	var rtn_app_amount="";
	var rtn_eff_frm_date="";
	var rtn_user_id="";
	var HideChk="";
	var chkCashSet1="";
	var chkCashSet2="";
	var captureemployeridyn="";
	/****** 
			The following fields are introduced by 
			Murugavel for the enhancements on the
			Gap Analysis. 
			Date 	: 11/Aug/2002
	********/

	var rtn_annual_income =  "";		// Parent Frames (0)
	var rtn_family_asset  = "";		// Parent Frames (0)
	var chk_credit_doc_yn1 = "";
	var chk_credit_doc_yn2 = "";		// For the Last Frame 
	var chk_health_card_exp_yn = "";
	var temp_dflt_blng_grp = "";
	var temp_dflt_blng_desc = "";
	var rtn_no_of_dependants = "";			
	var rtn_resp_for_payment = "";
	var rtn_gl_holder_name = "";	
	var rtn_pat_reln_with_gl_holder = "";	
	var rtn_credit_doc_reqd_yn1 = "";
	var rtn_credit_doc_reqd_yn2 = "";		// For the Last Frame 
	var rtn_attend_practitioner_id="";
	var calling_module_id = parent.frames(0).document.forms(0).calling_module_id.value;
//alert("calling_module_id==>" +calling_module_id);
	var temp_blng_class =  parent.frames(0).document.forms(0).temp_blng_class.value;
	var temp_bill_type =  parent.frames(0).document.forms(0).temp_bill_type.value;

	var calling_function_id = parent.frames(0).document.forms(0).function_id.value;
	var boolPatientFound = parent.frames(0).document.forms(0).patient_found.value;
	
	var bed_class_code  = parent.frames(0).document.forms(0).bed_class_code.value;
	var visit_adm_type  = parent.frames(0).document.forms(0).visit_adm_type.value;
	var nursing_unit_code = parent.frames(0).document.forms(0).nursing_unit_code.value;
	var dept_code = parent.frames(0).document.forms(0).dept_code.value;

	var blInterface = parent.frames(0).document.forms(0).bl_interfaced_yn.value;
	

	var bl_oper_yn = parent.frames(0).document.forms(0).bl_oper_yn.value;
	
	/** End Murugavel**/
	
	rtn_bil_grp		= parent.frames(0).document.forms(0).billing_group.value;
	rtn_bil_cls		= parent.frames(0).document.forms(0).billing_class.value;
	rtn_emp		= parent.frames(0).document.forms(0).employer_code.value;
	

	if (parent.frames(0).document.forms(0).capture_employer_id_yn)
		captureemployeridyn = parent.frames(0).document.forms(0).capture_employer_id_yn.value;
	else
		captureemployeridyn = "N";

	rtn_remarks		= parent.frames(0).document.forms(0).remarks.value;
	rtn_upd_fin_dtls= parent.frames(0).document.forms(0).upd_fin_dtls.value;
	rtn_user_id= parent.frames(0).document.forms(0).user_id.value;
	HideChk= parent.frames(0).document.forms(0).show_hide_blng_class.value;

	/** 
		The following codes are Enhancements
		ON 11/AUG/2002
	**/
			
	rtn_annual_income =  parent.frames(0).document.forms(0).annual_income.value;		// Parent Frames (0)
	//Commented on 26/10/2004 to pass value as null to the number columns if not entered.
	//if (rtn_annual_income==null || rtn_annual_income=="") rtn_annual_income = "0";
	rtn_family_asset  = parent.frames(0).document.forms(0).family_asset.value;		// Parent Frames (0) 
	rtn_attend_practitioner_id  = parent.frames(0).document.forms(0).attend_practitioner_id.value;		// Parent Frames (0) 
//	alert("rtn_attend_practitioner_id==>" +rtn_attend_practitioner_id);
	//if (rtn_family_asset==null  || rtn_family_asset=="") rtn_family_asset = "0";
	rtn_no_of_dependants = parent.frames(0).document.forms(0).no_of_dependants.value;		// Parent Frames (0) 
	//if (rtn_no_of_dependants==null  || rtn_no_of_dependants=="") rtn_no_of_dependants = "0";
	rtn_resp_for_payment = parent.frames(0).document.forms(0).resp_for_payment.value;		// Parent Frames (0) 
	if (rtn_resp_for_payment==null) rtn_resp_for_payment = "";

	
	
	var v_third_party_gl_in_use_yn = parent.frames(0).document.forms(0).third_party_gl_in_use_yn.value;		// Parent Frames (0) 
	
	if (v_third_party_gl_in_use_yn == null) v_third_party_gl_in_use_yn = "N";

	var v_third_party_gl_mandatory_yn = parent.frames(0).document.forms(0).third_party_gl_mandatory_yn.value;		// Parent Frames (0) 

	if (v_third_party_gl_mandatory_yn == null) v_third_party_gl_mandatory_yn = "N";

	if (v_third_party_gl_in_use_yn == "Y")
	{	
	rtn_gl_holder_name = parent.frames(0).document.forms(0).gl_holder_name.value;		// Parent Frames (0) 
	}
	
   
	if (rtn_gl_holder_name==null) rtn_gl_holder_name = "";

	if (v_third_party_gl_in_use_yn == "Y")
    {
	rtn_pat_reln_with_gl_holder = parent.frames(0).document.forms(0).pat_reln_with_gl_holder.value;		// Parent Frames (0) 
	}
	if (rtn_pat_reln_with_gl_holder==null) rtn_pat_reln_with_gl_holder = "";	

	

	
	special_scheme_appl = parent.frames(0).document.forms(0).special_scheme_appl.value;		
	special_scheme_blng_grp = parent.frames(0).document.forms(0).special_scheme_blng_grp.value;		
	

	alt_id1_exp_date = parent.frames(0).document.forms(0).alt_id1_exp_date.value;		

	
	var bed_no = 	parent.frames(0).document.forms(0).bed_no.value;

	//parent.frames(3).location.href='../../eBL/jsp/BLValidation.jsp';

	try
	{
		if ( (calling_module_id == "OP" ||calling_module_id == "AE" ) && (bl_oper_yn == 'Y')  )
		{
			if (temp_blng_class == null || temp_blng_class == ""|| temp_blng_class == " " )
			{
				alert(getMessage("BL1130"));
				return(false);
			}

			if (temp_bill_type == null || temp_bill_type== ""|| temp_bill_type== " " )
			{
				alert(getMessage("BL1130"));
				return(false);
			}
		}

//Commented on 27/10/2004 
//	if ( (blInterface == 'Y') &&(calling_module_id == "IP" || calling_module_id == "DC") )
//Comment Ends
		if ( (bl_oper_yn == 'Y') &&(calling_module_id == "IP" || calling_module_id == "DC") )
		{

			if ( (bed_no != null) && (bed_no !="") && (bed_no !=" ") )
			{
				if (temp_blng_class == null || temp_blng_class == ""|| temp_blng_class == " " )
				{
					alert(getMessage("BL9206"));
					return(false);
				}
			}
				if (temp_bill_type == null || temp_bill_type== ""|| temp_bill_type== " " )
				{
					alert(getMessage("BL9202"));
					return(false);
				}
				if (dept_code == null)
				{
					alert(getMessage("BL1184"));
					return(false);
				}

			if ( (sys_message_id != null) )
			{
				if ( (sys_message_id !="" ) && (sys_message_id !='null') )
				{
					alert("*** "+sys_message_id + "***"+getMessage(sys_message_id));
					return(false);

				}
			}

		}
	}
	catch(es)
	{
	}


	
	//var varBillingApp = parent.frames(0).document.forms(0).blng_applicable_yn.value;
	var varBillingApp = parent.frames(0).document.forms(0).blnggrpappyn.value;		
	var indx = parent.frames(0).document.forms(0).billing_group.selectedIndex;

	if (rtn_bil_grp != "" && varBillingApp == 'N' )
	{
		//alert(getMessage("BL0195"));
			alert(getMessage("BL1523"));		
			return(false);	
	}

	var vblnggrpstatus = parent.frames(0).document.forms(0).BlngGrpStatus.value;		


	if (rtn_bil_grp != "" && vblnggrpstatus == 'S' )
	{
			alert(getMessage("BL0026"));		
			return(false);	
	}

	var vblnggrpcatgappyn = parent.frames(0).document.forms(0).blnggrpcatgappyn.value;		


	if (rtn_bil_grp != "" && vblnggrpcatgappyn == 'N' )
	{
			alert(getMessage("BL1524"));		
			return(false);	
	}

	


	var arr = new Array();
	arr = varBillingApp.split("|");
	indx = indx-1;

	/*
	if (indx>=0)
	{
		
		if (arr[indx] == 'Y') 
		{
			//return(true);
		}
		else
		{
			alert(getMessage("BL0195"));
			return(false);
		}
	}
	*/
	
	if(rtn_bil_grp=="")
	{
		//alert("APP-000001 Billing Group cannot be blank");
		alert(getMessage("BL9301"));
		return false;
	}
	if((rtn_bil_cls == "") && (calling_function_id=="VISIT_REGISTRATION"))
	{
	}
	/******* The following added for enhancements***/
	if ( (special_scheme_appl != 'N') && (calling_module_id != "MP" ) )
	{
		
		if (rtn_bil_grp != special_scheme_blng_grp)
		{
			alert(getMessage("BL9305"));
			return(false);
		}
	}
	
	rtn_setlmt_ind = parent.frames(1).frames(0).document.forms(0).setlmt_ind.value;

	if (rtn_setlmt_ind==null) rtn_setlmt_ind ="";

	if (rtn_setlmt_ind != "C")
	{

		if (v_third_party_gl_in_use_yn == "Y" && v_third_party_gl_mandatory_yn == "Y"  && rtn_gl_holder_name == "")
		{
			alert('Gaurantee Letter Holder Name cannot be blank');
			return(false);
		}

		if (v_third_party_gl_in_use_yn == "Y" && v_third_party_gl_mandatory_yn == "Y"  && rtn_pat_reln_with_gl_holder == "")
		{
			alert('Relationship with Gaurantee Letter Holder cannot be blank');
			return(false);
		}

		if (v_third_party_gl_in_use_yn == "Y" && 
			rtn_pat_reln_with_gl_holder != "" && rtn_gl_holder_name == "")
		{
			alert('Gaurantee Letter Holder Name cannot be blank');
			return(false);
		}

		if (v_third_party_gl_in_use_yn == "Y" && 
			rtn_gl_holder_name != "" && rtn_pat_reln_with_gl_holder == "")
		{
			alert('Relationship with Gaurantee Letter Holder cannot be blank');
			return(false);
		}
	}
	


	if (HideChk=="SHOW" )
	{
		if (rtn_setlmt_ind == "C" )
		{
			try
			{
				rtn_cshst_typ1	= parent.frames(1).frames(0).document.forms(0).cash_set_type1.value;
			    chkCashSet1=rtn_cshst_typ1.substring(2);
	    		rtn_cshst_typ1=rtn_cshst_typ1.substring(0,2);
				
			}
			catch(ex)
			{
			}				
		var	chk_credit_doc_yn1 = parent.frames(1).frames(0).document.forms(0).credit_doc_reqd_yn1.value;
		rtn_credit_doc_reqd_yn1	= chk_credit_doc_yn1;
		if (chk_credit_doc_yn1 == "Y")
		{
			
			rtn_cred_ref1 = parent.frames(1).frames(0).document.forms(0).credit_doc_ref1.value;
			rtn_cred_dt1  = parent.frames(1).frames(0).document.forms(0).credit_doc_date1.value;			
			rtn_cred_start_dt1  = parent.frames(1).frames(0).document.forms(0).credit_doc_start_date1.value;	
		}

			var returnArray = new Array (rtn_bil_grp,rtn_bil_cls,rtn_emp,rtn_cshst_typ1,
				rtn_chinst_ref1,rtn_chinst_dt1,rtn_chinst_rmk1,rtn_cust_1,
				rtn_cred_ref1,rtn_cred_dt1,rtn_cust_2,rtn_cred_ref2,rtn_cred_dt2,rtn_cust_3,rtn_poly_typ,rtn_poly_no,rtn_poexp_dt,rtn_nonins_blgrp,rtn_cshst_typ2,rtn_chinst_ref2,rtn_chinst_dt2,rtn_chinst_rmk2,rtn_cust_4,rtn_cred_ref3,rtn_cred_dt3,
				rtn_setlmt_ind,rtn_upd_fin_dtls,rtn_credit_auth_ref,rtn_credit_auth_date,
				rtn_app_days,rtn_app_amount,rtn_annual_income,rtn_family_asset,
				rtn_no_of_dependants, rtn_resp_for_payment, 
				rtn_credit_doc_reqd_yn1, rtn_credit_doc_reqd_yn2,
				rtn_eff_frm_date,rtn_remarks,rtn_user_id,
				rtn_cred_start_dt1,
				rtn_cred_start_dt2,
				rtn_cred_start_dt3,
				rtn_gl_holder_name,
				rtn_pat_reln_with_gl_holder,rtn_attend_practitioner_id);


			if(chk_credit_doc_yn1 =="Y")
		    {
	
			if(rtn_cred_ref1=="")
			{
				alert(getMessage("BL9302"));
				return false;
			}			

			if(rtn_cred_start_dt1=="")
			{
				alert(getMessage("BL1531"));
				return false;
			}
			if(rtn_cred_dt1=="")
			{
				alert(getMessage("BL1532"));
				return false;
			}


			}

	
			parent.window.returnValue=returnArray;
			parent.window.close();			
 			return true;
		}

	}

	var mode=parent.frames(1).frames(0).document.forms(0).Case.value;
	rtn_ins_auth_flag = parent.frames(1).frames(0).document.forms(0).ins_auth_flag.value;

	//Case:1
	if(mode=="1")
	{
		
		rtn_cshst_typ1	= parent.frames(1).frames(0).document.forms(0).cash_set_type1.value;
		chkCashSet1=rtn_cshst_typ1.substring(2);
		rtn_cshst_typ1=rtn_cshst_typ1.substring(0,2);
	}

	// Case:1.0 The Cash Settlement specific.
	/*****	
		The following condition is added
		by Murugavel on 11/Aug/2002
	****/

	if (mode == "1")
	{
		
		chk_credit_doc_yn1 = parent.frames(1).frames(0).document.forms(0).credit_doc_reqd_yn1.value;
		rtn_credit_doc_reqd_yn1	= chk_credit_doc_yn1;

		if (chk_credit_doc_yn1 == "Y")
		{
			
			rtn_cred_ref1 = parent.frames(1).frames(0).document.forms(0).credit_doc_ref1.value;
			rtn_cred_dt1  = parent.frames(1).frames(0).document.forms(0).credit_doc_date1.value;			
			rtn_cred_start_dt1  = parent.frames(1).frames(0).document.forms(0).credit_doc_start_date1.value;	
		}
	}
	/*** End ****/
	
	//Case:1.1
//	alert("mode==>" +mode);
	if((mode != "4")&&(chkCashSet1!="Y"))
	{
		if(checkForValidFrames4())
		{
			rtn_chinst_ref1 = parent.frames(1).frames(1).document.forms(0).cash_insmt_ref1.value;
			rtn_chinst_dt1  = parent.frames(1).frames(1).document.forms(0).cash_insmt_date1.value;
			rtn_chinst_rmk1 = parent.frames(1).frames(1).document.forms(0).cash_insmt_rmks1.value;
		}
	}
	
	
	//Case:2
	if(mode=="2")
	{
		rtn_cust_1    = parent.frames(1).frames(0).document.forms(0).cust_1.value;
		rtn_cred_ref1 = parent.frames(1).frames(0).document.forms(0).credit_doc_ref1.value;
		rtn_cred_dt1  = parent.frames(1).frames(0).document.forms(0).credit_doc_date1.value;
		rtn_cred_start_dt1  = parent.frames(1).frames(0).document.forms(0).credit_doc_start_date1.value;		
	}

	//Case:3
	if(mode=="3")
	{
		rtn_cust_2		= parent.frames(1).frames(0).document.forms(0).cust_2.value;
		rtn_cred_ref2	= parent.frames(1).frames(0).document.forms(0).credit_doc_ref2.value;
		rtn_cred_dt2	= parent.frames(1).frames(0).document.forms(0).credit_doc_date2.value;
		rtn_cred_start_dt2  = parent.frames(1).frames(0).document.forms(0).credit_doc_start_date2.value;				
	}

	//Case:4
	if(mode=="4")
	{
		rtn_cust_3		   = parent.frames(1).frames(0).document.forms(0).cust_3.value;
		rtn_poly_typ	   = parent.frames(1).frames(0).document.forms(0).policy_type.value;
		rtn_poly_no		   = parent.frames(1).frames(0).document.forms(0).policy_no.value;
		rtn_poexp_dt	   = parent.frames(1).frames(0).document.forms(0).policy_expiry_date.value;
		rtn_nonins_blgrp   = parent.frames(1).frames(0).document.forms(0).non_insur_blng_grp.value;
		rtn_emp   = parent.frames(0).document.forms(0).employer_code.value;

		var noninsblnggrpappyn	   = parent.frames(1).frames(0).document.forms(0).blnggrpappyn.value;
		var noninsblnggrpcatgappyn   = parent.frames(1).frames(0).document.forms(0).blnggrpcatgappyn.value;
		var noninsblnggrpstatus	   = parent.frames(1).frames(0).document.forms(0).BlngGrpStatus.value;
		
		if(rtn_ins_auth_flag=="Y")
		{
			rtn_credit_auth_ref = parent.frames(1).frames(0).document.forms(0).credit_auth_ref.value;
			rtn_credit_auth_date= parent.frames(1).frames(0).document.forms(0).credit_auth_date.value;
			rtn_app_days=parent.frames(1).frames(0).document.forms(0).app_days.value;
			rtn_app_amount=parent.frames(1).frames(0).document.forms(0).app_amount.value;
			rtn_eff_frm_date=parent.frames(1).frames(0).document.forms(0).eff_frm_date.value;
		}

	}
	if(mode=="4")
	{
		
		if(rtn_emp=="" && captureemployeridyn == "Y" ) 
		{
			alert("APP-000001 Employer cannot be blank for Insurance type of Settlement");
			//alert(getMessage("BL9102"));
			return false;
		}
		if(rtn_cust_3=="")
		{
			//alert("APP-000001 Customer cannot be blank");
			alert(getMessage("BL9102"));
			return false;
		}
		if(rtn_poly_typ=="" || rtn_poly_typ=="select")
		{
			//alert("APP-000001 Policy Type cannot be blank");
			alert(getMessage("BL9103"));
			return false;
		}
		 
		if(rtn_poly_no=="")	
		{
			//alert("APP-000001 Policy No cannot be blank");
			alert(getMessage("BL9104"));
			return false;
		}
		if(rtn_poexp_dt=="")
		{
			//alert("APP-000001 Policy Expiry Date cannot be blank");
			alert(getMessage("BL9105"));
			return false;
		}
		if(rtn_nonins_blgrp=="")
		{
			//alert("APP-000001 Non Insurance Billing Group cannot be blank");
			alert(getMessage("BL9106"));
			return false;
		}

		if (rtn_nonins_blgrp != "" && noninsblnggrpappyn == 'N' )
		{		
				alert(getMessage("BL1527"));		
				return(false);	
		}


		if (rtn_nonins_blgrp != "" && noninsblnggrpstatus == 'S' )
		{
				alert(getMessage("BL1530"));		
				return(false);	
		}


		if (rtn_nonins_blgrp != "" && noninsblnggrpcatgappyn == 'N' )
		{
				alert(getMessage("BL1528"));		
				return(false);	
		}



	}

	//Case:4.1
	/*************** 
			The following code is added on 11/aug/2002
	Single Line		chk_credit_doc_yn2 = parent.frames(1).frames(1).frames(0).document.forms(0).credit_doc_yn.value;	
	****************/


	if(mode=="4")
	{
		var mode2 = parent.frames(1).frames(1).frames(0).document.forms(0).Case_1.value;
		chk_credit_doc_yn2 = parent.frames(1).frames(1).frames(0).document.forms(0).credit_doc_reqd_yn2.value;
		rtn_credit_doc_reqd_yn2 = chk_credit_doc_yn2;
		if (chk_credit_doc_yn2 == "Y")
		{
			rtn_cred_ref3	= parent.frames(1).frames(1).frames(0).document.forms(0).credit_doc_ref3.value;
			rtn_cred_dt3	= parent.frames(1).frames(1).frames(0).document.forms(0).credit_doc_date3.value;
			rtn_cred_start_dt3	= parent.frames(1).frames(1).frames(0).document.forms(0).credit_doc_st_date3.value;

		}
	}
	/**    End of the Code ***/

	
	if((mode=="4")&&(mode2=="2"))
	{
		rtn_cshst_typ2 = parent.frames(1).frames(1).frames(0).document.forms(0).cash_set_type2.value;
		chkCashSet2=rtn_cshst_typ2.substring(2);
		rtn_cshst_typ2=rtn_cshst_typ2.substring(0,2);
		
	}
	//Case:4.1.1
	if(mode=="4")
	{
		if(checkForValidFrames8() && (chkCashSet2 != "Y"))
		{
			rtn_chinst_ref2 = parent.frames(1).frames(1).frames(1).document.forms(0).cash_insmt_ref2.value;
			rtn_chinst_dt2  = parent.frames(1).frames(1).frames(1).document.forms(0).cash_insmt_date2.value;
			rtn_chinst_rmk2 = parent.frames(1).frames(1).frames(1).document.forms(0).cash_insmt_rmks2.value;
		}
	}
	
	//Case:4.2
	if((mode=="4")&&(mode2=="1"))
	{
		rtn_cust_4		= parent.frames(1).frames(1).frames(0).document.forms(0).cust_4.value;
		rtn_cred_ref3	= parent.frames(1).frames(1).frames(0).document.forms(0).credit_doc_ref3.value;
		rtn_cred_dt3	= parent.frames(1).frames(1).frames(0).document.forms(0).credit_doc_date3.value;
		rtn_cred_start_dt3 = parent.frames(1).frames(1).frames(0).document.forms(0).credit_doc_st_date3.value;
	}

	

	if((rtn_bil_cls == "") && (HideChk=="SHOW"))
	{
		
	}
	if(rtn_bil_grp=="")
	{
		//alert("APP-000001 Billing Group cannot be blank");
		alert(getMessage("BL9301"));
		return false;
	}
	if(mode=="1")
	{
		if(rtn_cshst_typ1=="")
		{
			//alert("APP-000001 Cash Settlement Type cannot be blank");
			alert(getMessage("BL9107"));
			return false;
		}
		
		if(chkCashSet1!="Y" )
		{
			if(rtn_chinst_ref1=="")
			{
				//alert("APP-000001 Cash Instrument Ref cannot be blank");
				alert(getMessage("BL9108"));
				return false;
			}
			if(rtn_chinst_dt1=="")
			{
				//alert("APP-000001 Cash Instrument Date cannot be blank");
				alert(getMessage("BL9109"));
				return false;
			}
		}
		/***
			The following code is added 
			by Murugavell
			for the enhancements on 11/Aug/2002
		*****/
		if(chk_credit_doc_yn1 =="Y")
		{
	
			if(rtn_cred_ref1=="")
			{
				alert(getMessage("BL9302"));
				return false;
			}

			
			if(rtn_cred_start_dt1=="")
			{
				alert(getMessage("BL1531"));
				return false;
			}

			if(rtn_cred_dt1=="")
			{
				alert(getMessage("BL1532"));
				return false;
			}
			
				
		}
		/*** 
			End of the Code
		***/
	}
	else if(mode=="2")
	{
		
		if(rtn_cust_1=="")
		{
			alert(getMessage("BL9102"));
			return false;
		}
		if(rtn_cred_ref1=="")
		{
			alert(getMessage("BL9302"));
			return false;
		}

		if(rtn_cred_start_dt1=="")
		{
			alert(getMessage("BL1531"));
			return false;
		}

		if(rtn_cred_dt1=="")
		{
			alert(getMessage("BL1532"));
			return false;
		}

		

	}
	else if(mode=="3")
	{
		
		if(rtn_cust_2=="")
		{
			alert(getMessage("BL9102"));
			return false;
		}
		if(rtn_cred_ref2=="")
		{
			alert(getMessage("BL9302"));
			return false;
		}

		if(rtn_cred_start_dt2=="")
		{
			alert(getMessage("BL1531"));
			return false;
		}

		if(rtn_cred_dt2=="")
		{
			alert(getMessage("BL1532"));
			return false;
		}
		

	}
	else if((mode=="4")&&(mode2=="1"))
	{
		if(rtn_cust_4=="")
		{
			alert(getMessage("BL9102"));
			return false;
		}
		if(rtn_cred_ref3=="")
		{
			//alert("APP-000001 Credit Doc Ref cannot be blank");
			alert(getMessage("BL9302"));
			return false;
		}

		if(rtn_cred_start_dt3=="")	
		{
			//alert("APP-000001 Credit Doc Date cannot be blank");
			alert(getMessage("BL1531"));
			return false;
		}

		if(rtn_cred_dt3=="")	
		{
			//alert("APP-000001 Credit Doc Date cannot be blank");
			alert(getMessage("BL1532"));
			return false;
		}
		
		
	}
	else if((mode=="4")&&(mode2=="2"))
	{
		if(rtn_cshst_typ2=="")
		{
			//alert("APP-000001 Cash Settlement Type cannot be blank");
			alert(getMessage("BL9107"));
			return false;

		}
		if(chkCashSet2 !="Y")
		{
			if(checkForValidFrames8())
			{
				if(rtn_chinst_ref2=="")
				{
					//alert("APP-000001 Cash Instrument Ref cannot be blank");
					alert(getMessage("BL9108"));
					return false;
				}
				if(rtn_chinst_dt2=="")
				{
					//alert("APP-000001 Cash Instrument Date cannot be blank");
					alert(getMessage("BL9109"));
					return false;
				}
				
			}
		}
		/******* 
			The following code is added on 11/Aug/2002
		*******/
		if (chk_credit_doc_yn2=="Y")
		{
			if(rtn_cred_ref3=="")
			{
				//alert("APP-000001 Credit Doc Ref cannot be blank");
				alert(getMessage("BL9302"));
				return false;
			}

			if(rtn_cred_start_dt3=="")	
			{
				//alert("APP-000001 Credit Doc Date cannot be blank");
				alert(getMessage("BL1531"));
				return false;
			}

			if(rtn_cred_dt3=="")	
			{
				//alert("APP-000001 Credit Doc Date cannot be blank");
				alert(getMessage("BL1532"));
				return false;
			}
			
			
		}
		/***** End of the Code ***/
	}

	if(rtn_bil_grp=="")rtn_bil_grp="";
	if(rtn_bil_cls=="")rtn_bil_cls="";
	if(rtn_emp=="")rtn_emp="";
	if(rtn_cshst_typ1=="")rtn_cshst_typ1="";
	if(rtn_chinst_ref1=="")rtn_chinst_ref1="";
	if(rtn_chinst_dt1=="")rtn_chinst_dt1="";
	if(rtn_chinst_rmk1=="")rtn_chinst_rmk1="";
	if(rtn_cust_1=="")rtn_cust_1="";
	if(rtn_cred_ref1=="")rtn_cred_ref1="";
	if(rtn_cred_dt1=="")rtn_cred_dt1="";
	if(rtn_cred_start_dt1=="")rtn_cred_start_dt1="";
	if(rtn_cust_2=="")rtn_cust_2="";
	if(rtn_cred_ref2=="")rtn_cred_ref2="";
	if(rtn_cred_dt2=="")rtn_cred_dt2="";
	if(rtn_cred_start_dt2=="")rtn_cred_start_dt2="";
	if(rtn_cust_3=="")rtn_cust_3="";
	if(rtn_poly_typ=="")rtn_poly_typ="";
	if(rtn_poly_no=="")rtn_poly_no="";
	if(rtn_poexp_dt=="")rtn_poexp_dt="";
	if(rtn_nonins_blgrp=="")rtn_nonins_blgrp="";
	if(rtn_cshst_typ2=="")rtn_cshst_typ2="";
	if(rtn_chinst_ref2=="")rtn_chinst_ref2="";
	if(rtn_chinst_dt2=="")rtn_chinst_dt2="";
	if(rtn_chinst_rmk2=="")rtn_chinst_rmk2="";
	if(rtn_cust_4=="")rtn_cust_4="";
	if(rtn_cred_ref3=="")rtn_cred_ref3="";
	if(rtn_cred_dt3=="")rtn_cred_dt3="";
	if(rtn_cred_st_dt3=="")rtn_cred_st_dt3="";
	if(rtn_cred_start_dt3=="")rtn_cred_start_dt3="";
	if(rtn_upd_fin_dtls=="")rtn_upd_fin_dtls="C";


	try
	{
		
		if (blInterface == null)
		{
			blInterface = "N";
		}
	
		if ((calling_module_id == 'IP' || calling_module_id == 'DC')||  (calling_module_id == 'MP')  ||(blInterface == "N"))
		{

			var returnArray = new Array (rtn_bil_grp,rtn_bil_cls,rtn_emp,rtn_cshst_typ1,
				rtn_chinst_ref1,rtn_chinst_dt1,rtn_chinst_rmk1,rtn_cust_1,
				rtn_cred_ref1,rtn_cred_dt1,rtn_cust_2,rtn_cred_ref2,rtn_cred_dt2,rtn_cust_3,rtn_poly_typ,rtn_poly_no,rtn_poexp_dt,rtn_nonins_blgrp,rtn_cshst_typ2,rtn_chinst_ref2,rtn_chinst_dt2,rtn_chinst_rmk2,rtn_cust_4,rtn_cred_ref3,rtn_cred_dt3,
				rtn_setlmt_ind,rtn_upd_fin_dtls,rtn_credit_auth_ref,rtn_credit_auth_date,
				rtn_app_days,rtn_app_amount,rtn_annual_income,rtn_family_asset,
				rtn_no_of_dependants, rtn_resp_for_payment, 
				rtn_credit_doc_reqd_yn1, rtn_credit_doc_reqd_yn2,
				rtn_eff_frm_date,rtn_remarks,rtn_user_id,
				rtn_cred_start_dt1,
				rtn_cred_start_dt2,
				rtn_cred_start_dt3,
				rtn_gl_holder_name,
				rtn_pat_reln_with_gl_holder);

	
			parent.window.returnValue=returnArray;
			parent.window.close();			
		}
		else if ((calling_module_id == 'OP' || calling_module_id == 'AE') && (blInterface == "Y"))
		{
			
			try
			{
				parent.ValidFrame.document.forms(0).billing_group.value= parent.frames(0).document.forms(0).billing_group.value;
				parent.ValidFrame.document.forms(0).clinic_code.value= parent.frames(0).document.forms(0).clinic_code.value;
				parent.ValidFrame.document.forms(0).visit_type_code.value=  parent.frames(0).document.forms(0).visit_type_code.value;
				parent.ValidFrame.document.forms(0).patient_id.value = parent.frames(0).document.forms(0).patient_id.value;
				parent.ValidFrame.document.forms(0).episode_type.value = parent.frames(0).document.forms(0).episode_type.value;
				parent.ValidFrame.document.forms(0).facility_id.value = parent.frames(0).document.forms(0).facility_id.value;
				parent.ValidFrame.document.forms(0).calling_module_id.value = parent.frames(0).document.forms(0).calling_module_id.value;
				parent.ValidFrame.document.forms(0).logged_user_id.value = parent.frames(0).document.forms(0).logged_user_id.value;
				parent.ValidFrame.document.forms(0).attend_practitioner_id.value = parent.frames(0).document.forms(0).attend_practitioner_id.value;
				if(mode=="2")
				{
					parent.ValidFrame.document.forms(0).cust_code.value = rtn_cust_1;
				}
				else if(mode=="3")
				{
					parent.ValidFrame.document.forms(0).cust_code.value = rtn_cust_2;
				}
				else if(mode=="4")
				{
					parent.ValidFrame.document.forms(0).cust_code.value = rtn_cust_3;
				}
				else
				{
				parent.ValidFrame.document.forms(0).cust_code.value = rtn_cust_1;
				}

				parent.ValidFrame.document.forms(0).non_ins_blng_grp_id.value = rtn_nonins_blgrp;
				parent.ValidFrame.document.forms(0).non_ins_cust_code.value = rtn_cust_3;
			}
			catch(er)
			{
				alert("error="+er);
			}
			parent.frames(3).location.href='../../eBL/jsp/BLValidation.jsp';


			if(parent.ValidFrame.document.forms(0).validated_state.value == 'Y')
			{
				
				var retVal;
				var dialogHeight= "5";
				var dialogWidth	= "25";
				var dialogTop = "210";
				var center = "1" ;														   
				var status="no";
				var features	= "dialogHeight:" + dialogHeight + "; dialogWidth:" + dialogWidth + "; center: " + center + "; status: " + status + "; dialogTop :" + dialogTop;
				var arguments	= "" ;

				
				var visitcharge = parent.ValidFrame.document.forms(0).visitchargeamt.value;				
	
				if (visitcharge != "")
				{				
					var url = "../../eBL/jsp/BLVisitChargeDet.jsp?visitcharge="+visitcharge;				
					retVal = window.showModalDialog(url,arguments,features);
					// Returns 1 for close , 2 for modify
				}
				else
				{
					retVal = "1";				
				}

				if (retVal == "1")				
				{

					var returnArray = new Array (rtn_bil_grp,rtn_bil_cls,rtn_emp,rtn_cshst_typ1,
					rtn_chinst_ref1,rtn_chinst_dt1,rtn_chinst_rmk1,rtn_cust_1,
					rtn_cred_ref1,rtn_cred_dt1,rtn_cust_2,rtn_cred_ref2,rtn_cred_dt2,rtn_cust_3,rtn_poly_typ,rtn_poly_no,rtn_poexp_dt,rtn_nonins_blgrp,rtn_cshst_typ2,rtn_chinst_ref2,rtn_chinst_dt2,rtn_chinst_rmk2,rtn_cust_4,rtn_cred_ref3,rtn_cred_dt3,
					rtn_setlmt_ind,rtn_upd_fin_dtls,rtn_credit_auth_ref,rtn_credit_auth_date,
					rtn_app_days,rtn_app_amount,rtn_annual_income,rtn_family_asset,
					rtn_no_of_dependants, rtn_resp_for_payment, 
					rtn_credit_doc_reqd_yn1, rtn_credit_doc_reqd_yn2,
					rtn_eff_frm_date,rtn_remarks,rtn_user_id,
					rtn_cred_start_dt1,
					rtn_cred_start_dt2,
					rtn_cred_start_dt3,
					rtn_gl_holder_name,
					rtn_pat_reln_with_gl_holder,rtn_attend_practitioner_id);					
					parent.window.returnValue=returnArray;
					parent.window.close();			
				}
				

			}
			else if(parent.ValidFrame.document.forms(0).validated_state.value == 'N')
			{
				
				
				parent.ValidFrame.document.forms(0).start_valid.value = 'Y';				
				parent.ValidFrame.document.forms(0).submit();

				

			}
			
			else if(parent.ValidFrame.document.forms(0).validated_state.value == 'E')
			{
				
				alert(parent.ValidFrame.document.forms(0).error_message.value);			
				
			}

		} // Module ID OP

		}
		catch (e)
		{
			alert('Final Err='+e);
		}
}

function changeOnSelectCustomer(selectObj)
{

	var cust_3 = selectObj.value;
	/********modified for SCR 5279******start 17/03/2008******/
	var id = selectObj.options(selectObj.options.selectedIndex).id;
	var tempCode=id.substring(0,id.indexOf("::"));		
	if(tempCode==cust_3){		
		exp_status=id.substr((id.indexOf("::")+2));		
		if(exp_status=='E' || exp_status=="E") {
			alert(getMessage("BL1533"));
		selectObj.value='';
		var policy_type_code	= 'select';
		var short_desc	= '         ---- Select ----         ';
		var opt=document.createElement('OPTION'); 
		opt.text	=	short_desc; 
		opt.value	=	policy_type_code; 
		document.forms(0).policy_type.add(opt); 
		document.forms(0).policy_type.selectedIndex = 0;
		return false
		}
	}
	/********modified for SCR 5279******end 17/03/2008******/
	var optlength = document.forms(0).policy_type.options.length;


	for (var i=0; i<optlength; i++)
	{
		document.forms(0).policy_type.options.remove("policy_type_code");
	}

	if((cust_3=="") ||(cust_3=="select")) 
	{
		var policy_type_code	= 'select';

		var short_desc	= '         ---- Select ----         ';
		var opt=document.createElement('OPTION'); 
		opt.text	=	short_desc; 
		opt.value	=	policy_type_code; 
		document.forms(0).policy_type.add(opt); 
		document.forms(0).policy_type.selectedIndex = 0;
		return false;
	}

	
	var HTMLVal="<html><body><form name='BLPolicyCodeForm' method='post' action='../../eBL/jsp/BLPolicyCode.jsp'>"+
	"<input type='hidden' name='cust_code' value='"+cust_3+"'>"+
	"</form></body></html>";
	
	parent.parent.frames(2).document.body.insertAdjacentHTML('AfterBegin', HTMLVal);
	parent.parent.frames(2).document.BLPolicyCodeForm.submit();

	return true;
	
	
}

function confirmPasswd(obj)
{
	var usr_id=document.forms(0).user_id;
	var pass_wd=document.forms(0).passwd;
	var rmks=document.forms(0).remarks;

	var upd_fin_dtl=document.forms(0).upd_fin_dtl;

	if(upd_fin_dtl.checked==true)
		upd_fin_dtl.value='Y';
	else
		upd_fin_dtl.value='N';
						
		if(usr_id.value=="")
		{
			alert(getMessage("BL9112"));
			usr_id.focus();
			return false;
		}
		if(pass_wd.value=="")
		{
			alert(getMessage("BL9113"));
			pass_wd.focus();
			return false;
		}

		if(rmks.value=="")
		{
			alert(getMessage("BL9306"));
			rmks.focus();
			return false;
		}
		
		var HTMLVal="<html><body><form name='BLConfirmPassWdForm' method='post' action='../../eBL/jsp/BLConfirmPassWd.jsp'>"+
		"<input type='hidden' name='usr_id' value='"+usr_id.value+"'>"+
		"<input type='hidden' name='pass_wd' value='"+pass_wd.value+"'>"+
		"<input type='hidden' name='upd_fin_dtl' value='"+upd_fin_dtl.value+"'>"+
		"<input type='hidden' name='remarks' value='"+rmks.value+"'>"+
		"</form></body></html>";
		parent.frames(1).document.body.insertAdjacentHTML('AfterBegin', HTMLVal);
		parent.frames(1).document.BLConfirmPassWdForm.submit();
		return true;
	//}
}

function enableAllElements()
{
	var len = parent.frames.length;
	var chkCashSet1="";
	var chkCashSet2="";
	var Case="0";	
	if(parent.frames(0).location.href.indexOf("AddModifyPatFinDetails.jsp")!=-1)
	{
	
		if(parent.frames(0).name=="MainFrame1")
		{

			var no_of_ele5=parent.frames(0).document.forms(0).elements.length;
			for(var j=0;j<no_of_ele5;j++)
			{				
				parent.frames(0).document.forms(0).elements(j).disabled=false;
				disableObject(parent.frames(0).document.forms(0).elements(j));
			}

		}
	}
	//parent.frames(0).document.forms(0).health_card_yn.disabled = true;
	if ( parent.frames(1).frames.length >0 )
	{
		if(parent.frames(1).frames(0).location.href.indexOf("AddModifyPatFinDetails2.jsp")!=-1)
		{
			if(parent.frames(1).frames(0).name=="Frame61")
			{
				var no_of_ele2=parent.frames(1).frames(0).document.forms(0).elements.length;
				for(var j=0;j<no_of_ele2;j++)
				{
					parent.frames(1).frames(0).document.forms(0).elements(j).disabled=false;
					disableObject(parent.frames(1).frames(0).document.forms(0).elements(j));

				}
			}
		}
	try
		{
			
			Case=parent.frames(1).frames(0).document.forms(0).Case.value;
		}
	catch (e)
	{
	}

	
	
	if(Case=="1")
	{
		try
		{	
			if (parent.frames(1).frames(0).document.forms(0).cash_set_type1 != null)
			{
				var chk_set_typ=parent.frames(1).frames(0).document.forms(0).cash_set_type1.value
				chkCashSet1=chk_set_typ.substring(2);
				chk_set_typ=chk_set_typ.substring(0,2);
			}
		}
		catch(e2)
		{
		}
		
	}
	if(Case=="1" && chkCashSet1 != "Y")
	{
		try
		{	
		
			if(parent.frames(1).frames.length>1)
			{
				if(parent.frames(1).frames(1).location.href.indexOf("AddModifyPatFinDetails4.jsp")!=-1)
				{
					if(parent.frames(1).frames(1).name=="Frame62")
					{
						var no_of_ele2=parent.frames(1).frames(1).document.forms(0).elements.length;
							for(var j=0;j<no_of_ele2;j++)
						{
							parent.frames(1).frames(1).document.forms(0).elements(j).disabled=false;
							disableObject(parent.frames(1).frames(1).document.forms(0).elements(j));
						}
					}
				}
			}
		}
		catch(e3)
		{
		}
		
	}		
	
	if(Case=="4")
	{
		try
		{
			if ( (parent.frames(1).frames.length)>1)
			{

				if(parent.frames(1).frames(1).frames(0).location.href.indexOf("AddModifyPatFinDetails3.jsp")!=-1)
				{
					if(parent.frames(1).frames(1).frames(0).name=="frame21")
					{
						var no_of_ele3=parent.frames(1).frames(1).frames(0).document.forms(0).elements.length;
						for(var j=0;j<no_of_ele3;j++)
						{
							parent.frames(1).frames(1).frames(0).document.forms(0).elements(j).disabled=false;
							disableObject(parent.frames(1).frames(1).frames(0).document.forms(0).elements(j));
						}
					}
				}
			}
		}
		catch(e5)
		{
		}
	}
	
	if(Case=="4")
	{
		try
		{
	
			var chk_case_1=parent.frames(1).frames(1).frames(0).document.forms(0).Case_1.value;
			var chk_set_typ1="";
			if(chk_case_1=="2")
			{
				chk_set_typ1=parent.frames(1).frames(1).frames(0).document.forms(0).cash_set_type2.value
				chkCashSet2=chk_set_typ1.substring(2);
				chk_set_typ1=chk_set_typ1.substring(0,2);
				
			}
		}
		catch(e6)
		{
		}
	}
	
	if(Case=="4" && chkCashSet2 != "Y")
	{
		try
		{
			if(parent.frames(1).frames(1).frames(1).location.href.indexOf("AddModifyPatFinDetails8.jsp")!=-1)
			{
				if(parent.frames(1).frames(1).frames(1).name=="frame22")
				{
					var no_of_ele4=parent.frames(1).frames(1).frames(1).document.forms(0).elements.length;

					for(var j=0;j<no_of_ele4;j++)
					{
						parent.frames(1).frames(1).frames(1).document.forms(0).elements(j).disabled=false;
						disableObject(parent.frames(1).frames(1).frames(1).document.forms(0).elements(j));
					}
				}
			}
		}
		catch(e7)
		{
		}

	}
	}// End of If for II frame has child frames
}


function disableAllElements()
{
	var len = document.forms(0).elements.length;
	for(var i=0;i<len;i++)
	{
		document.forms(0).elements(i).disabled=true;

	}

	if(document.forms(0).name=="PatFinMainForm")
	{
		document.all.close_button.disabled = false;
		document.all.modify_button.disabled = false;
		document.all.vali_button.disabled = false;
	}
}

function disableModifyButton()
{		
		document.all.modify_button.disabled = true;	
}




function getPackageBill(obj1,obj2,obj3)
{
	
	var retVal;
	var dialogHeight= "30";
	var dialogWidth	= "50";
	var dialogTop = "75" ;
	var center = "1" ;														   
	var status="no";
	
	var pkg_bill_type = obj1;
	var pkg_bill_no = obj2;
	var patient_id = obj3;
	
	

	if (pkg_bill_type.length > 0) 
	{
		var features	= "dialogHeight:" + dialogHeight + "; dialogWidth:" + dialogWidth + "; center: " + center + "; status: " + status + "; dialogTop :" + dialogTop;
		var arguments	= "" ;
		var url = "../../eBL/jsp/dispPackageDetails.jsp?patient_id="+patient_id+"&pkg_bill_type="+pkg_bill_type+"&pkg_bill_no="+pkg_bill_no;
		retVal = window.showModalDialog(url,arguments,features);
		if(retVal==null) retVal="";
			
	}
}

function chkDtLessWithSysDate(entered_date,sys_date) 
{
	if((CheckDate(entered_date)))
	{
		var enteredDateArray; var sysDateArray;
		var enteredDate = entered_date.value ;
		var sysDate = sys_date.value;

		if(enteredDate.length > 0 && sysDate.length > 0 ) 
		{
			enteredDateArray = enteredDate.split("/");
			sysDateArray = sysDate.split("/");
			var enteredDateObject = new Date(enteredDateArray[2],(enteredDateArray[1]-1),enteredDateArray[0]);
			var sysDateObject = new Date(sysDateArray[2],(sysDateArray[1]-1),sysDateArray[0]);	
			if(Date.parse(sysDateObject) < Date.parse(enteredDateObject)) 
			{
				//alert("Entered date cannot be greater than sys date");
				alert(getMessage("BL9114"));
				entered_date.focus();
				entered_date.select();
				/**
				* If the sys_date is less than the entered_date date,
				 * i.e., The Entered date is greater than the Current System Date
				* Then return false to indicate it is wrong..
				*/
				return false;
			}
			else if(Date.parse(sysDateObject) >= Date.parse(enteredDateObject)) return true;
		}	
		return true;
	}
}

function chkDtGreaterWithSysDate(entered_date,sys_date) 
{
	if(!(CheckDate(entered_date)))

	var enteredDateArray; var sysDateArray;
	var enteredDate = entered_date.value ;
	var sysDate = sys_date.value;

	if(enteredDate.length > 0 && sysDate.length > 0 ) 
	{
		enteredDateArray = enteredDate.split("/");
		sysDateArray = sysDate.split("/");
		var enteredDateObject = new Date(enteredDateArray[2],(enteredDateArray[1]-1),enteredDateArray[0]);
		var sysDateObject = new Date(sysDateArray[2],(sysDateArray[1]-1),sysDateArray[0]);	
		if(Date.parse(sysDateObject) > Date.parse(enteredDateObject)) 
		{
			//alert("Entered date cannot be Less than sys date");
			alert(getMessage("BL9115"));
			entered_date.focus();
			entered_date.select();
			/**
			* If the sys_date is greater than the entered_date date,
			* i.e., The Entered date is less than the Current System Date
			* Then return false to indicate it is wrong..
			*/
			return false;
		}
		else if(Date.parse(sysDateObject) <= Date.parse(enteredDateObject)) return true;
	}	
	return true;
}

/** 
	The Following modification is undertaken by Murugavel.
	for the Gap Analysis Enhancements.	on 11/Aug/2002	
***/

function chkDtGreaterThanSysDate(entered_date,sys_date) 
{
	if((CheckDate(entered_date)))
	{

		var enteredDateArray; var sysDateArray;
		var enteredDate = entered_date.value ;
		var sysDate = sys_date.value;
	
		if(enteredDate.length > 0 && sysDate.length > 0 ) 
		{
			enteredDateArray = enteredDate.split("/");
			sysDateArray = sysDate.split("/");
			var enteredDateObject = new Date(enteredDateArray[2],(enteredDateArray[1]-1),enteredDateArray[0]-1);
				var sysDateObject = new Date(sysDateArray[2],(sysDateArray[1]-1),sysDateArray[0]);	
			if(Date.parse(sysDateObject) > Date.parse(enteredDateObject)) 
			{
				//alert("Entered date cannot be Less than sys date");
				alert(getMessage("BL8147"));
				entered_date.focus();
				entered_date.select();
				/**
				* If the sys_date is greater than the entered_date date,
				* i.e., The Entered date is less than the Current System Date
				* Then return false to indicate it is wrong..
				*/
				return false;
			}
			else if(Date.parse(sysDateObject) < (Date.parse(enteredDateObject))) 
			{
				return true;
			}
			else 
			{
				return false;
			}
		}	
		return true;
	}
	else
	{
		return(false);
	}
	
}


function chkDtLessEqualThanSysDate(entered_date,sys_date) 
{
	if((CheckDate(entered_date)))
	{

		var enteredDateArray; var sysDateArray;
		var enteredDate = entered_date.value ;
		var sysDate = sys_date.value;
	
		if(enteredDate.length > 0 && sysDate.length > 0 ) 
		{
			enteredDateArray = enteredDate.split("/");
			sysDateArray = sysDate.split("/");
			var enteredDateObject = new Date(enteredDateArray[2],(enteredDateArray[1]-1),enteredDateArray[0]-1);
				var sysDateObject = new Date(sysDateArray[2],(sysDateArray[1]-1),sysDateArray[0]);	
			if(Date.parse(sysDateObject) <=  Date.parse(enteredDateObject)) 
			{
				//alert("Entered date cannot be Less than sys date");
				alert(getMessage("BL9114"));
				entered_date.focus();
				entered_date.select();
				/**
				* If the sys_date is greater than the entered_date date,
				* i.e., The Entered date is less than the Current System Date
				* Then return false to indicate it is wrong..
				*/
				return false;
			}
			else if(Date.parse(sysDateObject) > (Date.parse(enteredDateObject))) 
			{
				return true;
			}
			else 
			{
				return false;
			}
		}	
		return true;
	}
	else
	{
		return(false);
	}
	
}


function makeUpperCase()
{
	if( (event.keyCode > 96) && (event.keyCode < 123) )
	{
		event.keyCode = event.keyCode - 32;
	}
	return true;
}

function put_decimal(obj)
{
	if(obj.value!='')
	{
	putDecimal(obj,17,2);
	}
}

function callValidation(patid,facid,call_direct)
{
	var dialogTop		= "40";
	var dialogHeight	= "80" ;
	var dialogWidth		= "40" ;
	var features		= "dialogTop:"+dialogTop+"dialogHeight:" + dialogHeight + "; dialogWidth:" + dialogWidth +";status=no" ;
	var arguments		= "" ;

	var strParam = "patient_id="+patid+"&facility_id="+facid;

	var retVal = window.showModalDialog("../../eIP/jsp/ValidateFrameset.jsp?patient_id="+patid+"&facility_id="+facid+"&mode=1&call_direct="+call_direct,arguments,features);

	if(retVal != null)
	{
		var vArray = retVal.split("~");
	
		if(vArray[0] != "")
		{
			document.forms(0).billing_group_desc.value = vArray[1];
			document.forms(0).billing_group.value = vArray[0];
			document.forms(0).arg1.value = vArray[2];
			document.forms(0).arg2.value = vArray[3];
			document.forms(0).arg3.value = vArray[4];
			document.forms(0).arg4.value = vArray[5];
			document.forms(0).arg5.value = vArray[6];
			document.forms(0).arg6.value = vArray[7];
			document.forms(0).arg7.value = vArray[8];
			document.forms(0).arg8.value = vArray[9];
			document.forms(0).arg9.value = vArray[10];
			document.forms(0).arg10.value = vArray[11];
			document.forms(0).arg11.value = vArray[12];
			document.forms(0).arg12.value = vArray[13];
			document.forms(0).arg13.value = vArray[14];
			document.forms(0).arg14.value = vArray[15];
			document.forms(0).arg15.value = vArray[16];
			document.forms(0).arg18.value = vArray[17];
			document.forms(0).arg19.value = vArray[18];
			document.forms(0).valid_from.value = vArray[13];
			document.forms(0).valid_upto.value = vArray[14];

			valid_from		= vArray[13];
			valid_upto		= vArray[14];
			doc_reference	= vArray[5];
			cust_name		= vArray[6];
			document.all.eglid.style.visibility='visible' ;
		}
	}

	funChangeBillingGroup(document.forms(0).billing_group);

}
