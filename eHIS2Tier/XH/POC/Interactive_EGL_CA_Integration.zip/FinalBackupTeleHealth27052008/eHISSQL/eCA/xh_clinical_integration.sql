
Rem
Rem	Script Name 	:	xh_clinical_integration.sql
Rem 
Rem purpose: to create table.
Rem  
Rem         
Rem  DD/MM/YYYY  Created by     

Rem  ----------  -----------    

Rem  06/05/2008  shailabala     

------------------------------------------------------------------------

SET TERM OFF;

SET ECHO OFF;

SET SERVEROUTPUT ON;

SET LINESIZE 2000;

SPOOL xh_clinical_integration.log;


 
PROMPT	creating table XH_CLINICAL_INTEGRATION .

CREATE TABLE xh_clinical_integration
(
 patient_nric_id              VARCHAR2(20),
 session_id                   VARCHAR2(1000),
 sno                          NUMBER,
 header_doc                   CLOB,
 detail_doc                   CLOB,
 xml_valid_header_stauts      VARCHAR2(1)             NOT NULL,
 xml_valid_detail_stauts      VARCHAR2(1)             NOT NULL,
 xml_error_text               CLOB,
 added_by_id                  VARCHAR2(30)            NOT NULL,
 added_date                   DATE                    NOT NULL,
 modified_by_id               VARCHAR2(30)            NOT NULL,
 modified_date                DATE                    NOT NULL,
 added_at_ws_no               VARCHAR2(30)            NOT NULL,
 modified_at_ws_no            VARCHAR2(30)            NOT NULL
)
/
CREATE PUBLIC SYNONYM xh_clinical_integration FOR xh_clinical_integration
/
GRANT DELETE, INSERT, SELECT, UPDATE ON  xh_clinical_integration TO medusers
/

SPOOL OFF;

Rem ================================================================
Rem 	End of the Script
Rem ================================================================
   	
