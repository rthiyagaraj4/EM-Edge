set term off;
set echo off;
set serveroutput on;
            
SPOOL xh_cl_in_up_del.log;


create or replace PROCEDURE xh_cl_in_up_del      (p_mode		        IN  VARCHAR2,
						  p_patient_nric_id             IN  VARCHAR2,
						  p_session_id                  IN  VARCHAR2,
						  p_sno                         IN  NUMBER,
						  p_header_doc                  IN  CLOB,
						  p_detail_doc                  IN  CLOB,
						  p_xml_valid_header_stauts	IN  VARCHAR2,
                                                  p_xml_valid_detail_stauts     IN  VARCHAR2,
						  p_xml_error_text              IN  CLOB,
						  p_errcd		        OUT VARCHAR2,
				 		  p_errmsg		        OUT VARCHAR2  )IS
/****************************************************************************************
* PROCEDURE NAME  : xh_cl_in_up_del
* DESCRIPTION     : This Procedure is used for insert/update/delete records to/from xh_clinical_integration
			  table.
* SCOPE           : PUBLIC
* INPUTS          : p_mode,p_patient_nric_id,p_session_id,p_sno,p_header_doc,p_detail_doc,p_xml_valid_header_stauts,
                    p_xml_valid_detail_stauts,p_xml_error_text 
* OUTPUT          : p_errcd, p_errmsg
* CREATE BY       : SHAILABALA PANDA
* CREATED ON      : 06-05-2008
****************************************************************************************/

BEGIN

	XHTRACING.G_PROG_ID:='xh_cl_in_up_del';
	XHTRACING.G_FLAG:=XHTRACING.ENABLE_OR_DISABLE_TRACING;
	

	XHTRACING.TRACES('xh_cl_in_up_del','p_mode                   ='||p_mode,'P');
	XHTRACING.TRACES('xh_cl_in_up_del','p_patient_nric_id        ='||p_patient_nric_id,'P');
	XHTRACING.TRACES('xh_cl_in_up_del','p_session_id             ='||p_session_id,'P');
	XHTRACING.TRACES('xh_cl_in_up_del','p_sno		     ='||p_sno,'P');
	XHTRACING.TRACES('xh_cl_in_up_del','p_header_doc             ='||p_header_doc,'P');
	XHTRACING.TRACES('xh_cl_in_up_del','p_detail_doc             ='||p_detail_doc,'P');
	XHTRACING.TRACES('xh_cl_in_up_del','p_xml_valid_header_stauts='||p_xml_valid_header_stauts,'P');
	XHTRACING.TRACES('xh_cl_in_up_del','p_xml_valid_detail_stauts='||p_xml_valid_detail_stauts,'P');
	XHTRACING.TRACES('xh_cl_in_up_del','p_xml_error_text         ='||p_xml_error_text,'P');

	IF p_mode = 'I' THEN

		
		XHTRACING.TRACES('xh_cl_in_up_del','Executing Insert Statement','P');

		INSERT INTO xh_clinical_integration(
							patient_nric_id,              
 							session_id,                   
 							sno,                         
 							header_doc,                   
 							detail_doc,                   
 							xml_valid_header_stauts,      
 							xml_valid_detail_stauts,      
 							xml_error_text,   
							added_by_id,
							added_date  ,
							modified_by_id   ,
							modified_date    ,
							added_at_ws_no   ,
							modified_at_ws_no
						  )
					VALUES (
							p_patient_nric_id,           
						  	p_session_id,                 
						  	p_sno,                         
						  	p_header_doc,                  
						  	p_detail_doc,                 
						        p_xml_valid_header_stauts,	
                                                        p_xml_valid_detail_stauts,     
						        p_xml_error_text,
							user,
							SYSDATE,
							user,
							SYSDATE,
                               		                SYS_CONTEXT('USERENV','IP_ADDRESS'),
							SYS_CONTEXT('USERENV','IP_ADDRESS')
						);
		p_errcd := '0';
		XHTRACING.TRACES('xh_cl_in_up_del','Insert Statement Execution Over, Status - '||p_errcd,'P');

	ELSIF p_mode = 'U' THEN

		XHTRACING.TRACES('xh_cl_in_up_del','Executing Update Statement','P');

		UPDATE 	xh_clinical_integration
		SET 		patient_nric_id      	 =p_patient_nric_id,
				session_id               =p_session_id,
				sno       		 =p_sno,
				header_doc     		 =p_header_doc,
				detail_doc		 =p_detail_doc,
				xml_valid_header_stauts  =p_xml_valid_header_stauts,
				xml_valid_detail_stauts  =p_xml_valid_detail_stauts,     
 				xml_error_text		 =p_xml_error_text,
				modified_by_id           =user,
				modified_date 	         =SYSDATE,
				modified_at_ws_no        =SYS_CONTEXT('USERENV','IP_ADDRESS')
		WHERE 	sno               =p_sno;
		
		p_errcd := '0';

		XHTRACING.TRACES('xh_cl_in_up_del','Update Statement Execution Over, Status - '||p_errcd,'P');

	ELSIF p_mode = 'D' THEN

		XHTRACING.TRACES('xh_cl_in_up_del','Executing Delete Statement','P');

		DELETE 	xh_clinical_integration
		WHERE		sno                   =p_sno;
		
		p_errcd := '0';

		XHTRACING.TRACES('xh_cl_in_up_del','Delete Statement Execution Over, Status - '||p_errcd,'P');

	END IF;

EXCEPTION WHEN OTHERS THEN
	p_errcd := '1';
	XHTRACING.TRACES('xh_cl_in_up_del','p_errcd = '||p_errcd,'P');
	p_errmsg := SUBSTR(SQLERRM,1,500);
	XHTRACING.TRACES('xh_cl_in_up_del','Exception Occured in xh_clinical_integration table = '||p_errmsg,'P');

END xh_cl_in_up_del;
/

GRANT EXECUTE ON xh_cl_in_up_del TO medusers
/
            
DROP PUBLIC SYNONYM xh_cl_in_up_del
/
            
CREATE PUBLIC SYNONYM xh_cl_in_up_del FOR xh_cl_in_up_del
/
            
SELECT * FROM User_errors WHERE Name = 'xh_cl_in_up_del'
/
 
spool off;