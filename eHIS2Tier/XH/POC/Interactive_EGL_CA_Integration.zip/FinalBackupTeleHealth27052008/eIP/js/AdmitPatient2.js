var currentTab = new String();
currentTab = "admission_tab";
/*
	 *	This function is used to populate the reasons for admission
	 */
	function ReasonLookup()
	{
		var tit				= "Reason for Admission";
		var retVal			= new String();
		var argumentArray	= new Array() ;
		var dataNameArray	= new Array() ;
		var dataValueArray	= new Array() ;
		var dataTypeArray	= new Array() ;
		// This sql populates the reasons for admission with given search value
		sql="select complaint_code code,complaint_desc description from am_complaint where eff_status like ? and  upper(complaint_code) like upper(?) and upper(complaint_desc)  like upper(?)" ;	   
		dataNameArray[0]	= "eff_status" ;
		dataValueArray[0]	= "E";
		dataTypeArray[0]	= STRING;
		argumentArray[0] =sql;
		argumentArray[1] = dataNameArray ;
		argumentArray[2] = dataValueArray ;
		argumentArray[3] = dataTypeArray ;
		argumentArray[4] = "2,3";
		argumentArray[5] = document.forms(0).chief_complaint.value;
		argumentArray[6] = DESC_LINK;
		argumentArray[7] = DESC_CODE;
		retVal = CommonLookup( tit, argumentArray );
		if(retVal != null && retVal != "" )
		{
			var ret1=unescape(retVal);
			arr=ret1.split(",");
			document.forms(0).chief_complaint.value=arr[1];
			document.forms(0).complaintcode.value=arr[0];
			document.forms(0).chief_complaint_hid.value = document.forms(0).chief_complaint.value
		}
		else
		{
			document.forms(0).chief_complaint.value="";
			document.forms(0).complaintcode.value="";
		}
	}
	/*
	 * This function is used to show the bed availability chart
	 * Arg1		: Constant value(BED_AVAIL)
	 */
	function callModalssss(ref) //fn not reqd...
	{
		var nursingunit = "";
		var practitionerid = "";
		var specialitycode = "";
		if(parent.frames(2).document.AdmitPatient_form.nursing_unit_desc.value != "")
			nursingunit = parent.frames(2).document.AdmitPatient_form.nursing_unit.value;
		if(parent.frames(2).document.AdmitPatient_form.practid_desc.value != "")
			practitionerid = parent.frames(2).document.AdmitPatient_form.practid.value;
		if(parent.frames(2).document.AdmitPatient_form.SplDesc.value != "")
			specialitycode = parent.frames(2).document.AdmitPatient_form.Splcode.value;
		var bedclasscode = parent.frames(2).document.AdmitPatient_form.Bedcode.value;
		var bedtypecode = parent.frames(2).document.AdmitPatient_form.bed_type.value;
		var gender = parent.frames(2).document.AdmitPatient_form.gender.value;
		var agevalue = parent.frames(2).document.AdmitPatient_form.age.value;
		var bkgtype=parent.frames(0).document.Select_form.bkg_type.value;
		var patientclass='';
		if(bkgtype == 'D')
			patientclass='DC';
		else if(bkgtype == 'I')
			patientclass='IP';
		if(patientclass=='')
		patientclass = parent.frames(2).document.AdmitPatient_form.patient_class_id.value;
		var room_num;
		var obj = parent.frames(2).document.AdmitPatient_form.sub_service;
		var n = obj.length;
		for(i=0;i<n;i++)
			obj.remove(0);
		var opt = parent.frames(2).document.createElement('Option');
		opt.text = "---------Select---------"
		opt.value = "";
		obj.add(opt);
		if(bkgtype =='D')
		{
			room_num=parent.frames(2).document.AdmitPatient_form.room_no.value;
		}
		else
		{
			room_num='';
		}
		var age = "";
		if(agevalue != '')
		{
			var yr = eval(agevalue.indexOf("Y"));
			var mon = eval(agevalue.indexOf("M"));
			if(mon>=0 && yr>=0)
			{
				age = agevalue.substring(0,yr);
				agevalue = "Y";
			}
			else if(mon >= 0)
			{
				age = agevalue.substring(0,mon);
				agevalue = "M";
			}
			else
			{
				age = agevalue.substring(0,yr);
				agevalue = "Y";
			}
		}
		var disable_field = "NursingUnit";
		var retVal = 	new String();
		var wherecondn = "ADMIT_PAT_YN";
		var dialogHeight= "33" ;
		var dialogWidth	= "49.8" ;
		var dialogTop	= "66" ;
		var status = "no";
		var arguments	= "" ;
		var features	= "dialogHeight:" + dialogHeight + ";dialogTop:" + dialogTop + "; dialogWidth:" + dialogWidth +" ; scroll=no; status:" + status;
		retVal = window.showModalDialog("../../eIP/jsp/BedAvailabilityChart.jsp?nursing_unit_code="+nursingunit+"&speciality_code="+specialitycode+"&practitioner_id="+practitionerid+"&bed_class_code="+bedclasscode+"&bed_type="+bedtypecode+"&room_no_code="+room_num+"&age_value="+agevalue+"&age="+age+"&gender="+gender+"&patient_class="+patientclass+"&disable_field="+disable_field+"&wherecondn="+wherecondn,arguments,features);
		if(retVal != null)
		{
			retVal = retVal.replace("|","&");
			var arr = retVal.split("^");
			if (arr.length > 2)
			{
				parent.frames(2).document.AdmitPatient_form.nursing_unit.value=arr[0];
				parent.frames(2).document.AdmitPatient_form.nursing_unit_desc.value=arr[9];
				parent.frames(2).document.AdmitPatient_form.nurs_unit_desc_hid.value = parent.frames(2).document.AdmitPatient_form.nursing_unit_desc.value;
				validateFields(document.forms(0).nursing_unit_desc);
				parent.frames(2).document.AdmitPatient_form.bedtypecode.value=arr[2];
				var arrsplty = arr[11].split("*All SPLTY*");
				if (arrsplty.length==1)
				{
					parent.frames(2).document.AdmitPatient_form.Splcode.value=arr[10];
					parent.frames(2).document.AdmitPatient_form.SplDesc.value=arr[11];
				}
				if (arr .length > 1)
				{
					var arr1 = arr[1].split("/");
					parent.frames(2).document.AdmitPatient_form.bed_no.value = arr1[0];
					p = parent.frames(2).document.AdmitPatient_form.Bedcode.options;
					for (i=0; i<p.options.length; i++) 
					{
						if(p.options[i].value ==arr[3])
							p.options[i].selected = true;
					}
				}
				parent.frames(2).document.AdmitPatient_form.patient_class_id.value = arr[15];

				if(parent.frames(2).document.AdmitPatient_form.pat_check_in_allowed_yn.value == "N")
				{
					parent.frames(2).document.AdmitPatient_form.attend_img.style.visibility="visible";
				}				

				if(parent.frames(2).document.AdmitPatient_form.patient_class_id.value =='DC')
				{
					parent.frames(2).AdmitPatient_form.exp_days_stay.value = '1';
					parent.frames(2).AdmitPatient_form.exp_days_stay.onblur();
					parent.frames(2).AdmitPatient_form.exp_days_stay.readOnly = true;
				}
				if(bkgtype !='D')
				parent.frames(2).document.AdmitPatient_form.room_no.value = arr[4];
				parent.frames(2).document.AdmitPatient_form.bed_no.focus();
			}
			else
			{
				arr = retVal.split("^");
				parent.frames(2).document.AdmitPatient_form.nursing_unit.value = arr[0];
				if (arr.length == 2)
					parent.frames(2).document.AdmitPatient_form.nursing_unit_desc.value = arr[1];
					parent.frames(2).document.AdmitPatient_form.nurs_unit_desc_hid.value = parent.frames(2).document.AdmitPatient_form.nursing_unit_desc.value;
			}
	
			if (parent.frames(2).document.AdmitPatient_form.nursing_unit.value != '')
			if(parent.frames(2).document.AdmitPatient_form.pat_check_in_allowed_yn.value == "Y")
			{
				parent.frames(2).document.AdmitPatient_form.attend_img.style.visibility="hidden";
				parent.frames(3).document.all.valuables.disabled = false;
			}
		}
	}
	function moveToNextItem()
	{
		tab_click('admission_tab');
		if(!document.forms(0).Bedcode.disabled)
			document.forms(0).Bedcode.focus();	
	}

	function tab_click(objName)
	{
		changeTab(objName);
		if (objName == 'admission_tab' || objName == 'admission_tab1' || objName == 'admission_tab2')
		{
			document.all.tab1.scrollIntoView();
			if(document.all.visit_adm_date_time.disabled==false)
				document.all.visit_adm_date_time.focus();
		}
		else if (objName == 'additional_tab' || objName == 'additional_tab1' || objName == 'additional_tab2')
		{
			document.all.tab2.scrollIntoView();
			if(document.all.ambulatory_status.disabled==false)
				document.all.ambulatory_status.focus();
		}
		else if (objName == 'findtl_tab' || objName == 'findtl_tab1' || objName == 'findtl_tab2')
		{
			document.all.tab3.scrollIntoView();
			var financial_detail_ref_id = "";
			if(document.forms(0).isBlInstalled.value=="Y")
			{				
				if(parent.Select_frame.document.forms(0).referral_id.value != "")
					document.forms(0).financial_detail_ref_id.value = parent.Select_frame.document.forms(0).referral_id.value ;
			}
		
		if(parent.frames(2).document.AdmitPatient_form.nursing_unit.value !='')
			chkOnSub(); 
		else
		{	
			document.all.tab1.scrollIntoView();
			alert(getIPMessage('NU_NOTNULL'));
			parent.frames(2).document.AdmitPatient_form.nursing_unit_desc.focus();
			}
		}   
	} 
	function changeTab(TabName) 
	{
		if (currentTab == 'admission_tab' || currentTab == 'admission_tab1' || currentTab == 'admission_tab2')
		{
			document.all.admission_tab.src = '../images/Admission_click.gif';
			document.all.admission_tab1.src = '../images/Admission_click.gif';
			document.all.admission_tab2.src = '../images/Admission_click.gif';
		}
		else if (currentTab == 'additional_tab' || currentTab == 'additional_tab1' || currentTab == 'additional_tab2')
		{
			document.all.additional_tab.src = '../images/Additional_click.gif';
			document.all.additional_tab1.src = '../images/Additional_click.gif';
			document.all.additional_tab2.src = '../images/Additional_click.gif';
		}
		else if (currentTab == 'findtl_tab' || currentTab == 'findtl_tab1' || currentTab == 'findtl_tab2')
		{
			document.all.findtl_tab.src = '../../eBL/images/Financial Details_click.gif';
			document.all.findtl_tab1.src = '../../eBL/images/Financial Details_click.gif';
			document.all.findtl_tab2.src = '../../eBL/images/Financial Details_click.gif';
		}
		if (TabName == 'admission_tab' || TabName == 'admission_tab1' || TabName == 'admission_tab2')
		{
			document.all.admission_tab.src = '../images/Admission.gif';
			document.all.admission_tab1.src = '../images/Admission.gif';
			document.all.admission_tab2.src = '../images/Admission.gif';
		}
		else if (TabName == 'additional_tab' || TabName == 'additional_tab1' || TabName == 'additional_tab2')
		{
			document.all.additional_tab.src = '../images/Additional.gif';
			document.all.additional_tab1.src = '../images/Additional.gif';
			document.all.additional_tab2.src = '../images/Additional.gif';
		}
		else if (TabName == 'findtl_tab' || TabName == 'findtl_tab1' || TabName == 'findtl_tab2')
		{
			document.all.findtl_tab.src = '../../eBL/images/Financial Details.gif';
			document.all.findtl_tab1.src = '../../eBL/images/Financial Details.gif';
			document.all.findtl_tab2.src = '../../eBL/images/Financial Details.gif';
			
		}
		currentTab = TabName;    
	}    

	function setTabFocus(val,obj)
	{
		var continue_yn = true ;
		if(obj !=null)
			if(obj.name == 'room_no' && obj.value != '')
				continue_yn = validateSplchars (obj,'Room No')
		if( continue_yn )
		{
			if(val == 'F')
			{
				document.all.tab1.scrollIntoView();
				if(document.all.visit_adm_date_time.disabled==false)
					document.all.visit_adm_date_time.focus();
			}
			else
			{
				
				tab_click('admission_tab')
			}
		}
	}

function onBedClassChange()
{
	var obj = document.forms(0).bed_type;
	var length = obj.length;
	for(i=0;i<length;i++)
	{
		obj.remove(0);
	}
	var opt = document.createElement('OPTION');
	opt.text = "--------Select-------";
	opt.value = "";
	obj.add(opt);
   var bed_class = document.forms(0).Bedcode.value;
   var nursingunit_code = document.forms(0).nursing_unit.value;
   var deactivate_pseudo_bed_yn = document.forms(0).deactivate_pseudo_bed_yn.value;

	document.forms(0).bed_no.value = '';
	if (document.forms(0).Pract_id.value =='')
		{
		document.forms(0).room_no.value = '';
		}

	document.AdmitPatient_form.attend_img.style.visibility = "hidden";

	if(parent.frames(0).document.Select_form.bkg_type.value !='D')
		document.forms(0).room_no.value = '';

	parent.frames(3).document.all.valuables.disabled = true;
	if(bed_class!="")
	{
		var HTMLVal = " <html><body><form name='dum_form' method='post'  action='../../eIP/jsp/AdmissionValidation.jsp'><input type='hidden' name='field1' value=''><input type='hidden' name='field2' value=''><input type='hidden' name='bed_class' value='"+bed_class+"'><input type='hidden' name='nursingunit_code' value='"+nursingunit_code+"'><input type='hidden' name='deactivate_pseudo_bed_yn' value='"+deactivate_pseudo_bed_yn+"'></form></body></html>";
		parent.dummy.document.body.insertAdjacentHTML('AfterBegin',HTMLVal);
		parent.dummy.document.dum_form.submit();
	}
	
}

//Billing related nursing_unit
function chkOnSub()
{
	document.forms(0).bl_success.value = "N";
	var show_hide_blng_class = "HIDE";
	var patient_id     = parent.Select_frame.document.forms(0).patient_id.value;
	var package_flag	= document.forms(0).package_flag.value;
	var ins_auth_flag	= "Y";
	var upd_pat_flag	= "Y";
	var billing_group			= document.forms(0).billing_group;
	var billing_class			= document.forms(0).billing_class;
	var employer_code			= document.forms(0).employer_code;
	var cash_set_type1			= document.forms(0).cash_set_type1;
	var cash_insmt_ref1			= document.forms(0).cash_insmt_ref1;
	var cash_insmt_date1		= document.forms(0).cash_insmt_date1;
	var cash_insmt_rmks1		= document.forms(0).cash_insmt_rmks1;
	var cust_1					= document.forms(0).cust_1;
	var credit_doc_ref1			= document.forms(0).credit_doc_ref1;
	var credit_doc_date1		= document.forms(0).credit_doc_date1;
	var cust_2					= document.forms(0).cust_2;
	var credit_doc_ref2			= document.forms(0).credit_doc_ref2;
	var credit_doc_date2		= document.forms(0).credit_doc_date2;
	var cust_3					= document.forms(0).cust_3;
	var policy_type				= document.forms(0).policy_type;
	var policy_no				= document.forms(0).policy_no;
	var policy_expiry_date		= document.forms(0).policy_expiry_date;
	var non_insur_blng_grp		= document.forms(0).non_insur_blng_grp;
	var cash_set_type2			= document.forms(0).cash_set_type2;
	var cash_insmt_ref2			= document.forms(0).cash_insmt_ref2;
	var cash_insmt_date2		= document.forms(0).cash_insmt_date2;
	var cash_insmt_rmks2		= document.forms(0).cash_insmt_rmks2;
	var cust_4					= document.forms(0).cust_4;
	var credit_doc_ref3			= document.forms(0).credit_doc_ref3;
	var credit_doc_date3		= document.forms(0).credit_doc_date3;
	var setlmt_ind				= document.forms(0).setlmt_ind;
	var upd_fin_dtls			= document.forms(0).upd_fin_dtls;
	var credit_auth_ref			= document.forms(0).credit_auth_ref;
	var credit_auth_date		= document.forms(0).credit_auth_date;
	var app_days				= document.forms(0).app_days;
	var app_amount				= document.forms(0).app_amount;
	var eff_frm_date			= document.forms(0).eff_frm_date;
	var remarks					= document.forms(0).remarks;
	var billing_mode			= document.forms(0).billing_mode;
	var operation				= document.forms(0).bl_operation.value;
	var pkg_bill_type			= document.forms(0).pkg_bill_type;
	var pkg_bill_no				= document.forms(0).pkg_bill_no;
	var annual_income	   		= document.forms(0).annual_income;
	var family_asset			= document.forms(0).family_asset;
	var no_of_dependants		= document.forms(0).no_of_dependants;
	var resp_for_payment		= document.forms(0).resp_for_payment;
	var credit_doc_reqd_yn1		= document.forms(0).credit_doc_reqd_yn1;
	var credit_doc_reqd_yn2		= document.forms(0).credit_doc_reqd_yn2;
	var health_card_expired_yn	= document.forms(0).health_card_expired_yn; 
	var Chg_to_Visitor_Grp		= document.forms(0).Chg_to_Visitor_Grp;			
	/* Start Limpopo Changes /*
	/* Added by Chinju on 10th Nov 2006 - billing enhancements */
	var clsficatnCode           =  document.forms(0).clsficatnCode;
	var refNo                   = document.forms(0).refNo;
	var incAsset                = document.forms(0).incAsset;
	var indInc                  = document.forms(0).indInc;
	var indIncFreq              = document.forms(0).indIncFreq;
	var spouseInc               = document.forms(0).spouseInc;
	var spouseIncFreq           = document.forms(0).spouseIncFreq;
	var dependentInc            = document.forms(0).dependentInc;
	var dependentIncFreq        = document.forms(0).dependentIncFreq	;
	//For retaing values
	var clsficatnDesc			=  document.forms(0).clsficatnDesc;
	var clsficatnType			= document.forms(0).clsficatnType;
	var billing_group_desc		= document.forms(0).billing_group_desc;
	var validFrom				=  document.forms(0).validFrom;
	var validTo					= document.forms(0).validTo;
	var lastDate				= document.forms(0).lastDate;
	var totalIncAsset = "";
	if(annual_income.value == "")
	{
		if(family_asset.value=="")
			totalIncAsset = ""
		else
			totalIncAsset = family_asset.value;
	}
	else
		totalIncAsset = annual_income.value;

	/*End  Limpopo Changes*/
	var calling_module_id		=parent.frames(2).document.AdmitPatient_form.patient_class_id.value;
	var calling_function_id		= "ADMISSION";
	var nursingUnitCode = document.forms(0).nursing_unit.value;
	var admissionType	= document.forms(0).visit_adm_type.value;
	var bedClass		= document.forms(0).Bedcode.value;
	var financial_detail_ref_id = "";
	if(document.forms(0).isBlInstalled.value=="Y")
	financial_detail_ref_id = document.forms(0).financial_detail_ref_id.value;
	var episode="";
	var record="";
	//MOD#08 new variable is introduced for bl_interfaced_yn( NOT bl_interface?_yn)  and the logic 
	// for the null 
	var bl_interfaced_yn =  document.forms(0).bl_interface_yn.value;
	if ( (bl_interfaced_yn == null) || (bl_interfaced_yn == '') )
	{
		bl_interfaced_yn = 'N';
	}
	// End of mod#08
	var qryStr="operation="+operation+"&package_flag="+package_flag+"&ins_auth_flag="+ins_auth_flag+"&upd_pat_flag="+upd_pat_flag+"&show_hide_blng_class="+show_hide_blng_class+"&patient_id="+patient_id+"&billing_mode="+billing_mode.value+"&billing_group="+billing_group.value+"&billing_class="+billing_class.value+"&employer_code="+employer_code.value+"&cash_set_type1="+cash_set_type1.value+"&cash_insmt_ref1="+cash_insmt_ref1.value+"&cash_insmt_date1="+cash_insmt_date1.value;
	qryStr += "&cash_insmt_rmks1="+cash_insmt_rmks1.value+"&cust_1="+cust_1.value+"&credit_doc_ref1="+credit_doc_ref1.value+"&credit_doc_date1="+credit_doc_date1.value+"&cust_2="+cust_2.value;
	qryStr += "&credit_doc_ref2="+credit_doc_ref2.value+"&credit_doc_date2="+credit_doc_date2.value+"&cust_3="+cust_3.value+"&policy_type="+policy_type.value;
	qryStr += "&policy_no="+policy_no.value+"&policy_expiry_date="+policy_expiry_date.value+"&non_insur_blng_grp="+non_insur_blng_grp.value+"&cash_set_type2="+cash_set_type2.value+"&pkg_bill_type="+pkg_bill_type.value+"&pkg_bill_no="+pkg_bill_no.value;
	qryStr += "&cash_insmt_ref2="+cash_insmt_ref2.value+"&cash_insmt_date2="+cash_insmt_date2.value+"&cash_insmt_rmks2="+cash_insmt_rmks2.value+"&cust_4="+cust_4.value+"&credit_doc_ref3="+credit_doc_ref3.value+"&credit_doc_date3="+credit_doc_date3.value+"&setlmt_ind="+setlmt_ind.value+"&credit_auth_ref="+credit_auth_ref.value+"&credit_auth_date="+credit_auth_date.value+"&app_days="+app_days.value+"&app_amount="+app_amount.value+"&eff_frm_date="+eff_frm_date.value+"&remarks="+remarks.value+"&episode="+episode+"&record="+record;
	qryStr += "&calling_module_id="+calling_module_id+"&calling_function_id="+calling_function_id;
	qryStr += "&annual_income="+annual_income.value+"&family_asset="+family_asset.value+"&no_of_dependants="+no_of_dependants.value+"&resp_for_payment="+resp_for_payment.value+"&credit_doc_reqd_yn1="+credit_doc_reqd_yn1.value+"&credit_doc_reqd_yn2="+credit_doc_reqd_yn2.value+"&health_card_expired_yn="+health_card_expired_yn.value+"&Chg_to_Visitor_Grp="+Chg_to_Visitor_Grp.value;
	qryStr += "&bl_interfaced_yn="+bl_interfaced_yn;		 
	qryStr += "&nursing_unit_code="+nursingUnitCode+"&bed_class_code="+bedClass+"&visit_adm_type="+admissionType;
	qryStr += "&financial_detail_ref_id="+financial_detail_ref_id+"&org_type_ind="+document.forms[0].org_type_ind.value;
	//qryStr += "&credit_doc_start_date1="+document.forms(0).credit_doc_date1.value+"&credit_doc_start_date2="+document.forms(0).credit_doc_date2.value+"&credit_doc_start_date3="+document.forms(0).credit_doc_date3.value+"&gl_holder_name="+document.forms(0).gl_holder_name.value+"&pat_reln_with_gl_holder="+document.forms(0).gl_holder_reln.value;
	qryStr += "&credit_doc_start_date1="+document.forms(0).cred_st_dt1.value+"&credit_doc_start_date2="+document.forms(0).cred_st_dt2.value+"&credit_doc_start_date3="+document.forms(0).cred_st_dt3.value+"&gl_holder_name="+document.forms(0).gl_holder_name.value+"&pat_reln_with_gl_holder="+document.forms(0).gl_holder_reln.value;
	/*  Start Limpopo Changes */
	/*Added by chinju on 10th Nov 2006 - Billing enhancement  */
	qryStr+="&clsficatnCode="+clsficatnCode.value;
	qryStr+="&refNo="+refNo.value;
	qryStr+="&incAsset="+incAsset.value;
	qryStr+="&indInc="+indInc.value;
	qryStr+="&indIncFreq="+indIncFreq.value;
	qryStr+="&spouseInc="+spouseInc.value;
	qryStr+="&spouseIncFreq="+spouseIncFreq.value;
	qryStr+="&dependentInc="+dependentInc.value;
	qryStr+="&dependentIncFreq="+dependentIncFreq.value;
	qryStr+="&totalIncAsset="+totalIncAsset;
	qryStr+="&clsficatnDesc="+clsficatnDesc.value;
	qryStr+="&clsficatnType="+clsficatnType.value;
	qryStr+="&billing_group_desc="+billing_group_desc.value;
	qryStr+="&validFrom="+validFrom.value;
	qryStr+="&validTo="+validTo.value;
	qryStr+="&lastDate="+lastDate.value;
	qryStr+="&totalIncAsset="+totalIncAsset;
	/*End  Limpopo Changes*/
	var returnArray = new Array();

	returnArray = getFinDtl(qryStr,patient_id);

	if(returnArray.length>0)
	{
		billing_group.value     = returnArray[0];
		billing_class.value     = returnArray[1];
		employer_code.value     = returnArray[2];    
		cash_set_type1.value        = returnArray[3];
		cash_insmt_ref1.value       = returnArray[4];
		cash_insmt_date1.value      = returnArray[5];
		cash_insmt_rmks1.value      = returnArray[6];
		cust_1.value            = returnArray[7];
		credit_doc_ref1.value       = returnArray[8];
		credit_doc_date1.value      = returnArray[9];
		cust_2.value            = returnArray[10];
		credit_doc_ref2.value       = returnArray[11];
		credit_doc_date2.value      = returnArray[12];
		cust_3.value            = returnArray[13];
		policy_type.value       = returnArray[14];
		policy_no.value         = returnArray[15];
		policy_expiry_date.value    = returnArray[16];
		non_insur_blng_grp.value    = returnArray[17];
		cash_set_type2.value        = returnArray[18];
		cash_insmt_ref2.value       = returnArray[19];
		cash_insmt_date2.value      = returnArray[20];
		cash_insmt_rmks2.value      = returnArray[21];
		cust_4.value            = returnArray[22];
		credit_doc_ref3.value       = returnArray[23];
		credit_doc_date3.value      = returnArray[24];
		setlmt_ind.value        = returnArray[25];
		upd_fin_dtls.value      = returnArray[26];
		credit_auth_ref.value       = returnArray[27];
		credit_auth_date.value      = returnArray[28];
		app_days.value          = returnArray[29];
		app_amount.value        = returnArray[30];
		annual_income.value		= returnArray[31];    
		family_asset.value		= returnArray[32];   
		no_of_dependants.value		= returnArray[33];
		resp_for_payment.value		= returnArray[34];
		credit_doc_reqd_yn1.value	= returnArray[35];
		credit_doc_reqd_yn2.value	= returnArray[36];
		eff_frm_date.value      = returnArray[37];
		remarks.value           = returnArray[38];
		// MOD#07 Refer MOD#06 The credit authorization user id 
		document.forms(0).user_id.value = returnArray[39];
		document.forms(0).cred_st_dt1.value = returnArray[40];
		document.forms(0).cred_st_dt2.value = returnArray[41];
		document.forms(0).cred_st_dt3.value = returnArray[42];
		document.forms(0).gl_holder_name.value = returnArray[43];
		document.forms(0).gl_holder_reln.value = returnArray[44];
		/* Start Limpopo Changes */
		/* Added by Chinju on 10th Nov 2006 - billing enhancements */

		if(returnArray.length>45)
			{
				clsficatnCode.value = returnArray[45];
				refNo.value = returnArray[46];
				incAsset.value = returnArray[47];
				indInc.value = returnArray[48];
				indIncFreq.value = returnArray[49];
				spouseInc.value = returnArray[50];
				spouseIncFreq.value = returnArray[51];
				dependentInc.value = returnArray[52];
				dependentIncFreq.value = returnArray[53];
				clsficatnDesc.value = returnArray[54];
				clsficatnType.value = returnArray[55];
				billing_group_desc.value = returnArray[56];
				validFrom.value = returnArray[57];
				validTo.value = returnArray[58];
				lastDate.value = returnArray[59];
			}
			/*End of Modification by Chinju  */
			/* End  Limpopo Changes*/ 
		billing_mode.value      = "Modify"
		document.forms(0).bl_success.value = "Y";
		tab_click('admission_tab');
		document.forms[0].visit_adm_type.focus();
	}
	else 
	{
		tab_click('admission_tab');
		return false;
	}
}

function getFinDtl(qryStr)
{	
	var retVal;
	var facility_id			= document.forms(0).hddfacility.value;
	//var dialogHeight= "24" ;
	var dialogHeight= "32" ;
	//var dialogWidth = "49" ;
	var dialogWidth = "50" ;
	var dialogTop = "160" ;
	var center = "1" ;                                                         
	var status="no";
	var features    = "dialogHeight:" + dialogHeight + "; dialogWidth:" + dialogWidth + "; center: " + center + "; status: " + status + "; dialogTop :" + dialogTop;
	var arguments   = "" ;
	var url = "../../eBL/jsp/AddModifyPatFinDetailsMain.jsp?"+qryStr+"&facility_id="+facility_id;
	retVal = window.showModalDialog(url,arguments,features);
	if(retVal==null) retVal="";
	return retVal;
}

	function calculateDepAmt()
	{
		var patient_id  = parent.Select_frame.document.forms(0).patient_id.value;
		var p_bed_class_code  =  document.forms(0).Bedcode.value;    
		var p_nursing_unit_code = document.forms(0).nursing_unit.value;   
		var p_bed_no = document.forms(0).bed_no.value;
		var setlmt_ind = document.forms(0).setlmt_ind.value;
		if( (patient_id != "" || patient_id !=null) && (p_bed_class_code != "" || p_bed_class_code !=null) && (p_nursing_unit_code != "" || p_nursing_unit_code !=null) && (p_bed_no != "" || p_bed_no !=null) ) 
		{
			HTMLVal = "<HTML><BODY CLASS='MESSAGE'><form name='DepCalc' method='post' action='../../eBL/jsp/CalulateIPDeposit.jsp'><input name='patientId' type='hidden' value='"+patient_id+"'><input name='p_bed_class_code' type='hidden' value='"+p_bed_class_code+"'><input name='p_nursing_unit_code' type='hidden' value='"+p_nursing_unit_code+"'><input name='p_bed_no' type='hidden' value='"+p_bed_no+"'><input name='setlmt_ind' type='hidden' value='"+setlmt_ind+"'></form></BODY></HTML>";
			parent.dummy.document.body.insertAdjacentHTML('AfterBegin',HTMLVal);
			parent.dummy.document.DepCalc.submit();
		}
	}
	//End Billing related
	/*
	 *	This fucntion is used to validate expected days 
	 *  Expected days should not be zero
	 */
	function CheckNumVal(obj)
	{
		if(obj.value.length > 0)
		{
			if (Math.abs(obj.value) == 0 )
			{
				alert(getIPMessage('IP_VAL_NOT_LESS_ZERO'));
				obj.select();
				obj.focus();
			}
			else
			{
				makeValidString(obj);
				CheckNum(obj);
				calcDate(obj);
			}
		}
		else
		document.forms[0].expecteddischargedate.value = "";
	}
	/*
	* This funtion is used to set the date for admission
	*/
	function setDate(val,dat)
	{
		if(val != null)
		{
			if(val.value == "")
			{
				if(dat != "")
				val.value=dat;
			}
		}
	}

	/*
	 * This function is used to validate the expected discharge date
	 */ 

	function validateExpDate(obj)
	{
		if(obj.value != "")
		{
			if(!(ValidateDateTime(document.forms[0].visit_adm_date_time,obj)))
			{
				var msg = getIPMessage("EXP_DIS_DATE_GT_SYSDATE");
				msg = msg.replace("or equal to Current Date Time","Admission Date Time")
				alert(msg);
				obj.value = "";
			}
		}
	 }
	//Added by kishore on 5/12/2004
	function getpatientcode()
	{
		var nursingunit=document.forms(0).nursing_unit.value;
		if(document.forms(0).nursing_unit_desc.value!="")
		{
			var HTMLVal = " <html><body><form name='dum_form' method='post'  action='../../eIP/jsp/AdmissionValidation.jsp'><input type='hidden' name='field1' value=''><input type='hidden' name='field2' value=''><input type='hidden' name='field4' value='patientcode_value'><input type='hidden' name='field5' value=''><input type='hidden' name='patient_nursingunit' value='"+nursingunit+"'></form></body></html>";
			parent.dummy.document.body.insertAdjacentHTML('AfterBegin',HTMLVal);
			parent.dummy.document.dum_form.submit();
		}
	}
	function callLoad()
	{
		var patient_classcode = document.forms(0).nursing_unit.value;
	}
	
function CheckNursingUnit()
{		
	var nursingunit=document.forms(0).nursing_unit_desc.value;
//	var practitionerid = parent.parent.messageFrame.AdmissionValidation_form.practitionerid.value;
//	alert("practitionerid==>" +practitionerid);
	if(nursingunit == '')
	{
		

		if (document.forms(0).Pract_id.value =='')
		{
			
            document.forms(0).room_no.value='';
		}
		
		document.forms(0).sub_service.value='';
		document.forms(0).bed_no.value='';
		if(parent.frames(0).document.Select_form.bkg_type.value !='D')
		{
			document.forms(0).room_no.value='';
		}
		var obj =document.forms(0).service;		
		var slength  = obj.length;
		for(i=0;i<=slength;i++) 
		{
			obj.remove(0);
		}
		var opt = parent.frames(2).document.createElement('Option');
		opt.value = "";
		opt.text = "--------- Select ----------";
		opt.selected = true;
		obj.add(opt);

		var obj1 =document.forms(0).sub_service;
		var length1  = obj1.length;
		for(i=0;i<length1;i++) 
		{
			obj1.remove(0);
		}
		var opt = parent.frames(2).document.createElement('Option');
		opt.value = "";
		opt.text = "--------- Select ----------";
		opt.selected = true;
		obj1.add(opt);

		var obj1 =document.forms(0).bed_type;
		var length1  = obj1.length;
		for(i=0;i<length1;i++) 
		{
			obj1.remove(0);
		}
		var opt = parent.frames(2).document.createElement('Option');
		opt.value = "";
		opt.text = "--------- Select ----------";
		opt.selected = true;
		obj1.add(opt);

		var obj3 =document.forms(0).Bedcode;		
		var slength3  = obj3.length;
		for(i=0;i<=slength3;i++) 
		{
			obj3.remove(0);
		}
		var opt3 = parent.frames(2).document.createElement('Option');
		opt3.value = "";
		opt3.text = "--------- Select----------";
		opt3.selected = true;
		obj3.add(opt3);
	}

}
	
	//++++++++++++++++++ Admission Validation.jsp functions+++++++++++++
	var continueFlag = "Y";
	var temp2 = "";
	var babyfalgyn='';

function showBillingRemarks()
{
	var patId = document.forms(0).patId.value;
	var module_id = document.forms(0).module_id.value;
	var calling_function_id = document.forms(0).calling_function_id.value;
	var episode_type = document.forms(0).episode_type.value;
	var episode_id = document.forms(0).episode_id.value;
	var visit_id = document.forms(0).visit_id.value;
	var arguments = "";
	var param = "patient_id="+patId+"&module_id="+module_id+"&calling_function_id="+calling_function_id+
	"&episode_type="+episode_type+"&episode_id="+episode_id+"&visit_id="+visit_id;
	var dialogHeight= "20" ;
	var dialogWidth	= "30" ;
	var dialogTop	= "66" ;	
	var status = "no";
	var arguments	= "" ;
	var features	= "dialogHeight:" + dialogHeight + ";dialogTop:" + dialogTop + "; dialogWidth:" + dialogWidth +" ; scroll=no; status:" + status;
	window.showModalDialog( "../../eBL/jsp/BLPatientRemarks.jsp?"+param,arguments,features);

}

//Addition ends here.
function callConfirmBilling()
{	var retVal;
	var dialogHeight= "9" ;
	var dialogWidth	= "22" ;
	var dialogTop = "225" ;
	var center = "1" ;														   
	var status="no";
	var features	= "dialogHeight:" + dialogHeight + "; dialogWidth:" + dialogWidth + "; center: " + center + "; status: " + status + "; dialogTop :" + dialogTop;
	var arguments	= "" ;
	retVal = window.showModalDialog("../../eBL/jsp/BLBillingGroupConfirm.jsp",arguments,features);
	return retVal;
}

function invokePatientReg()
{  
	var q_booking_ref_no="";
	var booking_type=parent.frames(1).frames(0).document.Select_form.bkg_type.value;
	q_booking_ref_no =parent.frames(1).frames(0).document.Select_form.booking_ref_no.value;
	
	var retVal =    new String();
	var dialogHeight= "14.5" ;
	var dialogWidth = "25" ;
	var features    = "dialogHeight:" + dialogHeight + "; dialogWidth:" + dialogWidth +";status=no" ;
	var arguments   = "" ;

	var loc_params = parent.frames[0].location.href
		retVal = window.showModalDialog("../../eOP/jsp/VisitRegistrationPromptPatID.jsp?func_act=Visitreg&q_from_funct=IP_ADMISSION&q_booking_type="+booking_type+"&q_booking_ref_no="+q_booking_ref_no,arguments,features);
	
	parent.frames[0].location.href  = loc_params

	if(retVal!=null) 
	{
		if(retVal!='C')
		{
//			parent.frames(1).frames(0).document.Select_form.patient_id.value = retVal;

			pat_flag=retVal.charAt(0);
			if(pat_flag == 'Y')
			{
				var patientid=retVal.substring(1,retVal.length);
				parent.frames(1).frames(0).document.Select_form.patient_id.value = patientid;
				parent.frames(1).frames(0).document.Select_form.pat_flag.value=pat_flag;
			}
			else
			{
				parent.frames(1).frames(0).document.Select_form.patient_id.value = retVal;
				pat_flag = 'N';
				parent.frames(1).frames(0).document.Select_form.pat_flag.value=pat_flag;
			}

		if(parent.frames(1).frames(0).document.Select_form.patient_id.disabled == true) 	
			parent.frames(1).frames(0).document.Select_form.patient_id.disabled = false;

		if(parent.frames(1).frames(0).document.Select_form.patient_id.readOnly == true) 	
			parent.frames(1).frames(0).document.Select_form.patient_id.readOnly = false;

			parent.frames(1).frames(0).document.Select_form.patient_id.select();
		}
		else
		{
			parent.frames(1).frames(2).location.reload();
			parent.frames(1).Select_frame.location.reload();
			
			if(retVal=='C')
				continueFlag = "N";
		}
	}
  }
	
function invokePatientRegRef(pRefID)
{  
	
	var q_booking_ref_no = parent.frames(1).frames(0).document.Select_form.booking_ref_no.value;
	var booking_type=parent.frames(1).frames(0).document.Select_form.bkg_type.value;
	var retVal =    new String();
	var dialogHeight= "14.5" ;
	var dialogWidth = "25" ;
	var features    = "dialogHeight:" + dialogHeight + "; dialogWidth:" + dialogWidth +";status=no" ;
	var arguments   = "" ;
	
	var loc_params = parent.frames[0].location.href
		retVal = window.showModalDialog("../../eOP/jsp/VisitRegistrationPromptPatID.jsp?calledFrom=IP&func_act=REF_SEARCH&q_from_funct=IP_ADMISSION&q_booking_ref_no="+q_booking_ref_no+"&q_booking_type="+booking_type+"&p_referral_id="+pRefID,arguments,features);

	parent.frames[0].location.href  = loc_params
	if(retVal!=null) 
	{
		if(retVal!='C')
		{
	//		parent.frames(1).frames(0).document.Select_form.patient_id.value = retVal;

			pat_flag=retVal.charAt(0);
			if(pat_flag == 'Y')
			{
				var patientid=retVal.substring(1,retVal.length);
				parent.frames(1).frames(0).document.Select_form.patient_id.value = patientid;
				parent.frames(1).frames(0).document.Select_form.pat_flag.value=pat_flag;
			}
			else
			{
				parent.frames(1).frames(0).document.Select_form.patient_id.value = retVal;
				pat_flag = 'N';
				parent.frames(1).frames(0).document.Select_form.pat_flag.value=pat_flag;
			}

		if(parent.frames(1).frames(0).document.Select_form.patient_id.disabled == true) 	
			parent.frames(1).frames(0).document.Select_form.patient_id.disabled = false;

		if(parent.frames(1).frames(0).document.Select_form.patient_id.readOnly == true) 	
			parent.frames(1).frames(0).document.Select_form.patient_id.readOnly = false;
			
			parent.frames(1).frames(0).document.Select_form.patient_id.select();
		}
		else
		{
			
			parent.frames(1).frames(2).location.reload();
			parent.frames(1).Select_frame.location.reload();
	
			if(retVal=='C')
				continueFlag = "N";
		}
	}
}

function enableDisable()
{
	if(document.AdmissionValidation_form.enablespeciality.value == 'Y')
	{
		parent.frames(1).frames(0).document.Select_form.patient_id.readOnly = true;
	}
	parent.frames(1).frames(2).document.AdmitPatient_form.exp_days_stay.readOnly = false;
	parent.frames(1).frames(2).document.AdmitPatient_form.team_id.disabled = false;
	parent.frames(1).frames(2).document.AdmitPatient_form.Bedcode.disabled = false;
	parent.frames(1).frames(2).document.AdmitPatient_form.nursing_unit.disabled = false;
	parent.frames(1).frames(2).document.AdmitPatient_form.visit_adm_type.disabled = false;
	parent.frames(1).frames(2).document.AdmitPatient_form.arrival_code.disabled = false;
	parent.frames(1).frames(2).document.AdmitPatient_form.ambulatory_status.disabled = false;
	if(parent.frames(1).frames(2).document.AdmitPatient_form.admissiondate_readonly.value=="")
	{
		parent.frames(1).frames(2).document.AdmitPatient_form.visit_adm_date_time.readOnly = false;
		if(parent.frames(1).frames(2).document.AdmitPatient_form.backdated_admission_yn.value=='Y')
			parent.frames(1).frames(2).document.all.AdmitDate.disabled = false;
		if(parent.frames(1).frames(2).document.AdmitPatient_form.AdmitDate!=null)
		parent.frames(1).frames(2).document.AdmitPatient_form.AdmitDate.disabled = false;
	}
	parent.frames(1).frames(2).document.AdmitPatient_form.chief_complaint.readOnly = false;
	parent.frames(1).frames(2).document.AdmitPatient_form.ot_date_time.readOnly = false;
//	parent.frames(1).frames(2).document.AdmitPatient_form.bed_no.readOnly = false;
//	parent.frames(1).frames(2).document.AdmitPatient_form.room_no.readOnly = true;
	parent.frames(1).frames(2).document.all.OTDate.disabled = false;	
	parent.frames(1).frames(2).document.AdmitPatient_form.escort_name.readOnly = false;
	if(parent.frames(1).frames(2).document.AdmitPatient_form.escort_add_ln1)
	parent.frames(1).frames(2).document.AdmitPatient_form.escort_add_ln1.readOnly = false;
	if(parent.frames(1).frames(2).document.AdmitPatient_form.escort_add_ln2)
	parent.frames(1).frames(2).document.AdmitPatient_form.escort_add_ln2.readOnly = false;
	if(parent.frames(1).frames(2).document.AdmitPatient_form.escort_add_ln3)
	parent.frames(1).frames(2).document.AdmitPatient_form.escort_add_ln3.readOnly = false;
	if(parent.frames(1).frames(2).document.AdmitPatient_form.escort_add_ln4)
	parent.frames(1).frames(2).document.AdmitPatient_form.escort_add_ln4.readOnly = false;
	if(parent.frames(1).frames(2).document.AdmitPatient_form.escort_add_postal_code)
	parent.frames(1).frames(2).document.AdmitPatient_form.escort_add_postal_code.readOnly = false;
	parent.frames(1).frames(2).document.AdmitPatient_form.escort_tel_num.readOnly = false;
	parent.frames(1).frames(2).document.AdmitPatient_form.escort_mv_regn_no.readOnly = false;
	parent.frames(1).frames(2).document.AdmitPatient_form.emergency_detail.readOnly = false;
	parent.frames(1).frames(0).document.Select_form.booking_ref_no.readOnly = true;
}

function makeDisabled(booleanFlag)
{
	if(parent.frames.length>1)		
	{
	 if(parent.frames(1).frames.length>0)
	 {
		if(parent.frames(1).frames(0).document.Select_form && parent.frames(1).frames(0).name=="Select_frame")
		{
			var booking_ref_no		=	parent.frames(1).frames(0).document.Select_form.booking_ref_no;
			var patient_id			=	parent.frames(1).frames(0).document.Select_form.patient_id;
			var referral_id			=	parent.frames(1).frames(0).document.Select_form.referral_id;
		//	var encounter_id		=	parent.frames(1).frames(0).document.Select_form.encounter_id;
			var book_ref_no_search	=	parent.frames(1).frames(0).document.Select_form.book_ref_no_search;
			var patient_id_search	=	parent.frames(1).frames(0).document.Select_form.patient_id_search;
			var referral_id_search	=	parent.frames(1).frames(0).document.Select_form.referral_id_search;
	//	if( (trimCheck(booking_ref_no.value)) || (trimCheck(patient_id.value)) || (trimCheck(referral_id.value)) || (trimCheck(encounter_id.value)) )		
			if( (trimCheck(booking_ref_no.value)) || (trimCheck(patient_id.value)) || (trimCheck(referral_id.value)))
			{						
				if(parent.frames(1).frames(0).document.Select_form.referral_id.value != "")
					parent.frames(1).frames(3).document.all.referal_details.disabled = false
				else
					parent.frames(1).frames(3).document.all.referal_details.disabled = true

				if(booleanFlag)
				{
					parent.frames(1).frames(0).proceedFurther = true;
				}

				booking_ref_no.readOnly			=	booleanFlag;
				referral_id.readOnly			=	booleanFlag;
			//	encounter_id.readOnly			=	booleanFlag;
				book_ref_no_search.disabled		=	booleanFlag;
				referral_id_search.disabled		=	booleanFlag;
			}
			else
				parent.frames(1).frames(0).proceedFurther = true;
		 }
	  }
	}
}

function enableFlds()
{
	var call_func = parent.frames(2).document.AdmitPatient_form.call_func.value;
	if(call_func != "PATREG")
	{
		var admissionFor = parent.frames(0).document.Select_form.admission_for.value;
		var booking_ref_no = parent.frames(0).document.Select_form.booking_ref_no.value;
		var referral_id = parent.frames(0).document.Select_form.referral_id.value;
		var patient_id = parent.frames(0).document.Select_form.patient_id.value;

		if(admissionFor == 'D')
		{
			if(booking_ref_no != "" || referral_id != "" || patient_id != "")
			{
				parent.frames(0).document.Select_form.reset();
				parent.frames(0).document.Select_form.admission_for.options(2).selected =true;
				parent.frames(1).location.href ="../../eCommon/html/blank.html" ;
				parent.frames(2).location.reload();
			}
		
			parent.frames(0).document.all.PatNationality.innerHTML="";
			parent.frames(0).document.all.PatHCExp.innerHTML="";
			parent.frames(0).document.all.patient_cat.innerHTML="";
			parent.frames(0).document.all.occClass.innerHTML="";
			parent.frames(0).document.all.occDesc.innerHTML="";

			parent.frames(0).document.Select_form.booking_ref_no.disabled=false;
			parent.frames(0).document.Select_form.booking_ref_no.readOnly=false;
			parent.frames(0).document.Select_form.book_ref_no_search.disabled=false;

			parent.frames(0).document.Select_form.referral_id.disabled=true;
			parent.frames(0).document.Select_form.referral_id_search.disabled=true;

			parent.frames(0).document.Select_form.patient_id.disabled=false;
			parent.frames(0).document.Select_form.patient_id.readOnly=false;
			parent.frames(0).document.Select_form.patient_id_search.disabled=false;
		}
		else if(admissionFor == 'I')
		{
			if(booking_ref_no != "" || referral_id != "" || patient_id != "")
			{
				parent.frames(0).document.Select_form.reset();
				parent.frames(0).document.Select_form.admission_for.options(1).selected =true;
				parent.frames(1).location.href ="../../eCommon/html/blank.html" ;
				parent.frames(2).location.reload();
			}
			
			parent.frames(0).document.all.PatNationality.innerHTML="";
			parent.frames(0).document.all.PatHCExp.innerHTML="";
			parent.frames(0).document.all.patient_cat.innerHTML="";
			parent.frames(0).document.all.occClass.innerHTML="";
			parent.frames(0).document.all.occDesc.innerHTML="";
/*
			parent.frames(0).document.Select_form.booking_ref_no.disabled=false;
			parent.frames(0).document.Select_form.booking_ref_no.readOnly=false;
			parent.frames(0).document.Select_form.book_ref_no_search.disabled=false;

			parent.frames(0).document.Select_form.referral_id.disabled=false;
			parent.frames(0).document.Select_form.referral_id.readOnly=false;
			parent.frames(0).document.Select_form.referral_id_search.disabled=false;

			parent.frames(0).document.Select_form.patient_id.disabled=false;
			parent.frames(0).document.Select_form.patient_id.readOnly=false;
			parent.frames(0).document.Select_form.patient_id_search.disabled=false;
*/
		}
		else
		{
			parent.frames(0).document.Select_form.booking_ref_no.value='';
			parent.frames(0).document.Select_form.booking_ref_no.disabled=true;
			parent.frames(0).document.Select_form.book_ref_no_search.disabled=true;

			parent.frames(0).document.Select_form.referral_id.value='';
			parent.frames(0).document.Select_form.referral_id.disabled=true;
			parent.frames(0).document.Select_form.referral_id_search.disabled=true;

			parent.frames(0).document.Select_form.patient_id.value='';
			parent.frames(0).document.Select_form.patient_id.disabled=true;
			parent.frames(0).document.Select_form.patient_id_search.disabled=true;
			
			parent.frames(0).location.reload();
			parent.frames(1).location.href ="../../eCommon/html/blank.html" ;
			parent.frames(2).location.reload();
		}
	}
}

// added by Sridhar R on 11/28/2005 ...
// this function will enable & disable patientID/ReferralID/BookingRefNo based on IP param value...
function allowedAdmissionType()
{
	var allowed_admission_type = parent.frames(0).document.Select_form.allowed_admission_type.value;
	if(allowed_admission_type == "D") // Direct admission
	{
		parent.frames(0).document.Select_form.booking_ref_no.disabled=false;
		parent.frames(0).document.Select_form.booking_ref_no.readOnly=false;
		parent.frames(0).document.Select_form.book_ref_no_search.disabled=false;

		parent.frames(0).document.Select_form.referral_id.disabled=false;
		parent.frames(0).document.Select_form.referral_id.readOnly=false;
		parent.frames(0).document.Select_form.referral_id_search.disabled=false;

		parent.frames(0).document.Select_form.patient_id.disabled=false;
		parent.frames(0).document.Select_form.patient_id.readOnly=false;
		parent.frames(0).document.Select_form.patient_id_search.disabled=false;
	}
	else if(allowed_admission_type == "B") // Admission by booking
	{
		parent.frames(0).document.Select_form.booking_ref_no.disabled=false;
		parent.frames(0).document.Select_form.booking_ref_no.readOnly=false;
		parent.frames(0).document.Select_form.book_ref_no_search.disabled=false;

		parent.frames(0).document.Select_form.referral_id.disabled=true;
		parent.frames(0).document.Select_form.referral_id.readOnly=true;
		parent.frames(0).document.Select_form.referral_id_search.disabled=true;

		parent.frames(0).document.Select_form.patient_id.disabled=true;
		parent.frames(0).document.Select_form.patient_id.readOnly=true;
		parent.frames(0).document.Select_form.patient_id_search.disabled=true;
	}
	else if(allowed_admission_type == "R") // Admission by Referral
	{
		parent.frames(0).document.Select_form.booking_ref_no.disabled=true;
		parent.frames(0).document.Select_form.booking_ref_no.readOnly=true;
		parent.frames(0).document.Select_form.book_ref_no_search.disabled=true;

		parent.frames(0).document.Select_form.referral_id.disabled=false;
		parent.frames(0).document.Select_form.referral_id.readOnly=false;
		parent.frames(0).document.Select_form.referral_id_search.disabled=false;

		parent.frames(0).document.Select_form.patient_id.disabled=true;
		parent.frames(0).document.Select_form.patient_id.readOnly=true;
		parent.frames(0).document.Select_form.patient_id_search.disabled=true;
	}
	if(allowed_admission_type == "Z") // Referral or Booking
	{
		parent.frames(0).document.Select_form.booking_ref_no.disabled=false;
		parent.frames(0).document.Select_form.booking_ref_no.readOnly=false;
		parent.frames(0).document.Select_form.book_ref_no_search.disabled=false;

		parent.frames(0).document.Select_form.referral_id.disabled=false;
		parent.frames(0).document.Select_form.referral_id.readOnly=false;
		parent.frames(0).document.Select_form.referral_id_search.disabled=false;

		parent.frames(0).document.Select_form.patient_id.disabled=true;
		parent.frames(0).document.Select_form.patient_id.readOnly=true;
		parent.frames(0).document.Select_form.patient_id_search.disabled=true;
	}
}

 
/*
* This funtion is used to validate id and populates the values
* Arg1		: Calling object like referral id, booking ref no ,patient id
* Arg2		: Calling function like referral, booking ,patient
*/
function validatePat(obj,fld_lgnd) 
{
	if(trimCheck(obj.value)=="") return false;
	if(validatePat!='' && validatePat !=null)
	{
		var fields = new Array(obj);
		var names = new Array(fld_lgnd);
		if(SpecialCharCheck(fields,names,'',"A",'') )
		{
			validateSelect(obj.name);
			//setTimeout("validateSelect(obj.name)",1000);
		}
		else
		{
			obj.select()
			obj.focus()
		}
			
   }   
}
/*
 * This function will call the AdmissionValidation.jsp if patient id or referral id * or enocutner id or booking ref no exists
 */
function validateSelect(obj) 
{
	parent.frames(1).location.href = '../../eCommon/html/blank.html';
	if( document.Select_form.patient_id.value != "")
		var patient     = document.Select_form.patient_id.value;
	else
		var patient="";
	
	initFields();
    var admission_for  = document.Select_form.admission_for.value;
	var bookingref		= document.Select_form.booking_ref_no.value;
	var referralid      = document.Select_form.referral_id.value;
	var operatorstation = document.Select_form.operator_station.value;
	var bkg_type		= document.Select_form.admission_for.value;
	var queryString		= document.Select_form.queryString.value;	
	var bkg_grace_period= document.Select_form.bkg_grace_period.value;	

	var visit_adm_date_time = "";
	if(parent.frames(2).document.AdmitPatient_form != null)
	{
		if(parent.frames(2).document.AdmitPatient_form.visit_adm_date_time)
		visit_adm_date_time	=	parent.frames(2).document.AdmitPatient_form.visit_adm_date_time.value;
	}
	if( !(proceedFurther) && actionOnField!=obj ) 
	{
		return false;
	}
	proceedFurther	=	false;
	actionOnField	=	obj;
	
	if(referralid !=''  || bookingref != '' || patient != '' )
	{
		var HTMLVal = "<html><body CLASS='MESSAGE'><form name='dum_form' method='post' action='../../eIP/jsp/AdmissionValidation.jsp'>"+
		"<input type='hidden' name='field1' value=\""+bookingref+"\"> "+
		"<input type='hidden' name='bkg_grace_period' value=\""+bkg_grace_period+"\"> "+
		"<input type='hidden' name='admission_for' value=\""+admission_for+"\"> "+
		"<input type='hidden' name='field2' value=\""+patient+"\">"+
		"<input type='hidden' name='field4' value='Select_form'>"+
		"<input type='hidden' name='field5' value=\""+referralid+"\"> "+
		"<input type='hidden' name='queryString' value=\""+queryString+"\"> "+
		"<input type='hidden' name='visit_adm_date_time' value=\""+visit_adm_date_time+"\"> "+
		"<input type='hidden' name='booking_type' value=\""+bkg_type+"\"> "+
		"<input type='hidden' name='operator_station' value=\""+operatorstation+"\"> "+
		"</form></body></html>";
		parent.parent.messageFrame.document.body.insertAdjacentHTML('AfterBegin',HTMLVal);
		parent.parent.messageFrame.document.dum_form.submit();
		
	}
}

function ChkNursingUnit()
{
	if (parent.frames(2).document.AdmitPatient_form.nursing_unit.value=='')
	{
		

	}
}