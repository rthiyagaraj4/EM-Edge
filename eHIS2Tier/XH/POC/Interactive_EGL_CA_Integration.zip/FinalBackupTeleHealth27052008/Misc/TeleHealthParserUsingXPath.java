package eCA;

import java.util.regex.*;
import org.w3c.dom.*;
import java.io.*;
import javax.xml.parsers.*;
import java.util.*;
import org.xml.sax.*;
import org.apache.xpath.XPathAPI;
import java.sql.*;

public class TeleHealthParser
{
	StringBuffer displayString	= new StringBuffer();
	StringBuffer strErrorMsg	= new StringBuffer();

	public TeleHealthParser()
	{
		strErrorMsg.delete(0,strErrorMsg.length());
		displayString.delete(0,displayString.length());
	}

	public String getDocuments(Connection con,String XMLContent,String strPatientId,String strSessionid)
	{
		boolean	bHdrStatus		=	false;
		boolean bBodyStatus		=	false;

		PreparedStatement pst	= null;

		Document doc			=	null;

		StringBuffer sbXPathDefn = new StringBuffer();
		
		NodeList	nlDocs			=	null;
		Node		ndDoc			=	null,			ndCurDocNode		=	null;

		int nlDocLen				=	0,		nCurIdx	=	0,				nUpdRecs		=	0;

		try
		{

			String strQuery =	"DELETE FROM XH_CLINICAL_INTEGRATION WHERE PATIENT_NRIC_ID = ? AND SESSION_ID = ? ";
			
			pst	=	con.prepareStatement(strQuery);

			pst.setString(1,strPatientId);
			pst.setString(2,strSessionid);

			nUpdRecs	=	pst.executeUpdate();

			if(nUpdRecs >= 0)
				con.commit();

			if( pst != null) pst.close();

			sbXPathDefn.delete(0,sbXPathDefn.length());
			sbXPathDefn.append("CLINICALDATA/levelone");

			String strTTTT = getContentNew(XMLContent,strPatientId,strSessionid,con);

/*


			try
			{
				doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new ByteArrayInputStream(XMLContent.getBytes()));			
			}
			catch (Exception e31)
			{
				strErrorMsg.append("APP-CA801 The XML Document received is not well formed....   ");
				e31.printStackTrace(System.err);
				return strErrorMsg.toString();
//				System.out.println( " Error in the TeleHealth Processor forming the doc "  + e31.getMessage());
			}

			nlDocs	= XPathAPI.selectNodeList(doc,sbXPathDefn.toString());

//			System.out.println(" Total Number Docs  Updated " + nlDocs.getLength());
			
			if(nlDocs != null)
			{
					nlDocLen	= nlDocs.getLength();
					
					for(nCurIdx = 0; nCurIdx < nlDocLen ; nCurIdx++)
					{
						try
						{
							ndDoc		= nlDocs.item(nCurIdx);
	
							if(ndDoc != null)
							{
								ndCurDocNode	=	ndDoc.cloneNode(true);

								try
								{
									bHdrStatus	= getDocHeader(ndCurDocNode,nCurIdx,strSessionid,strPatientId,con);


//									if(!bHdrStatus)
//										strErrorMsg.append("APP-CA805  Error in Getting the Header for the Document Number " + nCurIdx+ ".....   ");
								}
								catch (Exception e51)
								{
									strErrorMsg.append("APP-CA805 Error in Getting the Header for the Document Number " + nCurIdx + "......   ");
									e51.printStackTrace(System.err);
									System.out.println( " Error in Getting the Header for the document number " +nCurIdx);
								}
							}
						}
						catch (Exception e4)
						{
							strErrorMsg.append("APP-CA802 Error in Splitting the Header & Body in the Document Number " + nCurIdx + " ......   ");
							e4.printStackTrace(System.err);
							System.out.println( " Error from the Tele Health Process @ 4 " + e4.getMessage());
						}
				}
			}*/
		}
		catch (Exception e41)
		{
			strErrorMsg.append("APP-CA803 Error in Parsing (Finding the Root nodes) the XML Document Received.....     ") ;
			e41.printStackTrace(System.err);
			System.out.println( " Error from the Tele Health Process @ 41 " + e41.getMessage());
		}

		finally
		{
			doc= null;
			return strErrorMsg.toString();
		}
	}	

	public boolean getDocHeader(Node ndDoc,int nIndex,String strSessionId,String strPatId,Connection con)
	{
		String strRtnHdr		=	"";
		String strRtnBody		=	"";
		String nUpdStatus		=	"0";

		boolean bOpStatus		=	true;

		int nStIdx				=	0,			nEndIdx		=	0;

		try
		{
			displayString.delete(0,displayString.length());

			String strTemp	= NdtoStr(ndDoc);

			if(!strTemp.equals("") )
			{
				nStIdx		=	strTemp.indexOf("<clinical_document_header>");
				nEndIdx		=	strTemp.indexOf("</clinical_document_header>");

				if(nStIdx != -1 && nEndIdx != -1)
					strRtnHdr	=	strTemp.substring(nStIdx,nEndIdx+27);
				else
				{
					strErrorMsg.append("APP-CA805  Error in Getting the Header in the Document Number " + nIndex + " ......   ");
					bOpStatus	= false;
				}

//				System.out.println( " returned Header " + strRtnHdr);
/*
				nStIdx		=	strTemp.indexOf("<body>");

				if(nStIdx == -1)
				{
					nStIdx		=	strTemp.indexOf("<Body>");
					nEndIdx		=	strTemp.indexOf("</Body>");
				}
				else
					nEndIdx		=	strTemp.indexOf("</body>");
				
			
				if(nStIdx != -1 && nEndIdx != -1)
					strRtnBody	=	strTemp.substring(nStIdx,nEndIdx+7);
				else
				{
					strErrorMsg.append("APP-CA805  Error in Getting the Body in the Document Number " + nIndex + " ......   ");
					bOpStatus	= false;
				}
*/

				strRtnBody	=	strTemp;
//				System.out.println( " returned Body " + strRtnBody);

				nUpdStatus	= UpdateDb(nIndex,strSessionId,strPatId,strRtnHdr,strRtnBody,con);

			}
		}
		catch (Exception e701)
		{
			bOpStatus	= false;
			e701.printStackTrace(System.err);
		}
		finally
		{
			return bOpStatus;
		}
	}

	public String getDocBody(Node ndDoc)
	{
		String strRtnBody		=	"";
		String strXPathDefn		=	"";

		strXPathDefn	=	"/levelone/body|/levelone/Body";

		Node ndDocBody	=	null,		ndDocBodyFull	=	null;

		try
		{
			ndDocBody		=	XPathAPI.selectSingleNode(ndDoc,strXPathDefn);

			if(ndDocBody != null)
				ndDocBodyFull	= ndDocBody.cloneNode(true);
			else
				strRtnBody	=	"Error";

			if( !strRtnBody.equals("Error") )
			{
				displayString.delete(0,displayString.length());
				strRtnBody	= NdtoStr(ndDocBodyFull);
			}
		}
		catch (Exception e701)
		{
			strRtnBody	=	"Error";
			e701.printStackTrace(System.err);
		}
		finally
		{
			return strRtnBody;
		}
	}

	public String UpdateDb(int nIdx,String strSessid,String strPatId,String strHead,String strBody,Connection con)
	{
//		Connection			con		=	null;
		CallableStatement	csDb	=	null;

		String strErrorCode		=	"0";
		String strErrorMesg =	"";

		try
		{
			csDb	= con.prepareCall("{call xh_cl_in_up_del(?,?,?,?,?,?,?,?,?,?,?)}");
			
			csDb.setString(1,"I");
			csDb.setString(2,strPatId);
			csDb.setString(3,strSessid);
			csDb.setInt(4,nIdx);
			csDb.setString(5,strHead);
			csDb.setString(6,strBody);
			csDb.setString(7,"E");
			csDb.setString(8,"E");
			csDb.setString(9,null);
			csDb.registerOutParameter(10,java.sql.Types.VARCHAR);
			csDb.registerOutParameter(11,java.sql.Types.VARCHAR);

			csDb.execute();

			strErrorCode		= csDb.getString(10);
			strErrorMesg		= csDb.getString(11);

			if(strErrorMesg == null)
				strErrorMesg = "";

			if(!strErrorMesg.equals("") )
			{
				strErrorMsg.append("APP-CA907 Updation Failed for the Document Number "+nIdx);
			}
		}
		catch (Exception e901)
		{
			System.out.println( " Error in updating the database e 901 " + e901.getMessage());
			e901.printStackTrace(System.err);
		}
		
		finally
		{
			return strErrorCode;
		}
	}

	public String NdtoStr(Node node)
    {
		try
		{
			if (node == null)
			{
				return "";
			}
        int type = node.getNodeType();
        switch (type)
        {
            case Node.DOCUMENT_NODE:
            {
				displayString.append("");
                NdtoStr(((Document) node).getDocumentElement());
                break;
            }
            case Node.ELEMENT_NODE:
            {
				displayString.append("<");
                displayString.append(node.getNodeName());
                int length = (node.getAttributes() != null) ? node.getAttributes().getLength() : 0;
                Attr attributes[] = new Attr[length];
                for (int loopIndex = 0; loopIndex < length; loopIndex++)
                {
                    attributes[loopIndex] = (Attr) node.getAttributes().item(loopIndex);
                }
                for (int loopIndex = 0; loopIndex < attributes.length; loopIndex++)
                {
                    Attr attribute = attributes[loopIndex];
                    displayString.append(" ");
                    displayString.append(attribute.getNodeName());
                    displayString.append("=\"");
                    displayString.append(replaceSpecialChars(attribute.getNodeValue()));
                    displayString.append("\"");
                }
                displayString.append(">");

                NodeList childNodes = node.getChildNodes();

				if (childNodes != null)
                {
                    length = childNodes.getLength();

                    for (int loopIndex = 0; loopIndex < length; loopIndex++)
                    {
                        NdtoStr(childNodes.item(loopIndex));
                    }
                }
                break;
            }

            case Node.CDATA_SECTION_NODE:
            {
                displayString.append("<![CDATA[");
                displayString.append(node.getNodeValue());
                displayString.append("]]>");
            }
            case Node.TEXT_NODE:
            {
                String newText = replaceSpecialChars(node.getNodeValue());
                if (newText.length() > 0) {
                    displayString.append(newText);
                }
                break;
            }
            case Node.PROCESSING_INSTRUCTION_NODE:
            {
                displayString.append("<?");
                displayString.append(node.getNodeName());
                String text = node.getNodeValue();
                if (text != null && text.length() > 0)
                {
                    displayString.append(text);
                }
                displayString.append("?>");
                break;
            }
        }
        if (type == Node.ELEMENT_NODE)
        {
            displayString.append("</");
            displayString.append(node.getNodeName());
            displayString.append(">");
        }
		}
		catch (Exception e678)
		{
			e678.printStackTrace(System.err);
		}

		finally
		{
			return displayString.toString();
		}
    }


	private String replaceSpecialChars(String input)
    {
        if (input.indexOf("&") != -1) input = input.replaceAll("&","&amp;");
		if (input.indexOf("<") != -1) input = input.replaceAll("<","&#60;");
		if (input.indexOf(">") != -1) input = input.replaceAll(">","&#62;");	
		if (input.indexOf("\\n") != -1) input = input.replaceAll("\\n","&lt;br&gt;");	

        return input;
    }

	public String getContentNew(String xmlContent,String strPatientId,String strSessionId,Connection con)
	{
		ArrayList Docs		= new ArrayList();
		ArrayList Headers       = new ArrayList();
		ArrayList Bodys         = new ArrayList();
		ArrayList contentList	= new ArrayList();

		String strRtnContent	=	"";

		int nSecSize	=	0;

		String nUpdStatus		=	"0";

		String sectionContent = "";

		StringBuffer content = new StringBuffer();
				
		boolean containsCaption = false;

		Docs = getElementsFromXML(xmlContent,"<levelone>","</levelone>");

		nSecSize	=	Docs.size();
		int nn =0;

		for(nn = 0; nn < nSecSize; nn++);
		{
			String strDoc = (String)Docs.get(nn);
			Headers = getElementsFromXML(strDoc,"<clinical_document_header>","</clinical_document_header>");
			Bodys    =getElementsFromXML(strDoc,"<body>","</body>");

			int nBodySize = Bodys.size();

			for (int kk =0;kk < nBodySize ;kk++ )
			{
				String strTemp = (String)Headers.get(kk);
				String strBB = (String)Bodys.get(kk);
				nUpdStatus	= UpdateDb(kk,strSessionId,strPatientId,strTemp,strBB,con);
			}

		}



		

		return "";
	}
	public ArrayList getElementsFromXML(String xmlTemp,String elementStart,String elementEnd)
	{
		int currentSectionIndex = 0;
		int endIndex = 0;

		String temp = "";

		// Converting to lower case.
		String xmlTempLower = xmlTemp.toLowerCase();
		elementStart = elementStart.toLowerCase();
		elementEnd = elementEnd.toLowerCase();
		

		ArrayList tempList = new ArrayList();

		while(true)
		{
			currentSectionIndex = xmlTempLower.indexOf(elementStart);

			if(currentSectionIndex < 0)
				break;
			
			endIndex = xmlTempLower.indexOf(elementEnd);
			temp = xmlTemp.substring(currentSectionIndex+elementStart.length(),endIndex);			
			xmlTemp = xmlTemp.substring(endIndex+elementEnd.length());
			xmlTempLower = xmlTempLower.substring(endIndex+elementEnd.length());
			tempList.add(temp);			
		}
		
		return tempList;
	}	
	public boolean  containsSubstring(String mainString, String strSearch)
	{
		boolean status = false; 
		strSearch = strSearch.trim();
		System.out.println("mainString "+mainString);
		System.out.println("strSearch "+strSearch+"DES");
		Pattern pattern = Pattern.compile(strSearch);
		Matcher matcher = pattern.matcher(mainString); 
		status = matcher.find();
		System.out.println("Status "+status);
//		System.out.println( " Pattern Match for " + strSearch + " - > " + status);

		return status; 
	}


}
