/************************************************************************************************************************
* Author   :	Ravindranath Oruganti
* Desc     :	Class contains utility methods that are all required for EGL integration.
************************************************************************************************************************/
package eCA;

import java.util.*;
import java.sql.*;
import java.net.*;
import java.io.*;
import java.util.regex.*;

public class TeleHealthUtil
{
	Properties properties = null;
//	Connection connection = null;
	CallableStatement oracleCallableStatement = null;
	CallableStatement oracleCallableStatement1 = null;
	Clob clobMessage = null;

	Socket clientSocket = null;
	InputStream inStream = null;
	OutputStream outStream = null;
	InputStreamReader inStreamReader = null;

	String requestMessage = "";
	String ipAddress = "";
	String propFile = "c:/ehis/reports/properties.ini";	
	String exceptionMsg = "";
	String responseMsg = "";
	String xmlDataToSend = "";

	int port = 0;
	int xmlCounter = 0;

	boolean exceptionExists = false;

	public void setRequestMessage(String reqMsg)
	{
		this.requestMessage = reqMsg;
	}
	public String getRequestMessage()
	{
		return requestMessage;
	}	
	public void setResponseMessage(String resMsg)
	{
		this.responseMsg = resMsg;
	}
	public String getResponseMessage()
	{
		return responseMsg;
	}


	public String validateResponseMessage(String ackMessage)
	{
		StringTokenizer tempTokens = null;
		ArrayList tokens = null;
		ArrayList mshSegment = null;
		ArrayList msaSegment = null;
		HashMap segments = new HashMap();

		exceptionExists = false;
		try
		{
			if(ackMessage != null && !ackMessage.equals(""))
			{
				//Tokenizing the message segment wise.
				StringTokenizer ackMsgTokens = new StringTokenizer(ackMessage,""+ackMessage.charAt(ackMessage.length()-1));				
				String nextToken = "";
				//iterating thru segments
				while(ackMsgTokens.hasMoreTokens())
				{
					nextToken = ackMsgTokens.nextToken();			
					//Tokenising each segment based on "|(pipe)" character
					tempTokens = new StringTokenizer(nextToken,"|");
					tokens = new ArrayList();
					String temp = "";
					int temp1 = 0;
					while(tempTokens.hasMoreTokens())
					{						
						if(temp1 == 0)
						{							
							temp = tempTokens.nextToken();
							if(containsSubstring(temp,"MSH"))
							{								
								temp = temp.substring(2,5);								
							}
							temp1 =1;							
						}
						else
							tokens.add(tempTokens.nextToken());																		
					}					
					// Adding the each segment to hashmap(segment name as key and its values in the arraylist)
					segments.put(temp,tokens);			
				}

				Set val = segments.keySet();
				Iterator it = val.iterator();
				// Iterating thru all the keys of the hashmap and checking for validations.
				while(it.hasNext())
				{
					String key = it.next().toString();					
					if(key.equals("MSH"))
					{
						mshSegment = (ArrayList)segments.get(key);						
					}					
					if(key.equals("MSA"))
					{
						msaSegment = (ArrayList)segments.get(key);						
					}
				}	

				if(msaSegment != null && !msaSegment.isEmpty())
				{					
					if(!(msaSegment.get(0).toString()).equals("AA"))
					{
						exceptionExists = true;
						if(msaSegment.size() >= 4)
						exceptionMsg = (String)msaSegment.get(1)+(String)msaSegment.get(4);
						else
						exceptionMsg = (String)msaSegment.get(1);
//						System.out.println("Not AA -- Response:"+exceptionMsg);						
					}
					if(mshSegment != null && !mshSegment.isEmpty())
					{		
						exceptionExists = true;
						String msh10 = (String)mshSegment.get(8);
						String msa2 = (String)msaSegment.get(1);
						System.out.println("MSH10 "+msh10);
						System.out.println("MSa2 "+msa2);
						if(!msh10.equals(msa2))
						{
							exceptionMsg = "Request message id and response message is not matching. Please Contact eGL administrator";
							System.out.println("Response Not matching:"+exceptionMsg);							
						}
					}
				}
			}
		}
		catch(Exception exception)
		{
			exception.printStackTrace(System.err);
			exceptionMsg = "Validating the response failed...";
			exceptionExists = true;
		}
		return responseMsg;
	}
	//Method checks whether given substring exists in the string or not.
	public boolean  containsSubstring(String mainString, String strSearch)
	{
		boolean status = false; 
		strSearch = strSearch.trim();
		System.out.println("mainString "+mainString);
		System.out.println("strSearch "+strSearch+"DES");
		Pattern pattern = Pattern.compile(strSearch);
		Matcher matcher = pattern.matcher(mainString); 
		status = matcher.find();
		System.out.println("Status "+status);
//		System.out.println( " Pattern Match for " + strSearch + " - > " + status);

		return status; 
	}

	public String buildMessage(Connection connection,String strPatientId,String strFacilityId,String strParamVal)
	{
		exceptionExists = false;
		requestMessage = "";

		try
		{			
//			connection = ConnectionManager.getConnection();

			oracleCallableStatement = connection.prepareCall("{call XHGENERIC.MESSAGE_BUILDERONLINE(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			oracleCallableStatement.setString(1,"XH");
			oracleCallableStatement.setString(2,"O");
			oracleCallableStatement.setString(3,"EGL");
			oracleCallableStatement.setString(4,"I05");
			oracleCallableStatement.setString(5,strFacilityId);
			oracleCallableStatement.setString(6,strParamVal);
			oracleCallableStatement.setString(7,"");
			oracleCallableStatement.setString(8,null);
			oracleCallableStatement.setString(9,"");
			oracleCallableStatement.setString(10,strPatientId);
			oracleCallableStatement.setString(11,"");
			oracleCallableStatement.setString(12,"");
			oracleCallableStatement.setString(13,"");
			oracleCallableStatement.setString(14,"eGL");
			oracleCallableStatement.registerOutParameter(15,java.sql.Types.CLOB);
//			System.out.println("Calling XHGENERIC.message_builder...");
			oracleCallableStatement.execute();
//			System.out.println("Aftre calling");

			clobMessage = oracleCallableStatement.getClob(15);
			requestMessage = "";
			StringBuffer sbTemp	= new StringBuffer();

			if(clobMessage != null)
			{
/*
				java.io.BufferedReader r = new java.io.BufferedReader(clobMessage.getCharacterStream());
				String line = null;
					
				while((line=r.readLine()) != null) 
				{
					sbTemp.append(line);
				}

				
				requestMessage = sbTemp.toString()+CHR(13)+CHR(28)+CHR(13);
				*/

					Reader readerMsg = clobMessage.getCharacterStream(); 			
					
					while(true)
					{			
						char charMsg[] = new char[999999];					
						int intData = readerMsg.read(charMsg);
					
						if ( intData > 0 )
							sbTemp.append(String.valueOf(charMsg,0,intData));
//							strMessage += String.valueOf(charMsg,0,intData);
						else 
							break;					
					}
					requestMessage = sbTemp.toString();
//					System.out.println("Message Received from eHIS "+strMessage);
					readerMsg.close();

			}						

			System.out.println(" Message from the procedure " + sbTemp.toString());
		}
		catch(Exception exception)
		{
			exception.printStackTrace(System.err);
			exceptionMsg = "Failed in Building the Message";
			exceptionExists = true;
		}
		finally
		{
			try
			{				
				if(oracleCallableStatement != null) oracleCallableStatement.close();							
			}
			catch(Exception exp)
			{
				exp.printStackTrace(System.err);
			}
		}
		return requestMessage;
	}

	//Method n
	public String sendRequest()
	{
		long msgSentTime = 0;
		long currentTime = 0;
		long responseTime = (20 * 1000) ;
		int resp = 0;

		boolean responseExists = false;

		exceptionExists = false;		
		String ackMessage = "";

		try
		{
			try
			{
				clientSocket	= new Socket(ipAddress,port);			
				inStream		= clientSocket.getInputStream();
				outStream		= clientSocket.getOutputStream();
				inStreamReader	= new InputStreamReader(inStream);				
			}
			catch(Exception exception)
			{
				exception.printStackTrace(System.err);

				if (exception.getClass().isInstance(new ConnectException()) ||
					exception.getClass().isInstance(new SocketException()) ||
					exception.getClass().isInstance(new IOException()) )
				{
//					System.out.println("*** Unable to Conect to remote machine ***");				
					exception.printStackTrace(System.err);
					exceptionMsg = "Remote Server Not Available to establish the connection with IP " + ipAddress +  " and Port " + port;
					exceptionExists = true;
					return exceptionMsg;
				}
			}				

			System.out.println("--- Connection Successfull ---");

			byte byteMsg[] = new byte[999999];
			int numBytes = 0;
			
			System.out.println("Sending Message:"+requestMessage);
			try
			{
				outStream.write(requestMessage.getBytes());	
				numBytes = inStream.read(byteMsg);
				if(numBytes > 0)
				{

					responseMsg = new String(byteMsg,0,numBytes);
					System.out.println("Received Response Message:"+responseMsg);
//					encodeMsg = URLEncoder.encode(strMessage, "UTF-8"); 				
				}

//				System.out.println(" AFTER WRITING " + requestMessage.length());
			}
			catch (Exception e5454)
			{
				e5454.printStackTrace(System.err);
				System.out.println(" Error inwriting " + e5454.getMessage());
			}

			System.out.println("Message sent, waiting for response...");
			
			msgSentTime			= System.currentTimeMillis();
			long currentDiff	= System.currentTimeMillis() - msgSentTime;
			responseExists		= false;

			// Checking for response for the specified period of time.
/*
			while(currentDiff < responseTime)
			{				
				responseExists = inStreamReader.ready();
			
				if(responseExists)
				{						
					numBytes = inStream.read(byteMsg);
				
					if(numBytes > 0)
					{
						responseMsg = new String(byteMsg,0,numBytes);
						System.out.println("Received Response Message:"+responseMsg);						
					}
					break;					
				}

				currentDiff = System.currentTimeMillis() - msgSentTime;
			}
*/
			responseExists = true;
			if(!responseExists)
			{
				System.out.println("*** Request Times out ***");				
				exceptionExists = true;
				exceptionMsg = "Request is timed out... Re-try";
			}
		}
		catch(Exception exception)
		{
			exception.printStackTrace(System.err);				
			exceptionExists = true;
			exceptionMsg = "Error in sending/receiving in message";
		}
		finally
		{

			try
			{

				if(inStreamReader != null) inStreamReader.close();
				if(inStream != null) inStream.close();
				if(outStream != null) outStream.close();
			}
			catch(Exception exception)
			{
				exception.printStackTrace(System.err);
			}
	
		}
					return responseMsg;
	}

	// Method retrieves the IP address and port no from the .ini file
	public void getDestinationDetails()
	{
		exceptionExists = false;
		properties		= new Properties();

		try
		{
			properties.load(new FileInputStream(propFile));
			ipAddress	= (String)properties.getProperty("IP");
			port		= Integer.parseInt(properties.getProperty("port"));
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			exceptionMsg = "Fetching communication details failed...";
			exceptionExists = true;
		}
		finally
		{
			properties = null;
		}
	}

	public String filterXMLContent(String ackMessage)
	{
//		System.out.println("ACKMESSAGE "+ackMessage);	 

		int i			= 0;
		int index		= 0;
		int nextOBXIndex = 0; 
		int xmlCounter = 0;

		boolean xmlDataExists = false;

		String xmlData = "";
		String xmlDataToSend = "";
		String xmlContent = "";

		exceptionExists = false;

		try
		{
			int ackMsgLen = ackMessage.length();
			String tt = (char)13+"OBX";
			System.out.println("tt "+tt);

			while(index < ackMsgLen)
			{
				i = 0;
				int tempIndex = index;
				index = ackMessage.indexOf(tt,index) + 4;
				if(index < tempIndex)
					break;
				System.out.println("INDEX "+index);
				nextOBXIndex = ackMessage.indexOf(tt,index)+4;
				System.out.println("nextOBXIndex "+nextOBXIndex);
				if(nextOBXIndex < index)
					nextOBXIndex = ackMsgLen;
				String tempVal = "";

				while(true)
				{
					char strChar = ackMessage.charAt(++index);
					System.out.println("CHARAT:"+strChar);
					if(i == 1)
					{
						tempVal = tempVal+strChar;
						System.out.println("tempVal:"+tempVal);
					}
					else if(i > 1)
					{						
						String xmlExists = ackMessage.substring(index,nextOBXIndex);
						int xmlIndex = xmlExists.indexOf("<levelone>");
						if(xmlIndex != -1)
						{
							System.out.println("INDEXOF "+xmlIndex);
							xmlDataExists = true;								
							xmlData = xmlExists.substring(xmlIndex);
							System.out.println("DATAAAAA "+xmlData);
							int lastIndex = xmlData.indexOf("</levelone>");
							System.out.println("lastIndex "+lastIndex);
							xmlData = xmlData.substring(0,lastIndex+11);									
						//	xmlStrings.add(xmlData);
							xmlCounter++;
							
							if(xmlCounter == 1)
							{
								xmlDataToSend = xmlData;
							}						
						
							xmlContent = xmlContent+xmlData;
							System.out.println("xmlCounter "+xmlCounter);									
						}
						
						break;
					}
					

					if(strChar == '|')
					{
						i++;
					}					
				//	if(i == 4)	break;
				}
			}								
		}
		catch(Exception exception)
		{
			exception.printStackTrace(System.err);
			exceptionMsg = "Error in getting XML content";
			exceptionExists = true;
		}
		return xmlContent;
	}

	public void processReponseMessage(Connection connection,String ackMessage)
	{
		CallableStatement oracleCallableStatement1 = null;

		String arg1 = null;
		String arg2 = null;
		String arg3 = null;
		String arg4 = null;
		String arg5 = null;
		String arg6 = null;
		
		try
		{
//			connection = ConnectionManager.getConnection();
			System.out.println("Calling XHGENERIC.GET_EGL_ELEMENT_VALUE...");
			// For tokenising purpose PL/SQL procedure is used curently, PL/SQL procodure call to be removed by adding java logic later.
			oracleCallableStatement1 = connection.prepareCall("{call XHGENERIC.GET_EGL_ELEMENT_VALUE(?,?,?,?,?,?,?,?)}");
			oracleCallableStatement1.setString(1,ackMessage);
			oracleCallableStatement1.registerOutParameter(2,java.sql.Types.VARCHAR);
			oracleCallableStatement1.registerOutParameter(3,java.sql.Types.VARCHAR);
			oracleCallableStatement1.registerOutParameter(4,java.sql.Types.VARCHAR);
			oracleCallableStatement1.registerOutParameter(5,java.sql.Types.VARCHAR);
			oracleCallableStatement1.registerOutParameter(6,java.sql.Types.VARCHAR);
			oracleCallableStatement1.registerOutParameter(7,java.sql.Types.VARCHAR);
			oracleCallableStatement1.setString(8,"H");
			oracleCallableStatement1.execute();
			
			arg1 = oracleCallableStatement1.getString(2);
			arg2 = oracleCallableStatement1.getString(3);
			arg3 = oracleCallableStatement1.getString(4);
			arg4 = oracleCallableStatement1.getString(5);
			arg5 = oracleCallableStatement1.getString(6);
			arg6 = oracleCallableStatement1.getString(7);

			System.out.println("p_Org_code_out "+arg1);
			System.out.println("p_Validity_From_out "+arg5);
			System.out.println("p_Gur_Name_out "+arg2);
			System.out.println("p_Salary_out "+arg3);
			System.out.println("p_Grade_out "+arg4);
			System.out.println("p_Validity_to_out "+arg6);
		}
		catch(Exception exception)
		{
			exception.printStackTrace(System.err);
		}
		finally
		{
			try
			{
				if(oracleCallableStatement1 != null) oracleCallableStatement1.close();				
//				if(connection != null) ConnectionManager.returnConnection(connection);
			}
			catch(Exception exception)
			{
				exception.printStackTrace(System.err);
			}
		}
	}


	public String processCommunication(Connection con,String strPatientId,String strFacilityId,String strParamVal)
	{
		buildMessage(con,strPatientId,strFacilityId,strParamVal);		
		
		if(exceptionExists)
			return "Error:"+exceptionMsg;
		
		getDestinationDetails();			

		if(exceptionExists)
			return "Error:"+exceptionMsg;
		
		System.out.println("IPADDRESS "+ipAddress);
		System.out.println("PORT "+port);

		String ackMessage = sendRequest();

		if(exceptionExists)
			return "Error:"+exceptionMsg;

/*	
		String responseMsg = validateResponseMessage(ackMessage);

		if(exceptionExists)
		{
			return "Error:"+exceptionMsg;
		}
*/
		System.out.println(" Getting the Leng " + ackMessage.length());
		String xmlData = filterXMLContentNew(ackMessage);

		/* reaplcing to lowercase */
		xmlData = replaceString(xmlData,"<BR>","    ");
		xmlData = replaceString(xmlData,"<Levelone>","<levelone>");
		xmlData = replaceString(xmlData,"</Levelone>","</levelone>");

		xmlData = replaceString(xmlData,"<Body>","<body>");
		xmlData = replaceString(xmlData,"</Body>","</body>");
		
		xmlData = replaceString(xmlData,"<Section>","<section>");
		xmlData = replaceString(xmlData,"</Section>","</section>");

		xmlData = replaceString(xmlData,"<Caption>","<caption>");
		xmlData = replaceString(xmlData,"</Caption>","</caption>");
		
		xmlData = replaceString(xmlData,"<Content>","<content>");
		xmlData = replaceString(xmlData,"</Content>","</content>");
		
		xmlData = replaceString(xmlData,"<Paragraph>","<list>");
		xmlData = replaceString(xmlData,"</Paragraph>","</list>");
		xmlData = replaceString(xmlData,"<P>","<list>");
		xmlData = replaceString(xmlData,"</P>","</list>");

		xmlData = replaceString(xmlData,"<List>","<list>");
		xmlData = replaceString(xmlData,"</List>","</list>");

		xmlData = replaceString(xmlData,"<Item>","<item>");
		xmlData = replaceString(xmlData,"</Item>","</item>");

		StringBuffer sbRtnData = new StringBuffer();
		sbRtnData.append("<CLINICALDATA>");
		sbRtnData.append(xmlData);
		sbRtnData.append("</CLINICALDATA>");
		System.out.println("Returned XML CONTENT convertedto lower case "+sbRtnData.toString());

//		processReponseMessage(con,ackMessage);

		return sbRtnData.toString();
	}

	public HashMap returnsSegmentArray(Connection con,String msgtext)
	{
//		Connection con=null;
		String individualSegment="";
		String segmentSeparator="";
		char separatorDelimiter;
		char firstCharOfMSH;
		String segmentName="";
		String A[][]=null;
		String comp[][]=null;
		HashMap hashmap=new HashMap();
		boolean chkStat=false;
		int leng=0;
		chkStat=containsSubstring(msgtext,"MSH");
		try
		{
//			con=ConnectionManager.getConnection();
			separatorDelimiter=msgtext.charAt((msgtext.length())-1);
			if(chkStat){ segmentSeparator=""+separatorDelimiter; }
			else { segmentSeparator=""; } 
			StringTokenizer st=new StringTokenizer(msgtext,segmentSeparator);
			if(chkStat) leng=st.countTokens()-1;
			else  leng=st.countTokens();
			System.out.println("leng of gc 1  :"+st.countTokens());
			System.out.println("leng of gc :"+leng);

			A=new String[leng][2];
			int row=0;
			while (st.hasMoreTokens())
			{
				ResultSet rss=null;
				Statement stmts=null;
				individualSegment=st.nextToken().trim();
				if(individualSegment.length()!=0){
				firstCharOfMSH=individualSegment.charAt(0);
				if(chkStat)
				{
					if (firstCharOfMSH==separatorDelimiter) segmentName=individualSegment.substring(1,4);
					else segmentName=individualSegment.substring(0,3);
				}
				else 
				{
					segmentName=individualSegment.substring(0,2);
				} 
				A[row][0]=segmentName;
				String msgsql1="SELECT segment_name FROM xh_segment WHERE segment_type ='"+segmentName+"'";
				stmts=con.createStatement();
				rss=stmts.executeQuery(msgsql1);
				while(rss.next())
				{					
					A[row][1]= rss.getString(1);					
				}
				if(rss!=null) rss.close();
				if(stmts!=null) stmts.close(); 
				comp=getSegmentComponents(con,msgtext,individualSegment);
				hashmap.put("comp"+row,comp);
				row++;
				} 
			}

		}
		catch(Exception e1)
		{
			System.out.println("Error in returnsSegmentArray method of xhreturnarray:"+e1.toString()); 
			e1.printStackTrace(System.err);
		}
		hashmap.put("segment",A);
		return hashmap;
	}	//End of method returnsSegmentArray.

	private String[][] getSegmentComponents(Connection con,String msgtext,String segmentString)
	{
		char firstCharOfMSH;
		String segmentName=null;
		String tempSegment=null;
		String[] components=null;
        ResultSet rss=null;
        Statement stmts=null;
		String A[][]=null;
		boolean chkStat=false;
      

		try
		{	
			tempSegment=segmentString.trim();
			firstCharOfMSH=tempSegment.charAt(0);
		
		    chkStat=containsSubstring(msgtext,"MSH");
			if(chkStat)	{
			if (firstCharOfMSH=='') segmentName=tempSegment.substring(1,4);
			else segmentName=tempSegment.substring(0,3);
			}
			else segmentName=tempSegment.substring(0,2);

			components= tempSegment.split("\\|");
			int leng=0;
			leng=components.length-1;
			A=new String[leng][2];
		    stmts=con.createStatement();
			int row=0;
		    for(int i=1;i<components.length; i++)
			{				
				String msgsql1="SELECT element_name FROM xh_segment_element_seq WHERE segment_type ='"+segmentName+"' and element_seq ="+i ;				
				rss=stmts.executeQuery(msgsql1);
				while(rss.next()){
		        A[row][0]= rss.getString(1);
				System.out.println("SEGMENT "+segmentName);
				System.out.println(rss.getString(1)+" COMPONENTS "+components[i]);
				if(segmentName.equalsIgnoreCase("MSH") && i == 1)
					A[row][1]= "|";
				else if(segmentName.equalsIgnoreCase("MSH"))
					A[row][1]= components[i-1];
				else
					A[row][1]= components[i];
		        }
				if(rss!=null) rss.close();
		  
			  row++;			
			}
			if(stmts!=null) stmts.close(); 
	      segmentName=null;
		}catch(Exception exception)
		  {
			System.out.println(" Exception "+exception);
			exception.printStackTrace(System.err);
			
		  }
       return A;
	}

	public String getXMLData(int reqPageNo,String xmlContent)
	{		
		System.out.println("Calling getXMLData ...");		
		String xmlData = null;
		xmlDataToSend = "";

		System.out.println("xmlContent "+xmlContent);
		System.out.println("reqPageNo "+reqPageNo);

		boolean xmlDataExists = false;
		int xmlIndex = 0;
		int xmlEndIndex = 0;
		int strIndex = xmlContent.length();
		xmlCounter = 0;
		int i =0 ;

		while(true)
		{	
			if(i == 0)
			{
				xmlIndex = xmlContent.indexOf("<levelone>");
				i++;
			}
			else
			{
				xmlIndex = xmlContent.indexOf("<levelone>",xmlIndex+10);
			}			
			if(xmlIndex != -1)
			{
				if(xmlIndex < xmlEndIndex)
				{	
					System.out.println("xmlCounter "+xmlCounter);
					System.out.println("xmlDataToSend "+xmlDataToSend);
					break;
				}
				xmlDataExists = true;								
				xmlData = xmlContent.substring(xmlIndex);
				xmlEndIndex = xmlData.indexOf("</levelone>");
				xmlData = xmlData.substring(0,xmlEndIndex+11);												
				xmlCounter++;
				
				if(xmlCounter == reqPageNo)
				{					
					xmlDataToSend = xmlData;
					System.out.println("Data to be sent: "+xmlDataToSend);
				}
			}
			else
			{
//				System.out.println("xmlCounter "+xmlCounter);
//				System.out.println("xmlDataToSend "+xmlDataToSend);
				break;
			}
		}
		return xmlDataToSend;

	} // end of getXMLData method

	// For Alternative Options

	public String getContent(String xmlContent,String caption,int nSecPos)
	{
		System.out.println( " in Get Content Searching For " + caption);
		ArrayList sections		= new ArrayList();
		ArrayList contentList	= new ArrayList();

		String strRtnContent	=	"";

		int nSecSize	=	0;

		String sectionContent = "";

		StringBuffer content = new StringBuffer();
				
		boolean containsCaption = false;

		sections = getElementsFromXML(xmlContent,"<section>","</section>");

		nSecSize	=	sections.size();

		if(nSecSize > nSecPos) 
		{
			sectionContent = sections.get(nSecPos).toString();
			containsCaption = containsSubstring(sectionContent.toLowerCase(),caption.toLowerCase());
		}
		else
			containsCaption = false;

	//	System.out.println(" Contains caption for " + caption + " -- > "  + containsCaption);
		if(!containsCaption)
		{
			for(int i=0; i < nSecSize; i++)
			{			
			//	System.out.println(" n Sec Size "  + i + " / " + caption);
				sectionContent = (String) sections.get(i);
			//	System.out.println( " sectionContent of i  " + sectionContent);

				containsCaption = containsSubstring(sectionContent.toLowerCase(),caption.toLowerCase());
			//	System.out.println( " containsCaption  " + containsCaption);		
				if(containsCaption)
					break;
			}
		}	

		if(containsCaption)
		{
			if(!sectionContent.equals("") )
			{
				contentList = getElementsFromXML(sectionContent,"<content>","</content>");

				int nContSize = 0;

				nContSize = contentList.size();

			//	System.out.println(" total number of contents " + nContSize + " for " + caption);
	
				for(int i=0 ;i < nContSize; i++)
				{				
					String strTT = (String) contentList.get(i);

					//content.append( (String) contentList.get(i));
					
					content.append(strTT);

					if(strTT != null && !strTT.equals(""))
						content.append(",");;
				}

				strRtnContent	= content.toString();
	
				if(!strRtnContent.equals("") )
					strRtnContent	=	strRtnContent.substring(0,strRtnContent.length()-1);

//				System.out.println(" Returned Content " + strRtnContent);
			}
		}

//		System.out.println( " in Get Content Resulted Content " + strRtnContent);
		return strRtnContent;
	}

	/*
	* Method returns an arraylist containing elements of data that exists between the passes elementStart
	* and elementEnd by calculating the no of tags.
	*/
	public ArrayList getElementsFromXML(String xmlTemp,String elementStart,String elementEnd)
	{
		int currentSectionIndex = 0;
		int endIndex = 0;

		String temp = "";

		// Converting to lower case.
		String xmlTempLower = xmlTemp.toLowerCase();
		elementStart = elementStart.toLowerCase();
		elementEnd = elementEnd.toLowerCase();
		

		ArrayList tempList = new ArrayList();

		while(true)
		{
			currentSectionIndex = xmlTempLower.indexOf(elementStart);

			if(currentSectionIndex < 0)
				break;
			
			endIndex = xmlTempLower.indexOf(elementEnd);

			if(endIndex < 0)
				break;

			temp = xmlTemp.substring(currentSectionIndex+elementStart.length(),endIndex);			
			xmlTemp = xmlTemp.substring(endIndex+elementEnd.length());
			xmlTempLower = xmlTempLower.substring(endIndex+elementEnd.length());
			tempList.add(temp);			
		}
		
		return tempList;
	}	
	public String[] getHeaders(String headerString)
	{				
		String header1 = "";
		String header2 = "";
		String docContent = "";

		String [] headers = new String[2];

		ArrayList tempList = new ArrayList();		

		tempList = getElementsFromXML(headerString,"<document_type_cd","</document_type_cd>");
		if(tempList.size() > 0)	
		{
			docContent = (String)tempList.get(0);
			if(docContent != null && !docContent.equals(""))
				headers[0] = getHeaderContent(docContent,"DN");
		}
		else
			headers[0] = "";

		tempList.clear();
		docContent = "";

		tempList = getElementsFromXML(headerString,"<organization.nm","</organization.nm>");
		if(tempList.size() > 0)	
		{
			docContent = (String)tempList.get(0);
			if(docContent != null && !docContent.equals(""))
				headers[1] = getHeaderContent(docContent,"V");
		}
		else
			headers[1] = "";

		System.out.println("header1 "+headers[0]);
		System.out.println("header2 "+headers[1]);
		
		return headers;
	}

	public String getHeaderContent(String content,String searchFor)
	{		
		boolean containsStr = false;

		String header = "";

		int tempStartIndex = 0;
		int tempEndIndex = 0;
		
		content = formatString(content); // truncating all spaces before "=" symbol
		
		containsStr = containsSubstring(content,searchFor+"=");
		if(containsStr)
		{
			int index = content.indexOf(searchFor+"=")+1;			
			tempStartIndex = content.indexOf("\"",index);
			tempEndIndex = content.indexOf("\"",tempStartIndex+1);
			header = content.substring(tempStartIndex+1,tempEndIndex);			
		}	
		return header;
	}

	public String formatString(String content)
	{
		int index = 0;
		
		while(true)
		{
			index = content.indexOf(" =");
			if(index > 0)
			{
				content = content.replaceAll(" =","=");
			}
			else
			{
				break;
			}
		}
		return content;
	}
	public String filterXMLContentNew(String ackMessage)
	{
		System.out.println("ACKMESSAGE "+ackMessage);
		int i = 0;
		int index = 0;
		int nextOBXIndex = 0; 
		int xmlCounter = 0;

		boolean xmlDataExists = false;

		String xmlData = "";
		String xmlDataToSend = "";
		String xmlContent = "";

		exceptionExists = false;

		try
		{
			int ackMsgLen = ackMessage.length();
			String tt = (char)13+"OBX";
			System.out.println("tt "+tt);
			while(index < ackMsgLen)
			{
				i = 0;
				int tempIndex = index;
				index = ackMessage.indexOf(tt,index) + 4;
				if(index < tempIndex)
					break;
//				System.out.println("INDEX "+index);
				nextOBXIndex = ackMessage.indexOf(tt,index)+4;
//				System.out.println("nextOBXIndex "+nextOBXIndex);
				if(nextOBXIndex < index)
					nextOBXIndex = ackMsgLen;
				String tempVal = "";

				while(true)
				{
					char strChar = ackMessage.charAt(++index);
//					System.out.println("CHARAT:"+strChar);
					if(i == 1)
					{
						tempVal = tempVal+strChar;
//						System.out.println("tempVal:"+tempVal);
					}
					else if(i > 1)
					{						
						String xmlExists = ackMessage.substring(index,nextOBXIndex);
						int xmlIndex = xmlExists.indexOf("<levelone>");
						while(xmlIndex != -1)
						{
//							System.out.println("INDEXOF "+xmlIndex);
							xmlDataExists = true;								
							xmlData = xmlExists.substring(xmlIndex);							
							int lastIndex = xmlData.indexOf("</levelone>");
//							System.out.println("lastIndex "+lastIndex);
							xmlData = xmlData.substring(0,lastIndex+11);									
						//	xmlStrings.add(xmlData);
							xmlCounter++;
							
							if(xmlCounter == 1)
							{
								xmlDataToSend = xmlData;
							}						
						
							xmlContent = xmlContent+xmlData;
//							System.out.println("xmlCounter "+xmlCounter);
							
							xmlIndex = xmlExists.indexOf("<levelone>",xmlIndex+10);							
							if(xmlIndex < lastIndex)
								break;
						}
						
						System.out.println("-xmlContent- "+xmlContent);
						break;
					}
					

					if(strChar == '|')
					{
						i++;
					}					
				//	if(i == 4)	break;
				}
			}								
		}
		catch(Exception exception)
		{
			exception.printStackTrace(System.err);
			exceptionMsg = "Error in getting XML content";
			exceptionExists = true;
		}
		return xmlContent;
	}

	public String[] getFooters(String headerString)
	{				
		String header1 = "";
		String header2 = "";
		String docContent = "";
		String docContent1 = "";

		String [] Footers = new String[2];

		ArrayList tempList = new ArrayList();	
		ArrayList temp1List = new ArrayList();

		tempList = getElementsFromXML(headerString,"<legal_authenticator","</legal_authenticator>");

		if(tempList.size() > 0)
		{
			docContent = (String)tempList.get(0);

			if(docContent != null && !docContent.equals(""))
			{
				Footers[1] = getHeaderContent(docContent,"QUAL");

				if(Footers[1] == null )
					Footers[1] = "";

				temp1List = getElementsFromXML(docContent,"<FAM","</FAM>");

				if(temp1List.size() > 0)
				{
					docContent1 = (String)temp1List.get(0);

					if(docContent1 != null && !docContent1.equals(""))
						Footers[0] = getHeaderContent(docContent1, "V");
					else
						Footers[0] = "";
				}
			}
		}
		else
		{
			Footers[0] = "";
			Footers[1] = "";
		}


		tempList.clear();
		temp1List.clear();
		docContent = "";
/*
		tempList = getElementsFromXML(headerString,"<organization.nm","</organization.nm>");
		if(tempList.size() > 0)	
		{
			docContent = (String)tempList.get(0);
			if(docContent != null && !docContent.equals(""))
				headers[1] = getHeaderContent(docContent,"V");
		}
		else
			headers[1] = "";
*/
		System.out.println("fOOTER1 "+Footers[0]);
		System.out.println("FOOTER2 "+Footers[1]);
		
		return Footers;
	}
	private String replaceString(String sourceString,String replaceWhat,String replaceWith)
    {
		if (sourceString.indexOf(replaceWhat) != -1) sourceString = sourceString.replaceAll(replaceWhat,replaceWith);
		return sourceString;
    }

}// end of class