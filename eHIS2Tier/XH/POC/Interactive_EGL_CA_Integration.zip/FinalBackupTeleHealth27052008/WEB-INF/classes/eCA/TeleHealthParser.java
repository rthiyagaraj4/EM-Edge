package eCA;

import java.util.regex.*;
import org.w3c.dom.*;
import java.io.*;
import javax.xml.parsers.*;
import java.util.*;
import org.xml.sax.*;
import org.apache.xpath.XPathAPI;
import java.sql.*;

public class TeleHealthParser
{
	StringBuffer displayString	= new StringBuffer();
	StringBuffer strErrorMsg	= new StringBuffer();

	public TeleHealthParser()
	{
		strErrorMsg.delete(0,strErrorMsg.length());
		displayString.delete(0,displayString.length());
	}

	public String getDocuments(Connection con,String XMLContent,String strPatientId,String strSessionid)
	{
		boolean	bHdrStatus		=	false;
		boolean bBodyStatus		=	false;

		PreparedStatement pst	= null;

		int nlDocLen				=	0,		nCurIdx	=	0,				nUpdRecs		=	0;

		try
		{
			String strQuery =	"DELETE FROM XH_CLINICAL_INTEGRATION WHERE PATIENT_NRIC_ID = ? AND SESSION_ID = ? ";
			
			pst	=	con.prepareStatement(strQuery);

			System.out.println(" strPatientId for deletion "+ strPatientId + " / "  + strSessionid);
			System.out.println(" strPatientId for Before Deletion  "+ strPatientId + " / "  + strSessionid);
			pst.setString(1,strPatientId);
			pst.setString(2,strSessionid);

			nUpdRecs	=	pst.executeUpdate();

			if(nUpdRecs >= 0)
				con.commit();

			if( pst != null) pst.close();
			
			boolean bStatus = getContentNew(XMLContent,strPatientId,strSessionid,con);

			if(!bStatus)
				strErrorMsg.append("APP-CA803 No XML Document Received.....     ") ;
		}
		catch (Exception e41)
		{
			strErrorMsg.append("APP-CA803 No XML Document Received.....     ") ;
			e41.printStackTrace(System.err);
			System.out.println( " Error from the Tele Health Process @ 41 " + e41.getMessage());
		}

		finally
		{
			return strErrorMsg.toString();
		}
	}	


	public String UpdateDb(int nIdx,String strSessid,String strPatId,String strHead,String strBody,Connection con)
	{
//		Connection			con		=	null;
		CallableStatement	csDb	=	null;

		String strErrorCode		=	"0";
		String strErrorMesg =	"";

		try
		{
			csDb	= con.prepareCall("{call xh_cl_in_up_del(?,?,?,?,?,?,?,?,?,?,?)}");
			
			csDb.setString(1,"I");
			csDb.setString(2,strPatId);
			csDb.setString(3,strSessid);
			csDb.setInt(4,nIdx);
			csDb.setString(5,strHead);
			csDb.setString(6,strBody);
			csDb.setString(7,"E");
			csDb.setString(8,"E");
			csDb.setString(9,null);
			csDb.registerOutParameter(10,java.sql.Types.VARCHAR);
			csDb.registerOutParameter(11,java.sql.Types.VARCHAR);

			csDb.execute();

			strErrorCode		= csDb.getString(10);
			strErrorMesg		= csDb.getString(11);

			if(strErrorMesg == null)
				strErrorMesg = "";

			if(!strErrorMesg.equals("") )
			{
				strErrorMsg.append("APP-CA907 Updation Failed for the Document Number "+nIdx);
			}
		}
		catch (Exception e901)
		{
			System.out.println( " Error in updating the database e 901 " + e901.getMessage());
			e901.printStackTrace(System.err);
		}
		
		finally
		{
			return strErrorCode;
		}
	}

	public boolean getContentNew(String xmlContent,String strPatientId,String strSessionId,Connection con)
	{
		ArrayList Docs			= new ArrayList();
		ArrayList Headers       = new ArrayList();
		ArrayList Bodys         = new ArrayList();

		String strRtnContent	=	"";
		String nUpdStatus		=	"0";
		String sectionContent	=	"";

		int nHeadSize	=	0;

		StringBuffer content = new StringBuffer();
				
		boolean bStatus = true;

		try
		{
			Docs		=	getElementsFromXML(xmlContent,"<levelone>","</levelone>");
			nHeadSize	=	Docs.size();

			System.out.println(" Total Number of Docs Received - from Parser reported " + nHeadSize);
		
			int i = 0;

			if(nHeadSize > 0 )
			{
				for(i = 0; i < nHeadSize; i++)
				{
					String strDoc = (String) Docs.get(i);
		
					if(strDoc != null && !strDoc.equals("") )
					{
						Headers = getElementsFromXML(strDoc,"<clinical_document_header>","</clinical_document_header>");
						String strDocHeader = "<clinical_document_header></clinical_document_header>";

						if(Headers.size() > 0)
							strDocHeader = (String)Headers.get(0);
						

						nUpdStatus	= UpdateDb(i,strSessionId,strPatientId,strDocHeader,strDoc,con);
					}
				}
			}
			else
			{
				bStatus = false;
			}
		}
		catch (Exception e64643)
		{
			e64643.printStackTrace(System.err);
			bStatus = false;
		}
		finally
		{
			return bStatus;
		}
	}
	
	public ArrayList getElementsFromXML(String xmlTemp,String elementStart,String elementEnd)
	{
		int currentSectionIndex = 0;
		int endIndex = 0;

		String temp = "";

		// Converting to lower case.
		String xmlTempLower = xmlTemp.toLowerCase();
		elementStart		= elementStart.toLowerCase();
		elementEnd			= elementEnd.toLowerCase();
		
		ArrayList tempList = new ArrayList();

		while(true)
		{
			currentSectionIndex = xmlTempLower.indexOf(elementStart);

			if(currentSectionIndex < 0)
				break;
			
			endIndex = xmlTempLower.indexOf(elementEnd);

			if(endIndex < 0)
				break;
					
			temp = xmlTemp.substring(currentSectionIndex,endIndex+elementEnd.length());			
			xmlTemp = xmlTemp.substring(endIndex+elementEnd.length());
			xmlTempLower = xmlTempLower.substring(endIndex+elementEnd.length());
			tempList.add(temp);		
			System.out.println(" Document for " + temp);
		}
		
		return tempList;
	}	
	public boolean  containsSubstring(String mainString, String strSearch)
	{
		boolean status = false; 
		strSearch = strSearch.trim();
//		System.out.println("mainString "+mainString);
//		System.out.println("strSearch "+strSearch+"DES");
		Pattern pattern = Pattern.compile(strSearch);
		Matcher matcher = pattern.matcher(mainString); 
		status = matcher.find();
//		System.out.println("Status "+status);
//		System.out.println( " Pattern Match for " + strSearch + " - > " + status);

		return status; 
	}


}
