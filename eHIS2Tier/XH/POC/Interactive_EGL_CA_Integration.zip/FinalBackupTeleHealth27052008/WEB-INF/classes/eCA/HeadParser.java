package eCA;
import org.w3c.dom.*;
import java.io.*;
import javax.xml.parsers.*;
import java.util.*;
import org.xml.sax.*;
import org.apache.xpath.XPathAPI;

public class HeadParser
{
    StringBuffer displayString = new StringBuffer();

	public String getdata(String XMLContent)
	{
		StringBuffer sbXPathDefn = new StringBuffer();
		
		String strCompType			=	"";
		String strCompValue			=	"";
		String strResultType		=	"";
		
		
		NodeList nlDTNodes			=	null;
		Node ndAttNode				=	null;
		Node ndDTNode				=	null;
		NamedNodeMap	nnmpAttr	= 	null;
		StringBuffer sbHeaderData = new StringBuffer();		
		int nDTNodesLen				=	0,		nCurIdx	=	0;

		try
		{			
			displayString.delete(0,displayString.length());
			sbXPathDefn.delete(0,sbXPathDefn.length());
			sbXPathDefn.append("/clinical_document_header/id");


																							   
//			StringReader strTemp = new StringReader(XMLContent);
//			InputSource isTemp = new InputSource(strTemp);
	
			Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new ByteArrayInputStream(XMLContent.getBytes()));

			
			nlDTNodes	= XPathAPI.selectNodeList(doc,sbXPathDefn.toString());

			System.out.println(" lengthofid node3 " + nlDTNodes.getLength());
			
			
			if(nlDTNodes != null)
			{
				try
				{
					nDTNodesLen	= nlDTNodes.getLength();
					
					for(nCurIdx = 0; nCurIdx < nDTNodesLen ; nCurIdx++)
					{
						ndDTNode		= nlDTNodes.item(nCurIdx);
						if(ndDTNode == null)
							continue;
						System.out.println(" Node Name " + ndDTNode.getNodeName());
							
						nnmpAttr		= ndDTNode.getAttributes();								
						ndAttNode		= nnmpAttr.getNamedItem("EX");
						strCompType		= ndAttNode.getNodeValue();
					
						if(strCompType != null  )
						{
							sbHeaderData.append(strCompType);
//							sbHeaderData.append("~");
						}
					}
				}
				catch (Exception e4)
				{
					e4.printStackTrace(System.err);
				}
				sbHeaderData.append("!!");
			}

			sbXPathDefn.delete(0,sbXPathDefn.length());
			sbXPathDefn.append("/clinical_document_header/legal_authenticator/participation_tmr");
			nlDTNodes	= XPathAPI.selectNodeList(doc,sbXPathDefn.toString());
			
			if(nlDTNodes != null)
			{
				nDTNodesLen	= nlDTNodes.getLength();
				
				for(nCurIdx = 0; nCurIdx < nDTNodesLen ; nCurIdx++)
				{
					ndDTNode		= nlDTNodes.item(nCurIdx);
					nnmpAttr		= ndDTNode.getAttributes();
					ndAttNode		= nnmpAttr.getNamedItem("V");
					strCompType		= ndAttNode.getNodeValue();
				
					if(strCompType != null  )
					{
						sbHeaderData.append(strCompType);
//						sbHeaderData.append("~");
					}
				}
				
				sbHeaderData.append("!!");
			}

			sbXPathDefn.delete(0,sbXPathDefn.length());

			sbXPathDefn.append("/clinical_document_header/originating_organization/organization/organization.nm");
			nlDTNodes	= XPathAPI.selectNodeList(doc,sbXPathDefn.toString());
			
			if(nlDTNodes != null)
			{
				nDTNodesLen	= nlDTNodes.getLength();
				
				for(nCurIdx = 0; nCurIdx < nDTNodesLen ; nCurIdx++)
				{
					ndDTNode		= nlDTNodes.item(nCurIdx);
					nnmpAttr		= ndDTNode.getAttributes();
					ndAttNode		= nnmpAttr.getNamedItem("V");
					strCompType		= ndAttNode.getNodeValue();
				
					if(strCompType != null  )
					{
						sbHeaderData.append(strCompType);
//						sbHeaderData.append("~");
					}
				}
			}
           
		}
		catch (Exception e)
		{
			e.printStackTrace(System.err);
		}
		
		finally
		{
			return sbHeaderData.toString();
		}
	}

	

}	