// GotoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "rpviewer.h"
#include "GotoDlg.h"
#include "zoomview.h"	// For CZoomView class
#include "rpdoc.h"
#include "rpview.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGotoDlg dialog


CGotoDlg::CGotoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGotoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGotoDlg)
	m_pageno = 0;
	//}}AFX_DATA_INIT
}


void CGotoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGotoDlg)
	DDX_Text(pDX, IDC_PAGE_NO, m_pageno);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGotoDlg, CDialog)
	//{{AFX_MSG_MAP(CGotoDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGotoDlg message handlers


BOOL CGotoDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	SetDlgItemInt(IDC_PAGE_NO,1,TRUE);
	CenterWindow();

	return TRUE;  
}



