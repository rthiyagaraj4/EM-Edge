// testdoc.h : interface of the CTestDoc class
//
/////////////////////////////////////////////////////////////////////////////

class CTestDoc : public CDocument
{
protected: // create from serialization only
	CTestDoc();
	DECLARE_DYNCREATE(CTestDoc)

// Attributes
public:

	FILE *fp;                     
    char **file_buf;
    char *buffer;
	char *file_name;
    long int i, no_page;
    long int ct_page;
    long int no_line;
    long end_loc[75000];
    long no_char[75000];
    char szBuffer[5000];
	long st;
    fpos_t pos;
    long int NUMLINES;

    //char tstrCmdLine[256];
    //char PgmCmdLine[256];
	//buffer=(char *) malloc(end_loc[ct_page]+1);

// Operations
public:

// Implementation
protected:
	CSize           m_sizeDoc;
public:
	CSize GetDocSize() { return m_sizeDoc; }

	void FileOpen(void);	// To File openning process
	void GetPageNo(long int pg_no);	// To Get a Page texts
	void GetContents(void);	    // To Seperate the page into lines


public:
	virtual void InitDocument();
	virtual ~CTestDoc();
	virtual void Serialize(CArchive& ar);	// overridden for document i/o
#ifdef _DEBUG
	virtual	void AssertValid() const;
	virtual	void Dump(CDumpContext& dc) const;
#endif
protected:
	virtual	BOOL  OnNewDocument();
	virtual BOOL  OnOpenDocument(const char* pszPathName);

// Generated message map functions
protected:
	//{{AFX_MSG(CTestDoc)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
