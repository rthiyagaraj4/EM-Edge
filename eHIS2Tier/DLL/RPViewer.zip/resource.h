//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by rpviewer.rc
//
#define IDR_MAINFRAME                   2
#define IDR_TESTTYPE                    3
#define IDD_ABOUTBOX                    100
#define IDC_ZOOMCURSOR                  101
#define IDC_PAGE_NO                     104
#define IDC_ZOOMOUT                     124
#define IDC_ZOOMIN                      125
#define IDD_GOTOBOX                     126
#define ID_VIEW_ZOOMIN                  32769
#define ID_VIEW_ZOOMOUT                 32770
#define ID_VIEW_ZOOMFULL                32771
#define ID_NAVIGATE_FIRSTPAGE           32775
#define ID_NAVIGATE_NEXTPAGE            32776
#define ID_NAVIGATE_PREVIOUSPAGE        32779
#define ID_NAVIGATE_LASTPAGE            32780
#define ID_GOTO                         32790
#define ID_INDICATOR_PAGE               59142

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        127
#define _APS_NEXT_COMMAND_VALUE         32794
#define _APS_NEXT_CONTROL_VALUE         109
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
