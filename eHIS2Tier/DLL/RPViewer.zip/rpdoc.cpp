// testdoc.cpp : implementation of the CTestDoc class
//

//***********
#include "stdafx.h"
#include "rpviewer.h"

#include "rpdoc.h"
#include "malloc.h"


#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestDoc

IMPLEMENT_DYNCREATE(CTestDoc, CDocument)

BEGIN_MESSAGE_MAP(CTestDoc, CDocument)
	//{{AFX_MSG_MAP(CTestDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestDoc construction/destruction

CTestDoc::CTestDoc()
{
	// TODO: add one-time construction code here
	no_page   = 0;
	no_line   = 0;
	ct_page   = 1;
	NUMLINES  = 0;
	buffer    = NULL;
	file_name = NULL;
	fp        = NULL;
	file_buf  = NULL;
    end_loc[0] = NULL;
    no_char[0] = NULL;
    szBuffer[0]= NULL; ;
	st         = 0;
    pos        = 0;

}

CTestDoc::~CTestDoc()
{
	if(file_name!=NULL)
		free(file_name);
}

void CTestDoc::InitDocument()
{
	//m_sizeDoc = CSize(1350,1600);

	// This is very important, this is view port setting if you increase 
	// hieght Font size will change Becare full. 
	// If necessary arise to increase height, goto TestView
	// change the font height calculation as per requirement.
	// If you increase width , Full fit goes to right alignment.
	// Decide as per requirement.

	//m_sizeDoc = CSize(1700,1600);
	//---------------width,hieght of the View port.
	
	FileOpen();		     // File openning process and file reading
	GetPageNo(ct_page);	 // Get corresponding Page texts
	GetContents();	     // Seperate the whole text into lines

	m_sizeDoc = CSize(2000,1700);

}

BOOL CTestDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	InitDocument();
	return TRUE;
}

BOOL CTestDoc::OnOpenDocument(const char* pszPathName)
{
	//int len=0;
	//char commd[200];
	//if (!CDocument::OnOpenDocument(pszPathName))
	//	exit(0); 

	file_name = (char*)malloc(100*sizeof(char));
	strcpy(file_name,pszPathName);

	InitDocument();
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CTestDoc serialization

void CTestDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}


/////////////////////////////////////////////////////////////////////////////
// CTestDoc diagnostics

#ifdef _DEBUG
void CTestDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTestDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestDoc commands

void CTestDoc::FileOpen() 
{
	long int i=0;
	char ch;

	if ((fp = fopen (file_name, "r")) != NULL)
	{  
		st=ftell(fp);
		end_loc[no_page]=ftell(fp);
		no_char[no_page]=i;
		ch=fgetc(fp);
		if(ch==12)
		{
			st=ftell(fp);
			end_loc[no_page]=ftell(fp);
			no_char[no_page]=i;
		}
		do 
		{
			ch=fgetc(fp);
			i=i+1;
			if(ch==12)
			{
				no_page = no_page + 1;
				if (no_page>75000)
				{
					AfxMessageBox("File is too large, Cannot Open");
					exit(0);
				}
				end_loc[no_page]=ftell(fp);
				no_char[no_page]=i;
				i=0;
			}

		}while(ch != EOF);
	} 
	else 
	{
	  AfxMessageBox("File not found");
	  exit (0);
	}
	if(i>10)
	{
		no_page = no_page + 1;
		end_loc[no_page]=ftell(fp);
		no_char[no_page]=i;
	}
	fclose(fp);
}

void CTestDoc::GetPageNo(long int pg_no)
{
	if ((fp = fopen (file_name, "r")) != NULL)
	{
		ct_page = pg_no;
		if((ct_page <= no_page)&&
		   (ct_page > 0))
		{
			if(ct_page==1)
				pos=st;
			else
				pos=end_loc[ct_page-1];

			fsetpos(fp,&pos);
			buffer=(char *) malloc(no_char[ct_page]+1);
			//buffer=(char *) malloc(end_loc[ct_page]+1);
			//fread( buffer, sizeof(char),end_loc[ct_page],fp);
			fread( buffer, sizeof(char),no_char[ct_page],fp);
			buffer[no_char[ct_page]-1]='\0';
			fclose(fp);
		}
	}
	else
	{
	  AfxMessageBox("File not found");
	  exit (0);
	}

}


void CTestDoc::GetContents()
{
	long int x=0,j=0;
	long int ssm=0;
	NUMLINES=0;

	if(buffer!=NULL)
	{
		file_buf = (char **) malloc ( sizeof(char *) * (NUMLINES + 1) );

		for(;*buffer;buffer++)
		{
			if((*buffer == '\n') || (*buffer == '\r') ||
				(*buffer == EOF))
			{
			   szBuffer[j]='\0';
			   file_buf[NUMLINES] = (char *) malloc ( sizeof(char) * strlen(szBuffer));
			   strcpy ( file_buf[NUMLINES++], szBuffer );
			   file_buf = (char **) realloc (file_buf, sizeof(char *) * (NUMLINES + 1));
			   j=0;
			}
			else
			{
				szBuffer[j]=*buffer;
				j++;
			}
		}

		if(j>5)
		{
		   szBuffer[j]='\0';
		   file_buf[NUMLINES] = (char *) malloc ( sizeof(char) * strlen(szBuffer));
		   strcpy ( file_buf[NUMLINES++], szBuffer );
		}
	}
}

