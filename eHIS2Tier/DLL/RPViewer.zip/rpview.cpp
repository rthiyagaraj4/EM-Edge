// testview.cpp : implementation of the CTestView class
//

#include "stdafx.h"
#include "mainfrm.h"
#include "zoomview.h"	// For CZoomView class
#include "rpviewer.h"
#include "afxpriv.h"    // For WM_SETMESSAGESTRING
#include "rpdoc.h"
#include "rpview.h"
#include "GotoDlg.h"
#include "stdarg.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

// Define some colors to make the boxes better looking
#define NUM_COLORS 9
#define COLOR_YELLOW  RGB(255, 255,   0)
#define COLOR_PURPLE  RGB(255,   0, 255)
#define COLOR_BLACK   RGB(  0,   0,   0)
#define COLOR_RED     RGB(255,   0,   0)
#define COLOR_GREEN   RGB(  0, 255,   0)
#define COLOR_DKGREEN RGB(  0, 128,   0)
#define COLOR_BLUE    RGB(  0,   0, 255)
#define COLOR_AQUA    RGB(  0, 255, 255)
#define COLOR_GRAY    RGB(192, 192, 192)
COLORREF colors[NUM_COLORS] = {COLOR_BLACK, COLOR_RED, COLOR_GREEN, COLOR_DKGREEN, 
	COLOR_BLUE, COLOR_AQUA, COLOR_YELLOW, COLOR_PURPLE, COLOR_GRAY};

/////////////////////////////////////////////////////////////////////////////
// CTestView

IMPLEMENT_DYNCREATE(CTestView, CZoomView)

BEGIN_MESSAGE_MAP(CTestView, CZoomView)
	//{{AFX_MSG_MAP(CTestView)
	ON_COMMAND(ID_VIEW_ZOOMIN, OnViewZoomin)
	ON_COMMAND(ID_VIEW_ZOOMOUT, OnViewZoomout)
	ON_COMMAND(ID_VIEW_ZOOMFULL, OnViewZoomfull)
	ON_UPDATE_COMMAND_UI(ID_VIEW_ZOOMIN, OnUpdateViewZoomin)
	ON_UPDATE_COMMAND_UI(ID_VIEW_ZOOMOUT, OnUpdateViewZoomout)
	ON_COMMAND(ID_NAVIGATE_LASTPAGE, OnNavigateLastpage)
	ON_COMMAND(ID_NAVIGATE_FIRSTPAGE, OnNavigateFirstpage)
	ON_COMMAND(ID_NAVIGATE_NEXTPAGE, OnNavigateNextpage)
	ON_COMMAND(ID_NAVIGATE_PREVIOUSPAGE, OnNavigatePreviouspage)
	ON_COMMAND(ID_GOTO, OnGoto)
	ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CZoomView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CZoomView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestView construction/destruction

CTestView::CTestView()
{
}

CTestView::~CTestView()
{
	if (m_font) delete m_font;
}


void CTestView::OnInitialUpdate()
{
	char status[50];
	CZoomView::OnInitialUpdate();
	CTestDoc* pDoc = GetDocument();

	// Initialize the CZoomView class
	SetZoomSizes(pDoc->GetDocSize());

	if( pDoc->ct_page <= pDoc->no_page)
	{
		sprintf(status," Page %d of %d",pDoc->ct_page,pDoc->no_page);
		StatusBarMessage(status);
	}

	// Create the LOGICAL font to draw with (only once!)
	//int height = (m_totalLog.cy / 10) / 8;  // 1/7 of box size

	int height = (m_totalLog.cy / 10) / 10;
    m_font = new CFont();
    //m_font->CreateFont(height, 0, 0, 0,
    //     FW_NORMAL, FALSE, FALSE,
    //     FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
    //     DEFAULT_QUALITY, VARIABLE_PITCH | FF_DONTCARE, "Arial");

    m_font->CreateFont(height, 0, 0, 0,
         FW_NORMAL, FALSE, FALSE,
         FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
         DEFAULT_QUALITY, VARIABLE_PITCH | FF_DONTCARE, "Courier New");

}

/////////////////////////////////////////////////////////////////////////////
// CTestView drawing
void CTestView::OnDraw(CDC* pDC)
{
	CTestDoc *pDoc = GetDocument();
	CFont    *oldFont;
	int textX, textY;
	int i=0;
	//CPen     *oldPen;
	//char     buf[150];

	// Draw border
	//CRect rect(1, 1, m_totalLog.cx - 1, m_totalLog.cy - 1);
	//pDC->Rectangle(&rect);
	
	oldFont = pDC->SelectObject(m_font); 
	//int color  = 0;
	//int width  = m_totalLog.cx / 10;
	//int height = m_totalLog.cy / 10;
	//int widthPad  = width  / 10;
	//int heightPad = height / 10;
	//CSize size;

	for (textX=5,textY=5,i=0;i<pDoc->NUMLINES; i++,textY+=18) 
		pDC->TabbedTextOut(textX,textY,pDoc->file_buf[i],0,NULL,0);

	//CSize TabbedTextOut( int x, int y, const CString& str, int nTabPositions, LPINT lpnTabStopPositions, int nTabOrigin );
	//pDC->TextOut(textX,textY, pDoc->file_buf[i],strlen(pDoc->file_buf[i]));

	pDC->SelectObject(oldFont); 
	

} // OnDraw

/////////////////////////////////////////////////////////////////////////////
// CTestView printing

BOOL CTestView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
} // OnPreparePrinting

void CTestView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
} // OnBeginPrinting

void CTestView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
} // OnEndPrinting



/////////////////////////////////////////////////////////////////////////////
// CTestView diagnostics

#ifdef _DEBUG
void CTestView::AssertValid() const
{
	CZoomView::AssertValid();
}

void CTestView::Dump(CDumpContext& dc) const
{
	CZoomView::Dump(dc);
}

CTestDoc* CTestView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTestDoc)));
	return (CTestDoc*) m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestView message handlers
//
/*---------------------------------------------------------------------------
   FUNCTION: OnViewZoomin
   PURPOSE : User pressed the ZOOM IN toolbutton or menu
---------------------------------------------------------------------------*/
void CTestView::OnViewZoomin()
{
	// Toggle zoomin mode
	CWnd *pWin = ((CWinApp *) AfxGetApp())->m_pMainWnd;
	if (GetZoomMode() == MODE_ZOOMIN) {
		SetZoomMode(MODE_ZOOMOFF);
		// Clear the statusbar
		pWin->SendMessage(WM_SETMESSAGESTRING, 0, 
			(LPARAM)(LPCSTR)"");
		//Included by sathya
		m_hZoomCursor = ::LoadCursor(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDC_ZOOMCURSOR));

	} else {
		SetZoomMode(MODE_ZOOMIN);
		// Give instructions in the statusbar
		pWin->SendMessage(WM_SETMESSAGESTRING, 0, 
			(LPARAM)(LPCSTR)"Click to Zoom In");
	    //Included by sathya
	    m_hZoomCursor = ::LoadCursor(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDC_ZOOMIN));
	}

} // OnViewZoomin

/*---------------------------------------------------------------------------
   FUNCTION: OnViewZoomout
   PURPOSE : User pressed the ZOOM OUT toolbutton or menu
---------------------------------------------------------------------------*/
void CTestView::OnViewZoomout()
{
	CWnd *pWin = ((CWinApp *) AfxGetApp())->m_pMainWnd;
	// Toggle zoomout mode
	if (GetZoomMode() == MODE_ZOOMOUT) {
		SetZoomMode(MODE_ZOOMOFF);
		// Clear the statusbar
		pWin->SendMessage(WM_SETMESSAGESTRING, 0, 
			(LPARAM)(LPCSTR)"");
		//Included by sathya
		m_hZoomCursor = ::LoadCursor(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDC_ZOOMCURSOR));
	}
	else 
	{
		SetZoomMode(MODE_ZOOMOUT);
		// Give instructions in the statusbar
		pWin->SendMessage(WM_SETMESSAGESTRING, 0, 
			(LPARAM)(LPCSTR)"Click to Zoom Out");
	    //Included by sathya
	    m_hZoomCursor = ::LoadCursor(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDC_ZOOMOUT));
	}
	
} // OnViewZoomout

/*---------------------------------------------------------------------------
   FUNCTION: OnViewZoomfull
   PURPOSE : User pressed the ZOOM FULL toolbutton or menu
---------------------------------------------------------------------------*/
void CTestView::OnViewZoomfull()
{
	DoZoomFull();  // Call CZoomView member to zoom full scale
}

/*---------------------------------------------------------------------------
   FUNCTION: OnUpdateViewZoomin
   PURPOSE : Tell MFC whether to depress the button or check the menu
---------------------------------------------------------------------------*/
void CTestView::OnUpdateViewZoomin(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(GetZoomMode() == MODE_ZOOMIN);
}

/*---------------------------------------------------------------------------
   FUNCTION: OnUpdateViewZoomout
   PURPOSE : Tell MFC whether to depress the button or check the menu
---------------------------------------------------------------------------*/
void CTestView::OnUpdateViewZoomout(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(GetZoomMode() == MODE_ZOOMOUT);
} 

//* Navigations 

void CTestView::OnNavigateFirstpage() 
{
	char status[50];
	CTestDoc *pDoc = GetDocument();
	
	pDoc->ct_page = 1;
	pDoc->GetPageNo(pDoc->ct_page);	
	pDoc->GetContents();
	pDoc->UpdateAllViews(NULL,0,0);

	if( pDoc->ct_page <= pDoc->no_page)
	{
		sprintf(status," Page %d of %d",pDoc->ct_page,pDoc->no_page);
		StatusBarMessage(status);
	}
}

void CTestView::OnNavigateNextpage() 
{
	char status[50];
	CTestDoc *pDoc = GetDocument();

	pDoc->ct_page = pDoc->ct_page + 1;
	if (pDoc->ct_page > pDoc->no_page)
		pDoc->ct_page = pDoc->no_page;

	pDoc->GetPageNo(pDoc->ct_page);	
	pDoc->GetContents();		
	pDoc->UpdateAllViews(NULL,0,0);

	if((pDoc->ct_page <= pDoc->no_page) &&
	   (pDoc->ct_page >0))
	{
		sprintf(status," Page %d of %d",pDoc->ct_page,pDoc->no_page);
		StatusBarMessage(status);
	}
}

void CTestView::OnNavigatePreviouspage() 
{
	char status[50];
	CTestDoc *pDoc = GetDocument();
	
	pDoc->ct_page = pDoc->ct_page - 1;
	if (pDoc->ct_page < 1)
		pDoc->ct_page = 1;
	pDoc->GetPageNo(pDoc->ct_page);	
	pDoc->GetContents();		
	pDoc->UpdateAllViews(NULL,0,0);

	if((pDoc->ct_page <= pDoc->no_page) &&
	   (pDoc->ct_page >0))
	{
		sprintf(status," Page %d of %d",pDoc->ct_page,pDoc->no_page);
		StatusBarMessage(status);
	}
}

void CTestView::OnNavigateLastpage() 
{
	char status[50];
	CTestDoc *pDoc = GetDocument();

	pDoc->ct_page = pDoc->no_page;
	pDoc->GetPageNo(pDoc->ct_page);	
	pDoc->GetContents();		
	pDoc->UpdateAllViews(NULL,0,0);

	if((pDoc->ct_page <= pDoc->no_page) &&
	   (pDoc->ct_page >0))
	{
		sprintf(status," Page %d of %d",pDoc->ct_page,pDoc->no_page);
		StatusBarMessage(status);
	}
}


void CTestView::OnGoto() 
{
	char status[50];
	CTestDoc *pDoc = GetDocument();
	CGotoDlg gotoDlg;
	gotoDlg.DoModal();

    if(gotoDlg.m_pageno > 0)         //(gotoDlg.m_pageno <= pDoc->no_page))
	{
	   if(gotoDlg.m_pageno > pDoc->no_page)
	   {
		   sprintf(status,"Maximum Number of Page(s) %d",pDoc->no_page);
		   AfxMessageBox(status);
		   gotoDlg.m_pageno = pDoc->no_page;
	   }

	   pDoc->GetPageNo(gotoDlg.m_pageno);	
	   pDoc->GetContents();		
	   pDoc->UpdateAllViews(NULL,0,0);

	   if((pDoc->ct_page <= pDoc->no_page) &&
		  (pDoc->ct_page >0))
	   {
		  sprintf(status," Page %d of %d",gotoDlg.m_pageno,pDoc->no_page);
		  StatusBarMessage(status);
	   }
	}
}

void CTestView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	BOOL processed;
	for(unsigned int i=0; i<nRepCnt&&processed; i++)
		processed=KeyScroll(nChar);

	if(!processed)
		CZoomView::OnKeyDown(nChar, nRepCnt, nFlags);
}

BOOL CTestView::KeyScroll(UINT nChar)
{
	switch (nChar)
	{
	case VK_UP :
		OnVScroll(SB_LINEUP,0,NULL);
		break;
	case VK_DOWN :
		OnVScroll(SB_LINEDOWN,0,NULL);
		break;
	case VK_HOME :
		OnVScroll(SB_LEFT,0,NULL);
		break;
	case VK_END :
		OnVScroll(SB_RIGHT,0,NULL);
		break;
	case VK_LEFT :
		OnHScroll(SB_LINELEFT,0,NULL);
		break;
	case VK_RIGHT :
		OnHScroll(SB_LINERIGHT,0,NULL);
		break;
	default:
		return FALSE;

	}
	return TRUE;
}


void CTestView::StatusBarMessage(char* fmt)
{
  if (AfxGetApp() != NULL && AfxGetApp()->m_pMainWnd != NULL) 
  {
     char buffer[256];
	 int indx;
     CStatusBar* pStatus = (CStatusBar*) 
     AfxGetApp()->m_pMainWnd->GetDescendantWindow(AFX_IDW_STATUS_BAR);
     va_list argptr;
     va_start(argptr, fmt);
     vsprintf(buffer, fmt, argptr);
     va_end(argptr);
	 UINT nID,nStyle;
	 int cxWidth;
     if (pStatus != NULL)
	 {
	   indx = pStatus->CommandToIndex(ID_INDICATOR_PAGE);
	   pStatus->GetPaneInfo(indx,nID,nStyle,cxWidth);
	   cxWidth = strlen(buffer)*7;
	   pStatus->SetPaneInfo(indx,nID,SBPS_STRETCH,cxWidth);
       indx = pStatus->SetPaneText(indx,buffer,TRUE);
	   pStatus->SetPaneInfo(indx,nID,SBPS_DISABLED,cxWidth);
       pStatus->UpdateWindow();
     }
  }
}